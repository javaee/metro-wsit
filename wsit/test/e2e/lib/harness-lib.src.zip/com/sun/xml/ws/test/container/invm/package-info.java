/**
 * {@link ApplicationContainer} implementation
 * that uses the in-vm transport.
 *
 * <p>
 * This is usually the preferred mode of testing,
 * as it can run very quickly.
 */
package com.sun.xml.ws.test.container.invm;

import com.sun.xml.ws.test.container.ApplicationContainer;