/**
 * {@link ApplicationContainer} implementation
 * that uses local transport and no "container" per se.
 */
package com.sun.xml.ws.test.container.local;

import com.sun.xml.ws.test.container.ApplicationContainer;