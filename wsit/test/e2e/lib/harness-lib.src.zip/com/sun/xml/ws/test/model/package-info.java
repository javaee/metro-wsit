/**
 * Classes that describe a test (metadata of test).
 */
package com.sun.xml.ws.test.model;