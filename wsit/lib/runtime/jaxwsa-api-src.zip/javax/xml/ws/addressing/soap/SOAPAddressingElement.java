/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: SOAPAddressingElement.java,v 1.3 2005/09/23 00:32:48 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package javax.xml.ws.addressing.soap;

import javax.xml.soap.SOAPElement;
import javax.xml.namespace.QName;
import javax.xml.ws.addressing.AddressingException;
import javax.xml.ws.addressing.AddressingType;

/**
 * Interface implemented by JAX-WSA classes that can be serialized / deserialized 
 * to <code>SOAPElements</code>.
 * 
 * @author JAX-WSA Development Team
 * @version JAX-WSA 1.0
 */
public interface SOAPAddressingElement extends AddressingType {
    

    /**
     * Initialize the object using the data contained in the specified
     * <code>SOAPElement</code>.
     *
     * @param element The <code>SOAPElement</code> to be read.

     * @throws AddressingException if an error occurs.
     */
    public void read(SOAPElement element) throws AddressingException;

    /**
     * Write a <code>SOAPHeaderElement</code> with the specified name 
     * as a child of the specified <code>SOAPElement</code> parent.
     *
     * @param parent The parent node
     * @param name The name of the element to be written. 
     *
     * @return The added element.

     * @throws AddressingException if an error occurs.
     */
    public SOAPElement write(SOAPElement parent, QName name)
            throws AddressingException;

}
