/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: AddressingProperties.java,v 1.12 2006/06/05 18:35:22 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */
package javax.xml.ws.addressing;

import javax.xml.namespace.QName;
import java.util.Map;

/**
 * This class is an abstraction of the Message Addressing Properties defined in
 * <b>WS-Addressing</b> specification.
 *
 * <p><p>Each Addressing Property can be initialized with a setXXX method and obtained
 * using a corresponding getXXX method. Each setXXX method also requires the Addressing
 * Property to be stored in the underlying map with it's QName as the key and it's actual
 * value as value of the key.
 *
 * <p><p>Each instance is associated with a particular <b>WS-Addressing</b> schema whose 
 * namespace URI is returned by its <code>getNamespaceURI</code> method.
 *
 * <p><p>The namespace of each key in the underlying map must match this URI and the
 * local names of all the keys must be exactly the names of the Message Addressing Properties 
 * defined in that version of the <b>WS-Addressing</b> specification.
 *
 * <p><p>Each value in the underlying type must be an instance of
 * <a href="AddressingType.html">AddressingType</a> whose <b>WS-Addressing</b> version
 * (determined by its <code>getNamespaceURI</code>) method must match the <b>WS-Addressing</b>
 * version associated with the <code>AddressingProperties</code>.
 * <p>
 * A new instance of <code>AddressingProperties</code> is created as:
 * <p><p>
 * <pre>
 * AddressingBuilder.newInstance().newAddressingProperties();</pre>
 * <p>
 * 
 * @author JAX-WSA Development Team
 * @version JAX-WSA 1.0
 */
public interface AddressingProperties extends 
	AddressingType, Map<QName, AddressingType> {

    /**
     * The accessor for the <b>To</b> property.
     *
     * @return The value of the property.
     */
    public AttributedURI getTo();

    /**
     * The mutator for the <b>To</b> property.
     *
     * @param iri The new value of the property.
     */
    public void setTo(AttributedURI iri);

    /**
     * The mutator for the <b>To</b> property.
     *
     * @param iri The new value of the property.
     */
    public void setTo(String iri);

    /**
     * The accessor for the <b>Action</b> property.
     *
     * @return The value of the property.
     */
    public AttributedURI getAction();

    /**
     * The mutator for the <b>Action</b> property.
     *
     * @param iri The new value of the property.
     */
    public void setAction(AttributedURI iri);

    /**
     * The mutator for the <b>Action</b> property.
     *
     * @param iri The new value of the property.
     */
    public void setAction(String iri);

    /**
     * The accessor for the <b>MessageID</b> property.
     *
     * @return The value of the property.
     */
    public AttributedURI getMessageID();

    /**
     * The mutator for the <b>MessageID</b> property.
     *
     * @param iri The new value of the property.
     */
    public void setMessageID(AttributedURI iri);

    /**
     * The mutator for the <b>MessageID</b> property.
     *
     * @param iri The new value of the property.
     */
    public void setMessageID(String iri);

    /**
     * The accessor for the <b>RelatesTo</b> property.
     *
     * @return The value of the property.
     */
    public Relationship[] getRelatesTo();

    /**
     * The mutator for the <b>RelatatesTo</b> property.
     *
     * @param relationship The new value of the property.
     */
    public void setRelatesTo(Relationship[] relationship);

    /**
     * The accessor for the <b>ReplyTo</b> property.
     *
     * @return The value of the property.
     */
    public EndpointReference getReplyTo();

    /**
     * The mutator for the <b>ReplyTo</b> property.
     *
     * @param ref The new value of the property.
     */
    public void setReplyTo(EndpointReference ref);

    /**
     * The mutator for the <b>ReplyTo</b> property.
     *
     * @param address The address of the EndpointReference.
     */
    public void setReplyTo(String address);

    /**
     * The accessor for the <b>FaultTo</b> property.
     *
     * @return The value of the property.
     */
    public EndpointReference getFaultTo();

    /**
     * The mutator for the <b>FaultTo</b> property.
     *
     * @param ref The new value of the property.
     */
    public void setFaultTo(EndpointReference ref);

    /**
     * The mutator for the <b>FaultTo</b> property.
     *
     * @param ref The address of the EndpointReference.
     */
    public void setFaultTo(String ref);

    /**
     * The accessor for the <b>From</b> property.
     *
     * @return The value of the property.
     */
    public EndpointReference getFrom();

    /**
     * The mutator for the <b>From</b> property.
     *
     * @param ref The new value of the property.
     */
    public void setFrom(EndpointReference ref);

    /**
     * The mutator for the <b>From</b> property.
     *
     * @param ref The address of the EndpointReference.
     */
    public void setFrom(String ref);

    /**
     * Returns a reference to the value of the <b>ReferenceParameters</b>
     * property of an <code>EndpointReference</code> used to initialize this
     * <code>AddressingProperties</code>.  There will be such an 
     * <code>EndpointReference</code> when the <code>initializeAsDestination</code>
     * method or the <code>initializeAsReply</code> method is used.
     *
     * @return the <bold>ReferenceParameters</bold> property value.
     */
    public ReferenceParameters getReferenceParameters();
    
    
    /**
     * Initializes this <code>AddressingProperties</code> as a destination using the
     * given <code>EndpointReference</code> as a source.
     *
     * <p><p> The <b>To</b> property is initialized using the <b>Address</b> property
     * of the <code>EndpointReference</code> and the <b>ReferenceParameters</b> property
     * is initialized using the <b>ReferenceParameters</b> property of the
     * <code>EndpointReference</code>.
     *
     * @param source the <code>EndpointReference</code> representing the source.
     */
    public void initializeAsDestination(EndpointReference source);

    /**
     * Initialize this <code>AddressingProperties</code> as a normal reply
     * to the given message as described in the WS-Addressing Core specification.
     *
     * <p><p>The <b>ReplyTo</b>, <b>ReferenceParameters</b> from <b>ReplyTo</b>, and
     * <b>MessageID</b> property from the <code>source</code> are used to
     * initialize the <b>Address</b>, <b>ReferenceParameters</b> and <b>RelatesTo</b>
     * property respectively of the destination.
     *
     * @param source the source <code>AddressingProperties</code>
     * @throws MapRequiredException if <b>MessageID</b> or <b>ReplyTo</b> property is missing.
     */
    public void initializeAsReply(AddressingProperties source);

    /**
     * Initialize this <code>AddressingProperties</code> as a fault reply
     * to the given message as described in the WS-Addressing Core specification.
     *
     * <p><p>The <b>FaultTo</b>, <b>ReferenceParameters</b> from <b>FaultTo</b>, and
     * <b>MessageID</b> property from <code>source</code> are used to
     * initialize the <b>Address</b>, <b>ReferenceParameters</b> and <b>RelatesTo</b>
     * property respectively of the destination. <b>ReplyTo</b> property is used if
     * <b>FaultTo</b> property is missing.
     *
     * @param source the source <code>AddressingProperties</code>
     * @throws MapRequiredException if <b>MessageID</b> or <b>ReplyTo</b>, if applicable, property is missing.
     */
    public void initializeAsFault(AddressingProperties source);
}
