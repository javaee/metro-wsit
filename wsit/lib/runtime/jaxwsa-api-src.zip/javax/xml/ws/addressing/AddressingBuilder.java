/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: AddressingBuilder.java,v 1.15 2006/03/31 21:02:07 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved.
 */

package javax.xml.ws.addressing;

import javax.xml.namespace.QName;
import static javax.xml.ws.addressing.JAXWSAConstants.ADDRESSING_BUILDER_PROPERTY;
import static javax.xml.ws.addressing.JAXWSAConstants.DEFAULT_ADDRESSING_BUILDER;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.util.Properties;

/**
 * Factory for <code>AddressingElements</code>. Implementing classes must
 * supply a 0-arguments constructor.
 * <p><p>A new instance of <code> AddressingBuilder</code> is created as:
 * <p><p>
 * <pre>
 * AddressingBuilder.newInstance();</pre>
 * <p>
 *
 * @author JAX-WSA Development Team
 * @version JAX-WSA 1.0
 */
public abstract class AddressingBuilder implements AddressingType {

    /**
     * Non-public constructor.  Base class is non-instantiable.
     */
    protected AddressingBuilder() {
    }
    
    /**
     * Creates a new instance of <code>AddressingBuilder</code>. This method uses the following
     * ordered lookup procedure to determine the AddressingBuilder implementation class to load:
     *<ol>
     *  <li>Use the <code>javax.xml.ws.addressing.AddressingBuilder</code> system property.</li>
     *  <li> Use the properties file "lib/jaxwsa.properties" in the JRE directory. This
     *       configuration file is in standard <code>java.util.Properties</code> format and
     *       contains the fully qualified name of the implementation class with the key being
     *       the system property defined above. The jaxwsa.properties file is read only once
     *       by the JAXWSA implementation and it's values are then cached for future use.
     *       If the file does not exist when the first attempt is made to read from it, no
     *       further attempts are made to check for its existence. It is not possible to
     *       change the value of any property in jaxwsa.properties after it has been read
     *       for the first time.</li>
     *  <li> Use the Services API (as detailed in the JAR specification), to determine the
     *       classname. The Services API will look for a classname in the file
     *       <code>META-INF/services/javax.xml.ws.addressing.AddressingBuilder</code> in jars
     *       available to the runtime.</li>
     *  <li> Platform default AddressingBuilder instance.</li>
     *</ol>
     * Once an application has obtained a reference to a AddressingBuilder it can use it
     * to create other WS-Addressing constructs.
     */
    public static final AddressingBuilder newInstance() {
        
        ClassLoader classLoader;
        try {
            classLoader = Thread.currentThread().getContextClassLoader();
        } catch (Exception x) {
            throw new AddressingException(x.toString(), x);
        }
        
        String name = null;
        
        // Use the system property first
        try {
            name = System.getProperty(ADDRESSING_BUILDER_PROPERTY);
            if (name != null) {
                return newClass(name, classLoader);
            }
        }  catch (Exception e) {
            System.out.println("Could not create and instance of " + name +
                " trying " + DEFAULT_ADDRESSING_BUILDER);
        }
        
        // try to read from $java.home/lib/jaxwsa.properties
        try {
            String javah = System.getProperty("java.home");
            String configFile = javah + File.separator +
                "lib" + File.separator + "jaxwsa.properties";
            File f = new File(configFile);
            if (f.exists()) {
                Properties props = new Properties();
                props.load(new FileInputStream(f));
                String factoryClassName = props.getProperty(ADDRESSING_BUILDER_PROPERTY);
                return newClass(factoryClassName, classLoader);
            }
        } catch(IOException ex) {
            throw new AddressingException(ex);
        }
        
        // default builder
        return newClass(DEFAULT_ADDRESSING_BUILDER, classLoader);
    }

    /**
     * Creates an instance of the specified class using the specified
     * <code>ClassLoader</code> object.
     *
     * @exception AddressingException if the given class could not be found
     *            or could not be instantiated
     */
    private static final AddressingBuilder newClass(String className,
                                                    ClassLoader classLoader) {
        try {
            Class cls;
            if (classLoader == null) {
                cls = Class.forName(className);
            } else {
                cls = classLoader.loadClass(className);
            }
            return (AddressingBuilder)cls.newInstance();
        } catch (ClassNotFoundException x) {
            throw new AddressingException(
                "Provider " + className + " not found", x);
        } catch (Exception x) {
            throw new AddressingException(
                "Provider " + className + " could not be instantiated: " + x,
                x);
        }
    }
    
    /**
     * Returns an instance of <code>javax.ws.addressing.AttributedURI</code>
     * initialized with the given <code>URI</code>.
     *
     * @param uri the specified <code>URI</code>.
     * @return the new URI.
     */
    public abstract AttributedURI newURI(URI uri);

    /**
     * Returns an instance of <code>javax.ws.addressing.AttributedURI</code>
     * initialized with the given String.
     *
     * @param uri the specified <code>URI</code>.
     * @return the new URI.
     * @throws AddressingException when malformed URI is passed.
     */
    public abstract AttributedURI newURI(String uri);

    /**
     * Returns an instance of <code>javax.ws.addressing.AttributedQName</code>
     * initialized using the specified <code>QName</code>.
     *
     * @param name the QName.
     * @return the AttributedQName
     */
    public abstract AttributedQName newQName(QName name);

    /**
     * Returns an instance of <code>javax.ws.addressing.AttributedQName</code>
     * initialized using the specified <code>QName</code>.
     *
     * @param namespace the namespace URI.
     * @param localname the local name.
     * @return the AttributedQName
     */
    public abstract AttributedQName newQName(String namespace, String localname);

    /**
     * Returns an instance of <code>javax.ws.addressing.Relationship</code>
     * whose <bold>ID</bold> property is initialized with the given
     * <code>URI</code>.
     *
     * @param uri the specified <code>URI</code>
     * @return the new Relationship.
     */
    public abstract Relationship newRelationship(URI uri);

    /**
     * Returns an instance of <code>javax.ws.addressing.Relationship</code>
     * whose <bold>ID</bold> property is initialized with the given
     * <code>URI</code>.
     *
     * @param uri the specified <code>URI</code>
     * @return the new Relationship.
     */
    public abstract Relationship newRelationship(String uri);

    /**
     * Returns an instance of <code>javax.ws.addressing.EndpointReference</code>
     *
     * @param uri the URI used to initialize the <bold>Address</bold> property.
     * @return the new EndpointReference.
     */
    public abstract EndpointReference newEndpointReference(URI uri);

    /**
     * Returns an instance of <code>javax.ws.addressing.EndpointReference</code>
     *
     * @param uri the address used to initialize the <bold>Address</bold> property.
     * @return the new EndpointReference.
     */
    public abstract EndpointReference newEndpointReference(String uri);

    /**
     * Returns an instance of
     * <code>javax.ws.addressing.AddressingProperties</code>
     *
     * @return the new AddressingProperties.
     */
    public abstract AddressingProperties newAddressingProperties();

    /**
     * Returns an instance of
     * <code>javax.ws.addressing.AddressingConstants</code>
     * <p>
     *
     * @return The new AddressingConstants.
     */
    public abstract AddressingConstants newAddressingConstants();
}
