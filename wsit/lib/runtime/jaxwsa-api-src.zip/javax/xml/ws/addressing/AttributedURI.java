/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: AttributedURI.java,v 1.7 2006/03/31 21:02:07 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package javax.xml.ws.addressing;

import java.net.URI;
import javax.xml.namespace.QName;

/**
 * Abstraction <code>AttributedURIType</code> defined in the WS-Addressing
 * core schema.
 * <p><p>A new instance of <code>AttributedURI</code> is created as:
 * <p><p>
 * <pre>
 * AddressingBuilder.newInstance().newURI("http://example.com");</pre>
 * or<p>
 * <pre>
 * try {
 *   AddressingBuilder.newInstance().newURI(new URI("http://example.com"));
 * } catch (URISyntaxException e) { }</pre>
 * <p>
 * 
 * @author JAX-WSA Development Team
 * @since JAX-WSA 1.0
 */

public interface AttributedURI extends AddressingType, AttributeExtensible {

    /**
     * Accessor for the URI property.
     * 
     * @return the value of the property.
     */
    public URI getURI();

    /**
     * Returns the content of the underlying URI as a String. The extensiblity
     * attributes may be ignored during the conversion.
     *
     * @return the String form of the underlying URI.
     */
    public String toString();
}
