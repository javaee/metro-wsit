/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: ActionNotSupportedException.java,v 1.6 2006/06/07 23:52:49 arungupta Exp $
 * 
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package javax.xml.ws.addressing;

import javax.xml.namespace.QName;

/**
 * This exception is thrown when the <b>action</b> message addressing property
 * in the message is not supported at an endpoint.
 * 
 * @author JAX-WSA Development Team
 * @since JAX-WSA 1.0
 */

public class ActionNotSupportedException extends AddressingException {

    static {
        fMessage = ac.getActionNotSupportedText();
    }
    
    private String action;
    
    /**
     * Overrides <code>AddressingException</code> default constructor. Thrown
     * when the <b>action</b> poperty in the message is not supported at this
     * endpoint.
     */
    protected ActionNotSupportedException() {
        super();
    }
    
    /**
     * Overrides <code>AddressingException(String)</code> constructor. Thrown
     * when the <b>action</b> poperty in the message is not supported at this
     * endpoint.
     * 
     * @param action
     *            the unsupported action
     */
    public ActionNotSupportedException(String action) {
        super(String.format(fMessage, action));
        
        this.action = action;
    }
    
    /**
     * @return the unsupported action
     */
    public String getAction() {
        return action;
    }
    
    /**
     * Return the Subcode required by the <b>WS-Addressing</b> specification.
     */
    public QName getSubcode() {
        return ac.getActionNotSupportedQName();
    }
}
