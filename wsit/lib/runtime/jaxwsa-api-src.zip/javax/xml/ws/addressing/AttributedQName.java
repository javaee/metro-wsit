/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: AttributedQName.java,v 1.8 2006/04/13 21:15:38 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package javax.xml.ws.addressing;

import javax.xml.namespace.QName;

/**
 * Abstraction of <code>AttributedQNameType</code> defined in the WS-Addressing
 * core schema.
 * <p><p>A new instance of <code>AttributedQName</code> is created as:
 * <p><p>
 * <pre>
 * AddressingBuilder.newInstance().newQName("http://example.org", "name"); </pre>
 * or<p>
 * <pre>
 * AddressingBuilder.newInstance().newQName(new QName("http://example.org", "name"));</pre>
 *
 * @author JAX-WSA Development Team
 * @since JAX-WSA 1.0
 */
public interface AttributedQName extends AddressingType, AttributeExtensible {
    /**
     * The accessor for the QName property.
     * 
     * @return the value of the property.
     */
    public QName getQName();

    /**
     * Returns the content of the underlying QName as a String. The extensiblity
     * attributes may be ignored during the conversion.
     *
     * @return the String form of the underlying QName.
     */
    public String toString();

}
