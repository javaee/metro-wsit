/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: SOAPAddressingBuilder.java,v 1.7 2006/04/03 22:03:07 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package javax.xml.ws.addressing.soap;
import javax.xml.ws.addressing.AddressingBuilder;


/**
 * Factory for <code>AddressingElements</code> that can be read from and
 * written to <code>SOAPMessages</code>. Implementing classes must
 * supply a 0-arguments constructor. Each method must return an instance of
 * <code>SOAPAddressingElement</code> except the <code>newInstance</code>,
 * <code>newAddressingProperties</code> and <code>newAddressingConstants</code> method.
 * <code>newAddressingProperties</code> return an instance of
 * <code>SOAPAddressingProperties</code>.
 * 
 * @author JAX-WSA Development Team
 * @version JAX-WSA 1.0
 */
public abstract class SOAPAddressingBuilder extends AddressingBuilder {
}
