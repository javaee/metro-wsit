/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: AttributeExtensible.java,v 1.5 2006/03/30 00:28:07 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package javax.xml.ws.addressing;

import java.util.Map;

import javax.xml.namespace.QName;

/**
 * This interface is implemented by classes that need to expose a
 * <code>Map<QName, String></code> of Attributes. It is used to represent
 * Addressing classes that support extensibility attributes.
 * 
 * @author JAX-WSA Development Team
 * @since JAX-WSA 1.0
 */
public interface AttributeExtensible {

    /**
     * Returns an unmodifiable <code>Map</code> representing the attributes of
     * an addressing element. Additions to the map are made through the
     * <code>addElement</code> method.
     * 
     * @return The unmodifiable <code>Map<QName, String></code> of
     *         attributes. Must return <code>null</code> if the implementing
     *         class does not support an attribute Map.
     */
    public Map<QName, String> getAttributes();

    /**
     * This method allows an arbitrary attribute, that do not belong
     * to the WS-Addressing namespace, to be added to the underlying
     * object implementing this interface. The name value/pair must be visible
     * in every <code>Map</code> that has been returned or will be returned by calls
     * to the <code>getAttribute</code> method.
     * 
     * @param name the name of the attribute to be added.
     * @param value the value of the attribute to be added
     * @throws AddressingException
     *             if the <code>name</code> parameter belongs to the WS-Addressing
     *             namespace.
     */
    public void addAttribute(QName name, String value) throws AddressingException;
}
