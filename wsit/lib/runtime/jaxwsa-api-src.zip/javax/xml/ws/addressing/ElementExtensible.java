/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: ElementExtensible.java,v 1.9 2006/03/30 00:28:07 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */
package javax.xml.ws.addressing;

import java.util.List;

/**
 * ElementExtensible is implemented by classes exposing a <code>List</code> of
 * <code>SOAPElements</code>. Used to represent addressing classes that
 * support collections of arbitrary XML Elements.
 * 
 * @author JAX-WSA Development Team
 * @since JAX-WSA 1.0
 */
public interface ElementExtensible {

    /**
     * Returns and unmodifiable <code>List</code> representing the child
     * elements of an addressing element. All Additions to the <code>List</code>
     * are made through the <code>addElement</code> method.
     * 
     * @return The unmodifiable <code>Collection</code>. Must return
     *         <code>null</code> if the implementing class does not support an
     *         element collection.
     */
    public List<Object> getElements();

    /**
     * Adds the specified element to the end of the list. It must be visible in every
     * <code>Collection</code> that has been returned or will be returned by
     * calls to the <code>getElements</code> method.
     * 
     * @param element the element to be added.
     * @throws AddressingException
     *             if the implementing class does not support an Element List.
     */

    public void addElement(Object element);
    
    /**
     * Removes the specified element.
     *
     * @param element
     *      The element to remove.
     * @return 
     *      <code>true</code> if the element exists in the original collection
     *      <code>false</code> otherwise.
     */
    public boolean removeElement(Object element);
}
