/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: Relationship.java,v 1.7 2006/03/31 21:02:07 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package javax.xml.ws.addressing;

import java.net.URI;

/**
 * This class is an abstraction of the <b>RelatesToType</b> defined by WS-Addressing
 * schema. Includes an ID property that references the MessageID of the related
 * message and a Type property corresponding to the <b>RelationshipType</b>
 * attribute of the <b>RelatesToType</b>. Implementing classes must supply a single
 * argument constructor with parameter type <code>java.net.URI</code>, which is used to
 * initialize the <b>ID</b> property.
 * 
 * <p><p>A new instance of <code>Relationship</code> is created as:
 * <p><p>
 * <pre>
 * AddressingBuilder.newInstance().newRelationship("http://example.com");</pre>
 * or<p>
 * <pre>
 * try {
 *   AddressingBuilder.newInstance().newRelationship(new URI("http://example.com"));
 * } catch (URISyntaxException e) { }</pre>
 * <p>
 * @author JAX-WSA Development Team
 * @since JAX-WSA 1.0
 */
public interface Relationship extends AttributeExtensible {
    /**
     * The accessor for the <b>ID</b> property.
     * 
     * @return The value of the property.
     */
    public URI getID();

    /**
     * The accessor for the <b>Type</b> property.
     * <p>
     * The return value must be the same as the value of the attribute in the Map returned by
     * <code>getAttributes</code> with name <code>wsa:RelationshipType</code>. For
     * <b>WS-Addressing</b> versions where the data type of this attribute is 
     * <i>xsd:anyURI</i>, the <code>toString</code> value of the URI is returnd.
     * 
     * @return the value of the property.
     */
    public String getType();

    /**
     * The mutator for the <b>Type</b> property. The default value is
     * <code>javax.ws.addressing.Constants.WSA_REPLY_TYPE</code>.
     * 
     * @param type the value to set.
     */
    public void setType(String type);
}
