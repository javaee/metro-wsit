/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: InvalidMapException.java,v 1.7 2006/03/30 00:28:07 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package javax.xml.ws.addressing;

import javax.xml.namespace.QName;

/**
 * This exception is thrown when a message addressing property cannot be
 * processed at the receiving side.
 * 
 * @author JAX-WSA Development Team
 * @since JAX-WSA 1.0
 */
public class InvalidMapException extends AddressingException {

    static {
        fMessage = ac.getInvalidMapText();
    }
    
    private QName name;
    private QName subsubcode;

    /**
     * Fault subcode when an invalid address is specified.
     */
    public static final QName INVALID_ADDRESS_SUBCODE = new QName(ac.getNamespaceURI(), "InvalidAddress",
                                                                  ac.getNamespacePrefix());

    /**
     * Fault subcode when an invalid header was expected to be EndpointReference but was not valid.
     */
    public static final QName INVALID_EPR = new QName(ac.getNamespaceURI(), "InvalidEPR", ac.getNamespacePrefix());

    /**
     * Fault subcode when greater than expected number of the specified header is received.
     */
    public static final QName INVALID_CARDINALITY = new QName(ac.getNamespaceURI(), "InvalidCardinality",
                                                              ac.getNamespacePrefix());

    /**
     * Fault subcode when an invalid header was expected to be EndpointReference but did not contain address.
     */
    public static final QName MISSING_ADDRESS_IN_EPR = new QName(ac.getNamespaceURI(), "MissingAddressInEPR",
                                                                 ac.getNamespacePrefix());

    /**
     * Fault subcode when a header contains a message id that was a duplicate of one already received.
     */
    public static final QName DUPLICATE_MESSAGEID = new QName(ac.getNamespaceURI(), "DuplicateMessageID",
                                                              ac.getNamespacePrefix());

    /**
     * Fault subcode when <code>Action</code> and <code>SOAPAction</code> for the mesage did not match.
     */
    public static final QName ACTION_MISMATCH = new QName(ac.getNamespaceURI(), "ActionMismatch",
                                                          ac.getNamespacePrefix());

    /**
     * Overrides <code>AddressingException</code> default constructor. Thrown
     * when a message addressing property cannot be processed.
     */
    protected InvalidMapException() {
    }

    /**
     * Overrides <code>AddressingException(String)</code> constructor Thrown
     * when a message addressing property cannot be processed.
     *
     * @param name
     *            the QName of the root element of the offending header
     */
    public InvalidMapException(QName name, QName subsubcode) {
        super(String.format(fMessage, name, subsubcode));
        
        this.name = name;
        this.subsubcode = subsubcode;
    }

    /**
     * Return the Subcode required by the <b>WS-Addressing</b> specification.
     */
    public QName getSubcode() {
        return ac.getInvalidMapQName();
    }
    
    public QName getMapQName() {
        return name;
    }
    
    public QName getSubsubcode() {
        return subsubcode;
    }
}
