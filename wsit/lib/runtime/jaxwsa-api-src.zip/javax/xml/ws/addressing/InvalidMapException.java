/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: InvalidMapException.java,v 1.9 2006/07/28 23:36:14 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package javax.xml.ws.addressing;

import javax.xml.namespace.QName;

/**
 * This exception is thrown when a message addressing property cannot be
 * processed at the receiving side.
 * 
 * @author JAX-WSA Development Team
 * @since JAX-WSA 1.0
 */
public class InvalidMapException extends AddressingException {

    static {
        fMessage = ac.getInvalidMapText();
    }
    
    private QName name;
    private QName subsubcode;

    /**
     * Fault subsubcode when an invalid address is specified.
     */
    public static final QName INVALID_ADDRESS_SUBCODE = new QName(ac.getNamespaceURI(), "InvalidAddress",
                                                                  ac.getNamespacePrefix());

    /**
     * Fault subsubcode when an invalid header was expected to be EndpointReference but was not valid.
     */
    public static final QName INVALID_EPR = new QName(ac.getNamespaceURI(), "InvalidEPR", ac.getNamespacePrefix());

    /**
     * Fault subsubcode when greater than expected number of the specified header is received.
     */
    public static final QName INVALID_CARDINALITY = new QName(ac.getNamespaceURI(), "InvalidCardinality",
                                                              ac.getNamespacePrefix());

    /**
     * Fault subsubcode when an invalid header was expected to be EndpointReference but did not contain address.
     */
    public static final QName MISSING_ADDRESS_IN_EPR = new QName(ac.getNamespaceURI(), "MissingAddressInEPR",
                                                                 ac.getNamespacePrefix());

    /**
     * Fault subsubcode when a header contains a message id that was a duplicate of one already received.
     */
    public static final QName DUPLICATE_MESSAGEID = new QName(ac.getNamespaceURI(), "DuplicateMessageID",
                                                              ac.getNamespacePrefix());

    /**
     * Fault subsubcode when <code>Action</code> and <code>SOAPAction</code> for the mesage did not match.
     */
    public static final QName ACTION_MISMATCH = new QName(ac.getNamespaceURI(), "ActionMismatch",
                                                          ac.getNamespacePrefix());

    /**
     * Fault subsubcode when the only address supported is the anonymous address.
     */
    public static final QName ONLY_ANONYMOUS_ADDRESS_SUPPORTED = new QName(ac.getNamespaceURI(), "OnlyAnonymousAddressSupported",
                                                          ac.getNamespacePrefix());

    /**
     * Fault subsubcode when anonymous address is not supported.
     */
    public static final QName ONLY_NON_ANONYMOUS_ADDRESS_SUPPORTED = new QName(ac.getNamespaceURI(), "OnlyNonAnonymousAddressSupported",
                                                          ac.getNamespacePrefix());

    /**
     * Overrides <code>AddressingException</code> default constructor. Thrown
     * when a message addressing property cannot be processed.
     */
    protected InvalidMapException() {
    }

    /**
     * Thrown when a message addressing property cannot be processed.
     *
     * @param name the QName of the root element of the offending header
     * @param subsubcode QName of the subsubcode defined by the <b>WS-Addressing</b> specification.
     */
    public InvalidMapException(QName name, QName subsubcode) {
        super(String.format(fMessage, name, subsubcode));
        
        this.name = name;
        this.subsubcode = subsubcode;
    }

    /**
     * Return the QName of the subcode required by the <b>WS-Addressing</b> specification.
     *
     * @return QName of the subcode representing this exception.
     */
    public QName getSubcode() {
        return ac.getInvalidMapQName();
    }

    /**
     * Returns the QName of the root element of the offending header.
     *
     * @return QName of the root element of the offending header
     */
    public QName getMapQName() {
        return name;
    }

    /**
     * Returns the QName of the subsubcode defined by the <b>WS-Addressing</b> specification.
     * 
     * @return QName of the subsubcode representing this exception.
     */
    public QName getSubsubcode() {
        return subsubcode;
    }
}
