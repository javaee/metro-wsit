/*
 The contents of this file are subject to the terms
 of the Common Development and Distribution License
 (the "License").  You may not use this file except
 in compliance with the License.
 
 You can obtain a copy of the license at
 https://jwsdp.dev.java.net/CDDLv1.0.html
 See the License for the specific language governing
 permissions and limitations under the License.
 
 When distributing Covered Code, include this CDDL
 HEADER in each file and include the License file at
 https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 add the following below this CDDL HEADER, with the
 fields enclosed by brackets "[]" replaced with your
 own identifying information: Portions Copyright [yyyy]
 [name of copyright owner]
*/
/*
 $Id: AddressingBuilderFactory.java,v 1.6 2006/06/26 16:58:01 arungupta Exp $

 Copyright (c) 2006 Sun Microsystems, Inc.
 All rights reserved.
*/

package javax.xml.ws.addressing;

import sun.misc.Service;

import static javax.xml.ws.addressing.JAXWSAConstants.ADDRESSING_BUILDER_FACTORY_PROPERTY;
import static javax.xml.ws.addressing.JAXWSAConstants.DEFAULT_ADDRESSING_BUILDER_FACTORY;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Iterator;

/**
 * Factory for <code>AddressingBuilder</code>.
 *
 * <p><p>A new instance of <code>AddressingBuilderFactory</code> is created as:
 * <p><p>
 * <pre>
 * AddressingBuilderFactory.newInstance();</pre>
 * <p>
 * <p><p>A new instance of <code>AddressingBuilder</code> is created as:
 * <p><p>
 * <pre>
 * AddressingBuilderFactory.newInstance().newAddressingBuilder();</pre>
 * <p>
 *
 * @author JAX-WSA Development Team
 * @version JAX-WSA 1.0
 */
public abstract class AddressingBuilderFactory {
    /**
     * Creates a new instance of <code>AddressingBuilderFactory</code>. This method
     * uses the following ordered lookup procedure to determine the AddressingBuilderFactory
     * implementation class to load:
     *<ol>
     *  <li> Use the <code>javax.xml.ws.addressing.AddressingBuilderFactory</code> system property.</li>
     *  <li> Use the properties file "lib/jaxwsa.properties" in the JRE directory. This configuration
     *       file is in standard java.util.Properties format and contains the fully qualified name of
     *       the implementation class with the key being the system property defined above. The
     *       jaxwsa.properties file is read only once by the JAXWSA implementation and it's values are
     *       then cached for future use. If the file does not exist when the first attempt is made to
     *       read from it, no further attempts are made to check for its existence. It is not possible
     *       to change the value of any property in jaxwsa.properties after it has been read for the
     *       first time.</li>
     *  <li> Use the Services API (as detailed in the JAR specification), to determine the
     *       class to be loaded. The Services API will look for a classname in the file
     *       <code>META-INF/services/javax.xml.ws.addressing.AddressingBuilderFactory</code> in jars
     *       available to the runtime.
     *  <li> Platform default <code>AddressingBuilderFactory</code> instance.</li>
     *</ol>
     * Once an application has obtained a reference to a AddressingBuilderFactory it can use it
     * to create AddressingBuilder for the supported set of namespaces.
     */
    public static final AddressingBuilderFactory newInstance() {
        ClassLoader loader;
        try {
            loader = Thread.currentThread().getContextClassLoader();
        } catch (Exception x) {
            throw new AddressingException(x.toString(), x);
        }

        AddressingBuilderFactory factory = readFromJreLib(loader);
        if (factory != null)
            return factory;

        Iterator iter = Service.providers(AddressingBuilderFactory.class, loader);
        if (iter.hasNext())
            return (AddressingBuilderFactory)iter.next();

        // default builder
        return newClass(DEFAULT_ADDRESSING_BUILDER_FACTORY, loader);
    }

    /**
     * Creates a new AddressingBuilder for W3C WS-Addressing namespace.
     *
     * @return W3C WS-Addressing AddressingBuilder
     */
    public abstract AddressingBuilder newAddressingBuilder();

    /**
     * Creates a new AddressingBuilder for the given WS-Addressing namespace.
     *
     * @param namespace Namespace of WS-Addressing
     * @return AddressingBuilder for the given namespace
     * @exception AddressingException if the namespace is not supported
     */
    public abstract AddressingBuilder newAddressingBuilder(String namespace);

    /**
     * Checks to see if this factory can create an AddressingBuilder for the given
     * namespace.
     *
     * @param namespace Namespace of WS-Addressing
     * @return true if an AddressingBuilder can be created for the given namespace.
     */
    public abstract boolean isSupported(String namespace);

    /**
     * Creates an instance of the specified class using the specified
     * <code>ClassLoader</code> object.
     *
     * @exception AddressingException if the given class could not be found
     *            or could not be instantiated
     */
    private static final AddressingBuilderFactory newClass(String className,
                                                           ClassLoader classLoader) {
        try {
            Class klass;
            if (classLoader == null) {
                klass = Class.forName(className);
            } else {
                klass = classLoader.loadClass(className);
            }
            return (AddressingBuilderFactory)klass.newInstance();
        } catch (ClassNotFoundException x) {
            throw new AddressingException(
                "Provider " + className + " not found", x);
        } catch (Exception x) {
            throw new AddressingException(
                "Provider " + className + " could not be instantiated: " + x,
                x);
        }
    }

    /**
     try to read from $java.home/lib/jaxwsa.properties
     "java.home" points to ${JAVA_HOME}/jre
    */
    private static final AddressingBuilderFactory readFromJreLib(ClassLoader loader) {
        try {
            String javah = System.getProperty("java.home");
            String configFile = javah + File.separator +
                "lib" + File.separator + "jaxwsa.properties";
            File f = new File(configFile);
            if (f.exists()) {
                Properties props = new Properties();
                props.load(new FileInputStream(f));
                if (!props.isEmpty()) {
                    String factoryClassName = props.getProperty(ADDRESSING_BUILDER_FACTORY_PROPERTY);
                    return newClass(factoryClassName, loader);
                }
            }
        } catch(IOException ex) {
            throw new AddressingException(ex);
        }

        return null;
    }

}
