/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: AddressingConstants.java,v 1.14 2006/03/31 21:02:07 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package javax.xml.ws.addressing;

import javax.xml.namespace.QName;

/**
 * This definition of constants pertaining to a specific version of
 * WS-Addressing.
 * <p><p>A new instance of <code>AddressingConstants</code> is created as:
 * <p><p>
 * <pre>
 * AddressingBuilder.newInstance().newAddressingConstants();</pre>
 * <p>
 *
 * @author JAX-WSA Development Team
 * @version JAX-WSA 1.0
 */
public interface AddressingConstants {
    /**
     * The namespace identifier defined by the WS-Addressing Core schema.
     */
    String getNamespaceURI();
    
    /**
     * The Prefix associated with the WS-Addressing namespace.
     */
    String getNamespacePrefix();
    
    /**
     * The namespace identifier defined by the WS-Addressing WSDL Binding schema.
     */
    String getWSDLNamespaceURI();
    
    /**
     * The prefix associated with the WS-Addressing WSDL Binding schema.
     */
    String getWSDLNamespacePrefix();
    
    /**
     * The QName of the WSDL extensiblity element.
     */
    QName getWSDLExtensibilityQName();
    
    /**
     * The QName of the wsaw:Action element.
     */
    QName getWSDLActionQName();
    
    /**
     * The value of "anonymous" URI.
     */
    String getAnonymousURI();
    
    /**
     * The value of "none" URI.
     */
    String getNoneURI();
    
    /**
     * The QName of the <b>From</b> addressing header.
     */
    QName getFromQName();
    
    /**
     * The QName of the <b>To</b> addressing header.
     */
    QName getToQName();
    
    /**
     * The QName of the <b>ReplyTo</b> addressing header.
     */
    QName getReplyToQName();
    
    /**
     * The QName of the <b>FaultTo</b> addressing header.
     */
    QName getFaultToQName();
    
    /**
     * The QName of the <b>Action</b> addressing header.
     */
    QName getActionQName();
    
    /**
     * The QName of the <b>MessageID</b> addressing header.
     */
    QName getMessageIDQName();
    
    /**
     * The QName of the <b>RelatesTo</b> addressing header.
     */
    QName getRelatesToQName();
    
    /**
     * The QName of the <b>Relationship</b> attribute.
     */
    QName getRelationshipTypeQName();

    /**
     * The value of the <b>RelationshipType</b> attribute indicating a reply
     * to the related message.
     */
    String getRelationshipReplyName();

    /**
     * The QName of the <b>Metadata</b> in <b>EndpointReference</b>.
     */
    QName getMetadataQName();
    
    /**
     * The QName of the <b>Address</b> in <b>EndpointReference</b>.
     */
    QName getAddressQName();
    
    /**
     * The package name of the implementation.
     */
    String getPackageName();
    
    /**
     * The QName of the reference parameter marker
     */
    QName getIsReferenceParameterQName();
    
    /**
     * The QName of the <b>Invalid Message Addressing Property</b> fault subcode.
     */
    QName getInvalidMapQName();
    
    /**
     * The QName of the <b>Message Addressing Property Required</b> fault subcode.
     */
    QName getMapRequiredQName();
    
    /**
     * The QName of the <b>Destination Unreachable</b> fault subcode.
     */
    QName getDestinationUnreachableQName();
    
    /**
     * The QName of the <b>Action Not Supported</b> fault subcode.
     */
    QName getActioNotSupportedQName();
    
    /**
     * The QName of the <b>Endpoint Unavailable</b> fault subcode.
     */
    QName getEndpointUnavailableQName();
    
    /**
     * The default fault <b>Action</b>.
     */
    String getDefaultFaultAction();

    /**
     * The descriptive text for the fault with <b>Action Not Supported</b> fault subcode.
     *  
     * @return the descriptive text
     */
    String getActionNotSupportedText();

    /**
     * The descriptive text for the fault with <b>Destination Unreachable</b> fault subcode.
     *
     * @return the descriptive text
     */
    String getDestinationUnreachableText();

    /**
     * The descriptive text for the fault with <b>Endpoint Unavailable</b> fault subcode.
     *
     * @return the descriptive text
     */
    String getEndpointUnavailableText();

    /**
     * The descriptive text for the fault with <b>Invalid Message Addressing Property</b> fault subcode.
     *
     * @return the descriptive text
     */
    String getInvalidMapText();

    /**
     * The descriptive text for the fault with <b>Message Addressing Property Required</b> fault subcode.
     *
     * @return the descriptive text
     */
    String getMapRequiredText();

    /**
     * The QName of the fault detail element.
     *
     * @return QName of the fault detail
     */
    QName getFaultDetailQName();
}

