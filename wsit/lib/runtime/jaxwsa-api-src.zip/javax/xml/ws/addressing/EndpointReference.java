/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: EndpointReference.java,v 1.8 2006/06/16 18:47:06 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */
package javax.xml.ws.addressing;

import javax.xml.namespace.QName;

/**
 * This class is an abstraction of <code>EndpointReference</code>. It contains <b>URI</b>,
 * <b>ReferenceParameters</b> and <b>Metadata</b> properties. A new instance of <code>
 * EndpointReference</code> is created as:
 * <p><p>
 * <pre>
 * AddressingBuilder.newInstance().newEndpointReference("http://example.com");</pre>
 * or<p>
 * <pre>
 * try {
 *   AddressingBuilder.newInstance().newEndpointReference(new URI("http://example.com"));
 * } catch (URISyntaxException e) { }</pre>
 * <p>
 * 
 * @author JAX-WSA Development Team
 * @since JAX-WSA 1.0
 */
public interface EndpointReference extends 
        AddressingType, AttributeExtensible, ElementExtensible {

    /** 
     * The accessor for the <b>Address</b> property.
     *
     * @return the value of the property.
     */
    public AttributedURI getAddress();

    /**
     * The accessor for the <b>ReferenceParameters</b> property.
     *
     * @return the value of the property.
     */
    public ReferenceParameters getReferenceParameters();

    /**
     * A convenience method to add a reference parameter with a String value.
     *
     * @param name name of the reference parameter
     * @param value value of the reference parameter
     */
    public void addReferenceParameter(QName name, String value);

    /**
     * A convenience method to get a reference parameter with a String value.
     *
     * @param name name of the reference parameter
     * @return value of the reference parameter
     */
    public String getReferenceParameter(QName name);

    /**
     * The accessor for the <b>Metadata</b> property.
     *
     * @return the value of the property.
     */
    public Metadata getMetadata();

    /**
     * The accessor method to obtain interface or port type this EndpointReference identifies.
     *
     * @return QName of the WSDL 1.1 portType or WSDL 2.0 interface
     */
    public QName getInterfaceName();

    /**
     * The accessor method to obtain service this EndpointReference belongs to.
     *
     * @return QName of the WSDL 1.1 or WSDL 2.0 service
     */
    public QName getServiceName();

    /**
     * The accessor method to obtain endpoint or port this EndpointReference identifies.
     *
     * @return QName of the WSDL 1.1 port or WSDL 2.0 endpoint
     */
    public QName getEndpointName();

    /**
     * Returns the content of the <b>Address</b> as a String. The
     * <b>ReferenceParameter</b> and <b>Metadata</b> may be ignored
     * during the conversion.
     *
     * @return the String form of this <code>EndpointReference</code>.
     */
    public String toString();
}
