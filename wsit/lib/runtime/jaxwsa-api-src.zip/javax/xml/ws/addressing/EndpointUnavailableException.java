/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: EndpointUnavailableException.java,v 1.9 2005/12/07 13:34:48 arungupta Exp $
 * 
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package javax.xml.ws.addressing;

import javax.xml.namespace.QName;

/**
 * This exception is thrown when endpoint is unable to process the message at
 * this time either due to some transient issue or a permanent failure.
 * 
 * @author JAX-WSA Development Team
 * @since JAX-WSA 1.0
 */
public class EndpointUnavailableException extends AddressingException {
    
    static {
        fMessage = ac.getEndpointUnavailableText();
    }
    
    /**
     * Overrides <code>AddressingException</code> default constructor. Thrown
     * when the endpoint is unable to process the message at this time either
     * due to some transient issue or a permanent failure.
     */
    public EndpointUnavailableException() {
        super();
    }

    /**
     * Overrides <code>AddressingException(String)</code> constructor. Thrown
     * when the endpoint is unable to process the message at this time either
     * due to some transient issue or a permanent failure.
     *
     * @param retryAfter
     *            suggested minimum duration in milliseconds to wait beofre
     *            retransmitting the message
     * @param problemIRI
     *            the IRI that caused the problem
     */
    public EndpointUnavailableException(int retryAfter, String problemIRI) {
        super(String.format(fMessage, retryAfter, problemIRI));
    }

    /**
     * Return the Subcode required by the <b>WS-Addressing</b> specification.
     *
     * @return QName of the subcode
     */
    public QName getSubcode() {
        return ac.getEndpointUnavailableQName();
    }
}
