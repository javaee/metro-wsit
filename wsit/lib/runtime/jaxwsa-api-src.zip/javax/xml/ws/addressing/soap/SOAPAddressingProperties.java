/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: SOAPAddressingProperties.java,v 1.7 2005/10/24 22:26:24 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package javax.xml.ws.addressing.soap;

import javax.xml.soap.SOAPMessage;
import javax.xml.ws.addressing.AddressingException;
import javax.xml.ws.addressing.AddressingProperties;


/**
 * Subinterface of <code>AddressingProperties</code> includes methods that
 * read and write the Message Addressing Properties to a <code>SOAPMessage</code>.
 * All individual properties must implement <code>SOAPAddressingElement</code>.
 * 
 * @author JAX-WSA Development Team
 * @version JAX-WSA 1.0
 */
public interface SOAPAddressingProperties extends AddressingProperties {
    /**
     * Initialize the <code>AddressingProperties</code> object by reading the
     * AddressingHeaders on the given <code>SOAPMessage</code>.
     *
     * @param message The message to be read
     * @throws AddressingException if an error occurs.
     */
    public void readHeaders(SOAPMessage message) throws AddressingException;

    /**
     * Write the properties of this <code>AddressingProperties</code> object 
     * as Addressing Headers on a <code>SOAPMessage</code>.
     *
     * @param message The message to be written to.
     * @throws AddressingException if an error occurs.
     */
    public void writeHeaders(SOAPMessage message) throws AddressingException;

    /**
     * Sets mustUnderstand attribute on all WS-Addressing header blocks
     *
     * @param mu value of mustUnderstand
     */
    public void setMu(boolean mu);
    
}
