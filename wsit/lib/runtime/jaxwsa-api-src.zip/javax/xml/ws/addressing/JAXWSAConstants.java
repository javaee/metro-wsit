/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: JAXWSAConstants.java,v 1.14 2006/03/30 00:28:07 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package javax.xml.ws.addressing;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPConstants;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPException;

/**
 * Static constants for the <code>javax.xml.ws.addressing</code> package.
 * 
 * <p>
 * <b>Note</b>: This class has changed since Early Draft 1. All the version-specific
 * WS-Addressing constants now exist in <a href="AddressingConstants.html">AddressingConstants</a>.
 * 
 * @author JAX-WSA Development Team
 * @since JAX-WSA 1.0
 */
public class JAXWSAConstants {

    /**
     * Private constructor.  There is no need to create an instance of this class.
     */
    private JAXWSAConstants() {
    }

    /**
     * A constant representing the property used to lookup the
     * name of a <code>AddressingBuilderFactory</code> implementation 
     * class.
     */
    public static final String ADDRESSING_BUILDER_PROPERTY = "javax.xml.ws.addressing.AddressingBuilder";

    /**
     * A constant representing the name of the default 
     * <code>AddressingBuilder</code> implementation class.
     */
    public static final String DEFAULT_ADDRESSING_BUILDER = "com.sun.xml.ws.addressing.AddressingBuilderImpl";
    
    /**
     * Name of the namespace defined by SOAP 1.1.
     */
    public static final String SOAP11_NAMESPACE_NAME = SOAPConstants.URI_NS_SOAP_1_1_ENVELOPE;

    /**
     * Name of the namespace defined by SOAP 1.2.
     */
    public static final String SOAP12_NAMESPACE_NAME = SOAPConstants.URI_NS_SOAP_1_2_ENVELOPE;

    /**
     * Name of Sender fault defined by SOAP 1.1.
     */
    public static final QName SOAP11_SENDER_QNAME = new QName(
            SOAP11_NAMESPACE_NAME, "Client");

    /**
     * Name of Receiver fault defined by SOAP 1.1.
     */
    public static final QName SOAP11_RECEIVER_QNAME = new QName(
            SOAP11_NAMESPACE_NAME, "Server");

    /**
     * Name of Sender fault defined by SOAP 1.2.
     */
    public static final QName SOAP12_SENDER_QNAME = SOAPConstants.SOAP_SENDER_FAULT;

    /**
     * Name of Receiver fault defined by SOAP 1.2.
     */
    public static final QName SOAP12_RECEIVER_QNAME = SOAPConstants.SOAP_RECEIVER_FAULT;

    /**
     * SOAP 1.1/HTTP WS-Addressing 1.0 binding id
     */
    public static final String SOAP11HTTP_ADDRESSING_BINDING = "http://schemas.xmlsoap.org/wsdl/soap/http?addressing=1.0";

    /**
     * SOAP 1.2/HTTP WS-Addressing 1.0 binding id
     */
    public static final String SOAP12HTTP_ADDRESSING_BINDING = "http://www.w3.org/2003/05/soap/bindings/HTTP/?addressing=1.0";

    /**
     * Property name to access the <code>AddressingProperties</code> in 
     * <code>javax.xml.ws.BindingProvider</code> request and response context.
     */
    public static final String CLIENT_ADDRESSING_PROPERTIES = 
            "javax.xml.ws.addressing.context";
    
    /**
     * Property name to access the inbound <code>AddressingProperties</code> in 
     * client-side <code>javax.xml.ws.handler.MessageContext</code>.
     */
    public static final String CLIENT_ADDRESSING_PROPERTIES_INBOUND = 
            "javax.xml.ws.addressing.context.inbound";
    
    /**
     * Property name to access the outbound <code>AddressingProperties</code> in 
     * client-side <code>javax.xml.ws.handler.MessageContext</code>.
     */
    public static final String CLIENT_ADDRESSING_PROPERTIES_OUTBOUND = 
            "javax.xml.ws.addressing.context.outbound";

    /**
     * Property name to access the inbound <code>AddressingProperties</code> in 
     * server-side <code>javax.xml.ws.handler.MessageContext</code>.
     */
    public static final String SERVER_ADDRESSING_PROPERTIES_INBOUND =
        "javax.xml.ws.addressing.context.inbound";
    
    /**
     * Property name to access the outbound <code>AddressingProperties</code> in 
     * server-side <code>javax.xml.ws.handler.MessageContext</code>.
     */
    public static final String SERVER_ADDRESSING_PROPERTIES_OUTBOUND =
        "javax.xml.ws.addressing.context.outbound";
    
    /**
     * Singleton instance of SOAPFactory
     */
    public static SOAPFactory SOAP_FACTORY = null;

    static {
        try {
            SOAP_FACTORY = SOAPFactory.newInstance();
        } catch (SOAPException e) {
            throw new AddressingException(e);
        }
    }

}
