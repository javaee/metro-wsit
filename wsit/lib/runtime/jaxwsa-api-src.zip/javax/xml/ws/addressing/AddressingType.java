/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: AddressingType.java,v 1.7 2006/03/30 00:28:07 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved.
 */
package javax.xml.ws.addressing;

/**
 * Interface implemented by wrappers for types defined by <b>WS-Addressing</b>.
 *
 * @author JAX-WSA Development Team
 * @version JAX-WSA 1.0
 */
public interface AddressingType {
    
    /**
     * Determines the version of <b>WS-Addressing</b> containing the definition of the this
     * type.
     * 
     * @return The targetNamespace for the <b>WS-Addressing</b> schema containing
     * the definition of this type.
     */
    public String getNamespaceURI();
}
