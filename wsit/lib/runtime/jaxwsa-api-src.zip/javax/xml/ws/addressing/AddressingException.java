/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: AddressingException.java,v 1.11 2006/06/16 19:18:07 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */
package javax.xml.ws.addressing;

import javax.xml.ws.WebServiceException;
import javax.xml.namespace.QName;

/**
 * The base class for JAX-WSA related exceptions.
 * 
 * @author JAX-WSA Development Team
 * @version JAX-WSA 1.0
 */
public class AddressingException extends WebServiceException {

    protected QName code;

    protected String reason;

    protected Object detail;
    
    protected static AddressingConstants ac = null;
    protected static String fMessage = null;
    static {
        ac = AddressingBuilderFactory.newInstance().newAddressingBuilder().newAddressingConstants();
    }
    
    /**
     * Constructs a new AddressingException with null as its detail message. The
     * cause is not initialized, and may subsequently be initialized by a call
     * to Throwable.initCause(java.lang.Throwable).
     */
    public AddressingException() {
        super();
    }

    /**
     * Constructs a new AddressingException with the specified detail message.
     * 
     * @param message
     *            the detail message (which is saved for later retrieval by the
     *            Throwable.getMessage() method).
     */
    public AddressingException(String message) {
        super(message);
    }

    /**
     * Constructs a new AddressingException with the specified detail message
     * and cause.
     * 
     * @param cause
     *            the cause (which is saved for later retrieval by the
     *            Throwable.getCause() method). (A null value is permitted, and
     *            indicates that the cause is nonexistent or unknown.)
     */
    public AddressingException(Throwable cause) {
        super(cause);
    }

    /**
     * Constructs a new AddressingException with the specified cause and a
     * detail message of (cause==null ? null : cause.toString()) (which
     * typically contains the class and detail message of cause).
     * 
     * @param message
     *            the detail message (which is saved for later retrieval by the
     *            Throwable.getMessage() method).
     * @param cause
     *            the cause (which is saved for later retrieval by the
     *            Throwable.getCause() method). (A null value is permitted, and
     *            indicates that the cause is nonexistent or unknown.)
     */
    public AddressingException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Returns the fault code.
     * 
     * @return the fault code
     */
    public QName getCode() {
        return code;
    }

    /**
     * Returns the fault subcode. Returns null if does not match a predefined
     * fault in WS-Addressing specification.
     * 
     * @return the fault subcode
     */
    public QName getSubcode() {
        return null;
    }

    /**
     * Returns the fault reason.
     * 
     * @return the fault reason
     */
    public String getReason() {
        return reason;
    }

    /**
     * Returns the fault detail.
     * 
     * @return the fault detail
     */
    public Object getDetail() {
        return detail;
    }

}
