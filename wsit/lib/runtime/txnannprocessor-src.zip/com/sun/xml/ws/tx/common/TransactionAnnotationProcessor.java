/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License).  You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * you own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 */

package com.sun.xml.ws.tx.common;

import javax.ejb.Stateful;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionManagement;
import java.lang.reflect.Method;

/**
 * Place all dependencies on javax.ejb in one file.
 */
public class TransactionAnnotationProcessor {

    enum TransactionAttributeType {
        NOT_SUPPORTED, NEVER, MANDATORY, SUPPORTS, REQUIRES_NEW, REQUIRED
    }

    static public boolean isContainerManagedEJB(Class c) {
        boolean result = false;
        TransactionManagement tm = (TransactionManagement) c.getAnnotation(TransactionManagement.class);
        if (tm != null) {
            switch (tm.value()) {
                case BEAN:
                    return false;
                case CONTAINER:
                default:
                    return true;
            }
        }

        // No TransactionManagement annotation. Default is CONTAINER for EJB.
        Stateful stateful = (Stateful) c.getAnnotation(Stateful.class);
        Stateless stateless = (Stateless) c.getAnnotation(Stateless.class);
        if (c.getAnnotation(Stateful.class) != null ||
                c.getAnnotation(Stateless.class) != null) {
            //TODO: Are there any other EJB annotations? 
            return true;
        } else {
            // servlet endpoint
            return false;
        }
    }

    /**
     * Precondition: isContainerManagedEjb(c) returned true.
     */
    static public TransactionAttributeType getTransactionAttributeDefault(Class c) {
        // defaults to REQUIRED if no annotation on class
        TransactionAttributeType result = TransactionAttributeType.REQUIRED;
        TransactionAttribute txnAttr = (TransactionAttribute) c.getAnnotation(TransactionAttribute.class);
        if (txnAttr != null) {
            result = convert(txnAttr.value());
        }
        return result;
    }

    /**
     * DefaultTxnAttr was obtained from class TransactionAttribute annotation.
     */
    static public TransactionAttributeType getEffectiveTransactionAttribute(Method m, TransactionAttributeType defaultTxnAttr) {
        TransactionAttributeType result = defaultTxnAttr;
        TransactionAttribute txnAttr = m.getAnnotation(TransactionAttribute.class);
        if (txnAttr != null) {
            result = convert(txnAttr.value());
        }
        return result;
    }

    private static TransactionAttributeType convert(javax.ejb.TransactionAttributeType e) {
        return TransactionAttributeType.valueOf(TransactionAttributeType.class, e.name());
    }
}
