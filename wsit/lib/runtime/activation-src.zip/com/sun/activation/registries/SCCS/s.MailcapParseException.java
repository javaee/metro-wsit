h33028
s 00005/00014/00020
d D 1.3 99/12/06 16:33:32 shannon 4 3
c Update copyright for SCSL release
e
s 00024/00010/00010
d D 1.2 99/11/03 11:45:43 shannon 3 1
c add missing copyrights
e
s 00000/00000/00000
d R 1.2 97/10/10 12:06:52 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 2 1 src/share/classes/com/sun/activation/registries/MailcapParseException.java
c Name history : 1 0 src/classes/com/sun/activation/registries/MailcapParseException.java
e
s 00020/00000/00000
d D 1.1 97/10/10 11:06:51 jmoore 1 0
c date and time created 97/10/10 11:06:51 by jmoore
e
u
U
f e 0
t
T
I 3
/*
 * %W% %E%
 *
D 4
 * Copyright (c) 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
E 4
I 4
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
E 4
 */

E 3
I 1
package	com.sun.activation.registries;

/**
 *	A class to encapsulate Mailcap parsing related exceptions
 */
D 3
public class	MailcapParseException
	extends		Exception
{
E 3
I 3
public class MailcapParseException extends Exception {
E 3

D 3
public	MailcapParseException()
{
E 3
I 3
    public MailcapParseException() {
E 3
	super();
D 3
}
E 3
I 3
    }
E 3

D 3
public	MailcapParseException(String inInfo)
{
E 3
I 3
    public MailcapParseException(String inInfo) {
E 3
	super(inInfo);
D 3
}

E 3
I 3
    }
E 3
}
E 1
