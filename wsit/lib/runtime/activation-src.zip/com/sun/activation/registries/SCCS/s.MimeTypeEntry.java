h12551
s 00004/00015/00031
d D 1.3 99/12/06 16:33:33 shannon 4 3
c Update copyright for SCSL release
e
s 00017/00022/00029
d D 1.2 98/01/18 00:41:59 shannon 3 1
c cleanup
e
s 00000/00000/00000
d R 1.2 97/09/05 16:25:24 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 2 1 src/share/classes/com/sun/activation/registries/MimeTypeEntry.java
c Name history : 1 0 src/classes/com/sun/activation/registries/MimeTypeEntry.java
e
s 00051/00000/00000
d D 1.1 97/09/05 16:25:23 bhc 1 0
c date and time created 97/09/05 16:25:23 by bhc
e
u
U
f e 0
t
T
I 1
/*
 * %W% %E%
I 4
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
E 4
 * 
D 3
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
E 3
I 3
D 4
 * Copyright (c) 1997-1998 Sun Microsystems, Inc. All Rights Reserved.
E 4
I 4
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
E 4
E 3
 * 
D 4
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 * 
E 4
 */

package com.sun.activation.registries;

import java.lang.*;

D 3
public class MimeTypeEntry extends Object {
    private String MIMEType;
    private String FileExtension;
E 3
I 3
public class MimeTypeEntry {
    private String type;
    private String extension;
E 3

D 3
    public MimeTypeEntry(String mime_type, String file_ext)
	{
	    MIMEType = new String(mime_type);
	    FileExtension = new String(file_ext);
	}
E 3
I 3
    public MimeTypeEntry(String mime_type, String file_ext) {
	type = mime_type;
	extension = file_ext;
    }
E 3

D 3
    public String getMIMEType()
	{
	    return MIMEType;
	}
E 3
I 3
    public String getMIMEType() {
	return type;
    }
E 3

D 3
    public String getFileExtension()
	{
	    return FileExtension;
	}
E 3
I 3
    public String getFileExtension() {
	return extension;
    }
E 3

D 3
    public String toString()
	{
	    return new String("MIMETypeEntry: " + MIMEType +
			      ", " + FileExtension);
	}
E 3
I 3
    public String toString() {
	return "MIMETypeEntry: " + type + ", " + extension;
    }
E 3
}
E 1
