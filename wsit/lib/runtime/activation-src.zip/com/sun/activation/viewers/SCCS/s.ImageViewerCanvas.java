h49759
s 00005/00017/00060
d D 1.2 99/12/06 16:33:33 shannon 3 1
c Update copyright for SCSL release
e
s 00000/00000/00000
d R 1.2 97/09/05 16:25:38 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 2 1 src/share/classes/com/sun/activation/viewers/ImageViewerCanvas.java
c Name history : 1 0 src/classes/com/sun/activation/viewers/ImageViewerCanvas.java
e
s 00077/00000/00000
d D 1.1 97/09/05 16:25:37 bhc 1 0
c date and time created 97/09/05 16:25:37 by bhc
e
u
U
f e 0
t
T
I 1
D 3
/**
E 3
I 3
/*
E 3
 * %W% %E%
I 3
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
E 3
 * 
D 3
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
E 3
I 3
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
E 3
 * 
D 3
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 *
 * @author Bart Calder
E 3
 */

package com.sun.activation.viewers;

import java.awt.*;

public class ImageViewerCanvas extends Canvas
{
  private Image canvas_image = null;
  
  /**
   * The constructor
   */
  public ImageViewerCanvas()
    {
	
    }

  /**
   * set the image
   */
  public void setImage(Image new_image)
    {
      canvas_image = new_image;
      this.invalidate();
      this.repaint();
    }
  
  /**
   * getPreferredSize
   */
  public Dimension getPreferredSize()
    {
      Dimension d = null;
      
      if(canvas_image == null)
	{
	  d = new Dimension(200, 200);
	}
      else
	d = new Dimension(canvas_image.getWidth(this), 
			  canvas_image.getHeight(this));

      return d;
    }
  /**
   * paint method
   */
  public void paint(Graphics g)
    {

      if(canvas_image != null)
	g.drawImage(canvas_image, 0, 0, this);

    }
  
}
E 1
