h46729
s 00005/00017/00103
d D 1.7 99/12/06 16:33:33 shannon 8 7
c Update copyright for SCSL release
e
s 00001/00002/00119
d D 1.6 97/12/18 13:21:57 bhc 7 6
c minor fixes for FolderView
e
s 00007/00012/00114
d D 1.5 97/12/16 14:51:03 bhc 6 5
c conform to new apis
e
s 00001/00001/00125
d D 1.4 97/12/09 10:39:37 bhc 5 4
c updated to reflect latest JAF apis
e
s 00056/00063/00070
d D 1.3 97/12/02 09:52:24 bhc 4 3
c cleaned up code
e
s 00008/00082/00125
d D 1.2 97/10/06 18:07:36 bhc 3 1
c fix IS bug, now correctly reads in all images
e
s 00000/00000/00000
d R 1.2 97/09/05 16:25:37 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 2 1 src/share/classes/com/sun/activation/viewers/ImageViewer.java
c Name history : 1 0 src/classes/com/sun/activation/viewers/ImageViewer.java
e
s 00207/00000/00000
d D 1.1 97/09/05 16:25:36 bhc 1 0
c date and time created 97/09/05 16:25:36 by bhc
e
u
U
f e 0
t
T
I 1
D 8
/**
E 8
I 8
/*
E 8
 * %W% %E%
I 8
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
E 8
 * 
D 8
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
E 8
I 8
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
E 8
 * 
D 8
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 *
 * @author Bart Calder
E 8
 */

package com.sun.activation.viewers;

import java.awt.*;
import java.io.*;
import java.beans.*;
import javax.activation.*;

D 4
public class ImageViewer extends Panel implements CommandObject 
{
E 4
I 4
public class ImageViewer extends Panel implements CommandObject {
E 4
    // UI Vars...
    private ImageViewerCanvas canvas = null;
    
    // File Vars
D 6
    private InputStream data_ins = null;
E 6
I 6
    //    private InputStream data_ins = null;
E 6
    private Image image = null;
    private DataHandler _dh = null;
    
    private boolean DEBUG = false;
    /**
     * Constructor
     */
D 4
    public ImageViewer()
	{
	    
	    // create the ImageViewerCanvas
	    canvas = new ImageViewerCanvas();
	    add(canvas);
	}
E 4
I 4
    public ImageViewer(){
	
	// create the ImageViewerCanvas
	canvas = new ImageViewerCanvas();
	add(canvas);
    }
E 4
    /**
     * Set the DataHandler for this CommandObject
     * @param DataHandler the DataHandler
     */
D 4
    public void setDataHandler( DataHandler dh )
	{
	    _dh = dh;
	    try {
		this.setInputStream( _dh.getInputStream() );
	    } catch (Exception e) { }
	    
	}
E 4
I 4
D 5
    public void initCommandContext(String verb, DataHandler dh)	{
E 5
I 5
D 6
    public void setCommandContext(String verb, DataHandler dh)	{
E 6
I 6
    public void setCommandContext(String verb, DataHandler dh)	throws IOException{
E 6
E 5
	_dh = dh;
D 6
	try {
	    this.setInputStream( _dh.getInputStream() );
	} catch (Exception e) { }
E 6
I 6
	this.setInputStream( _dh.getInputStream() );
E 6
    }
E 4
    //--------------------------------------------------------------------
    
    /**
     * Set the data stream, component to assume it is ready to
     * be read.
     */
D 4
    private void setInputStream(InputStream ins)
	{
	    MediaTracker mt = new MediaTracker(this);
D 3
	    DataInputStream dins = new DataInputStream(ins);
	    //	    int length = 0;
	    byte[] data = null; 
E 3
	    int bytes_read = 0;
D 3
	    
	    // check that we can actually read
            try {
E 3
I 3
	    byte data[] = new byte[1024];
	    ByteArrayOutputStream baos = new ByteArrayOutputStream();
E 3

D 3
//                 if(dins.available() <= 0)
//                     {
//                         System.out.println("Empty input stream");
//                     }
E 3
I 3
	    try {
		while((bytes_read = ins.read(data)) >0)
		    baos.write(data, 0, bytes_read);
		ins.close();
	    } catch(Exception e) { System.out.println(e);}
E 3

D 3
		//                length = dins.available();

		//		while(dins.available() > 0 && bytes_read != -1)
		while(bytes_read != -1)
		    {
			int chunk_length = 1024;
			//			int chunk_length = dins.available();
			byte[] chunk = new byte[chunk_length];

			bytes_read = dins.read(chunk, 0, chunk.length);
			if(bytes_read == -1)
			    break;
			try {
			    if(data == null)
				{
				    if(DEBUG)
					{
					    System.out.print("bytes_read " + bytes_read);
					    System.out.print(" chunk.length: " + chunk.length);
					}
				    data = new byte[bytes_read];
				    System.arraycopy(chunk,
						     0,
						     data,
						     0,
						     bytes_read);
				    if(DEBUG)
					System.out.println(" data.length: " + data.length);
				}
			    else
				{
				    //System.out.println("now HERE!");
				    byte[] tmp = new byte[data.length +
							 bytes_read];

				    if(DEBUG)
					{
					    System.out.print("chunk.length: " + chunk.length);
					    System.out.print(" bytes_read " + bytes_read);
					    System.out.print(" data.length: " + data.length);
					    System.out.print(" tmp.length: " + tmp.length);
					}
				// copy the data
				    System.arraycopy(data,
						     0,
						     tmp,
						     0,
						     data.length);
				    
				// copy the new stuff
				    System.arraycopy(chunk,
						     0,
						     tmp,
						     data.length - 1,
						     bytes_read);
				    data = tmp;
				    if(DEBUG)
					System.out.println(" Data.length: " + data.length);
				}
			}
			catch(Exception e)
			    { System.out.println("Here = " + e); }
			
		    }
		dins.close();
            }
            catch(IOException e)
                {
                    System.out.println("IO Exception occured when preparing input stream");
                    System.out.println(e);
                }
E 3
	    
	    // convert the buffer into an image
D 3
	    image = getToolkit().createImage(data);
E 3
I 3
	    image = getToolkit().createImage(baos.toByteArray());
E 3
	    
	    mt.addImage(image, 0);
	    
	    try {
		mt.waitForID(0);
		mt.waitForAll();
		if(mt.statusID(0, true ) != MediaTracker.COMPLETE){
		    System.out.println("Error occured in image loading = " +
				       mt.getErrorsID(0));
		    
		}
E 4
I 4
D 6
    private void setInputStream(InputStream ins) {
E 6
I 6
    private void setInputStream(InputStream ins) throws IOException {
E 6
	MediaTracker mt = new MediaTracker(this);
	int bytes_read = 0;
	byte data[] = new byte[1024];
	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	
D 6
	try {
	    while((bytes_read = ins.read(data)) >0)
		baos.write(data, 0, bytes_read);
	    ins.close();
	} catch(Exception e) { System.out.println(e);}
E 6
I 6
	while((bytes_read = ins.read(data)) >0)
	    baos.write(data, 0, bytes_read);
	ins.close();
E 6
	
D 6
	
E 6
	// convert the buffer into an image
	image = getToolkit().createImage(baos.toByteArray());
	
	mt.addImage(image, 0);
	
	try {
	    mt.waitForID(0);
	    mt.waitForAll();
	    if(mt.statusID(0, true ) != MediaTracker.COMPLETE){
		System.out.println("Error occured in image loading = " +
				   mt.getErrorsID(0));
E 4
		
	    }
D 4
	    catch(InterruptedException e) {
		System.out.println(e);
		return;
	    }
E 4
	    
D 4
	    canvas.setImage(image);
	    if(DEBUG)
		System.out.println("calling invalidate");

E 4
	}
D 4
    //--------------------------------------------------------------------
    public void addNotify()
	{
	    super.addNotify(); // call the real one first...
	    this.invalidate();
	    this.validate();
	    this.doLayout();
E 4
I 4
	catch(InterruptedException e) {
D 7
	    System.out.println(e);
	    return;
E 7
I 7
	    throw new IOException("Error reading image data");
E 7
E 4
	}
I 4
	
	canvas.setImage(image);
	if(DEBUG)
	    System.out.println("calling invalidate");
	
    }
E 4
    //--------------------------------------------------------------------
D 4
    public Dimension getPreferredSize()
	{
	    return canvas.getPreferredSize();
	}
E 4
I 4
    public void addNotify(){
	super.addNotify(); // call the real one first...
	this.invalidate();
	this.validate();
	this.doLayout();
    }
    //--------------------------------------------------------------------
    public Dimension getPreferredSize(){
	return canvas.getPreferredSize();
    }
E 4

}











E 1
