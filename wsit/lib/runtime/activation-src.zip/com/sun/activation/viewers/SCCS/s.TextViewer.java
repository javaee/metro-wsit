h41709
s 00005/00017/00083
d D 1.8 99/12/06 16:33:34 shannon 9 8
c Update copyright for SCSL release
e
s 00002/00001/00098
d D 1.7 97/12/18 13:21:58 bhc 8 7
c minor fixes for FolderView
e
s 00011/00013/00088
d D 1.6 97/12/16 14:51:04 bhc 7 6
c conform to new apis
e
s 00001/00001/00100
d D 1.5 97/12/09 10:39:38 bhc 6 5
c updated to reflect latest JAF apis
e
s 00017/00016/00084
d D 1.4 97/12/02 09:52:27 bhc 5 4
c cleaned up code
e
s 00002/00002/00098
d D 1.3 97/10/20 18:32:30 bhc 4 3
c added cotton's layout fix
c 
e
s 00010/00073/00090
d D 1.2 97/10/06 18:09:00 bhc 3 1
c fix IS bug, now correctly reads in all text
e
s 00000/00000/00000
d R 1.2 97/09/05 16:25:38 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 2 1 src/share/classes/com/sun/activation/viewers/TextViewer.java
c Name history : 1 0 src/classes/com/sun/activation/viewers/TextViewer.java
e
s 00163/00000/00000
d D 1.1 97/09/05 16:25:37 bhc 1 0
c date and time created 97/09/05 16:25:37 by bhc
e
u
U
f e 0
t
T
I 1
D 9
/**
E 9
I 9
/*
E 9
 * %W% %E%
I 9
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
E 9
 * 
D 9
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
E 9
I 9
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
E 9
 * 
D 9
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 *
 * @author Bart Calder
E 9
 */

package com.sun.activation.viewers;

import java.awt.*;
import java.io.*;
import java.beans.*;
import javax.activation.*;

D 5
public class TextViewer extends Panel implements CommandObject 
{
E 5
I 5
public class TextViewer extends Panel implements CommandObject {
E 5
    // UI Vars...
    private TextArea text_area = null;
    
    // File Vars
    private File text_file = null;
    private String text_buffer = null;
D 7
    private InputStream data_ins = null;
    private FileInputStream fis = null;
E 7
    
    private DataHandler _dh = null;
    private boolean DEBUG = false;
D 5
  /**
   * Constructor
   */
  public TextViewer() {
D 4
      
E 4
I 4
      setLayout( new GridLayout(1,1));
E 4
      // create the text area
D 4
      text_area = new TextArea("This is text",24, 80);
E 4
I 4
      text_area = new TextArea();
E 4
      text_area.setEditable( false );
      
      add(text_area);
  }

  //--------------------------------------------------------------------
    public void setDataHandler( DataHandler dh ) {
E 5
I 5
    /**
     * Constructor
     */
    public TextViewer() {
	setLayout( new GridLayout(1,1));
	// create the text area
D 8
	text_area = new TextArea();
E 8
I 8
	text_area = new TextArea("", 24, 80, 
				 TextArea.SCROLLBARS_VERTICAL_ONLY );
E 8
	text_area.setEditable( false );
	
	add(text_area);
    }
    
    //--------------------------------------------------------------------
D 6
    public void initCommandContext(String verb, DataHandler dh) {
E 6
I 6
D 7
    public void setCommandContext(String verb, DataHandler dh) {
E 7
I 7
    public void setCommandContext(String verb, DataHandler dh) throws IOException {
E 7
E 6
E 5
	_dh = dh;
D 7
	
	try {
	    this.setInputStream( _dh.getInputStream() );
	} catch (Exception e) {}
E 7
I 7
	this.setInputStream( _dh.getInputStream() );
E 7
    }
  //--------------------------------------------------------------------

  /**
   * set the data stream, component to assume it is ready to
   * be read.
   */
D 7
  public void setInputStream(InputStream ins) {
E 7
I 7
  public void setInputStream(InputStream ins) throws IOException {
E 7
      
D 3
      DataInputStream dins = new DataInputStream(ins);
      byte[] data = null; // limit the file size to 64 for now...
E 3
      int bytes_read = 0;
      // check that we can actually read
D 3

         try {

		while(bytes_read != -1)
		    {
			int chunk_length = 1024;
			byte[] chunk = new byte[chunk_length];

			bytes_read = dins.read(chunk, 0, chunk.length);
			try {
			    if(data == null)
				{
				    if(DEBUG)
					{
					    System.out.print("bytes_read " + bytes_read);
					    System.out.print(" chunk.length: " + chunk.length);
					}
				    data = new byte[bytes_read];
				    System.arraycopy(chunk,
						     0,
						     data,
						     0,
						     bytes_read);
				    if(DEBUG)
					System.out.println(" data.length: " + data.length);
				}
			    else
				{
				    //System.out.println("now HERE!");
				    byte[] tmp = new byte[data.length +
							 bytes_read];

				    if(DEBUG)
					{
					    System.out.print("chunk.length: " + chunk.length);
					    System.out.print(" bytes_read " + bytes_read);
					    System.out.print(" data.length: " + data.length);
					}
				// copy the data
				    System.arraycopy(data,
						     0,
						     tmp,
						     0,
						     data.length);
				    
				// copy the new stuff
				    System.arraycopy(chunk,
						     0,
						     tmp,
						     data.length - 1,
						     bytes_read);
				    data = tmp;
				    if(DEBUG)
					System.out.println(" Data.length: " + data.length);
				}
			}
			catch(Exception e)
			    { System.out.println(e); }
			
		    }
		dins.close();
            }
            catch(IOException e)
                {
                    System.out.println("IO Exception occured when preparing input stream");
                    System.exit(1);
                }
E 3
I 3
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      byte data[] = new byte[1024];
E 3
      
I 3
D 7
      try {
	  while((bytes_read = ins.read(data)) >0)
		  baos.write(data, 0, bytes_read);
	  ins.close();
      } catch(Exception e) { System.out.println(e);}
E 7
I 7
      while((bytes_read = ins.read(data)) >0)
	  baos.write(data, 0, bytes_read);
      
      ins.close();
E 7

E 3
      // convert the buffer into a string
D 3
            // popuplate the buffer
      text_buffer = new String(data);
E 3
I 3
      // popuplate the buffer
      text_buffer = baos.toString();
E 3

      // place in the text area
      text_area.setText(text_buffer);

D 3


E 3
    }
  //--------------------------------------------------------------------
    public void addNotify() {
	super.addNotify();
	invalidate();
    }
  //--------------------------------------------------------------------
    public Dimension getPreferredSize()	{
	return text_area.getMinimumSize(24, 80);
    }

}
I 5


I 7




E 7
E 5
E 1
