h59627
s 00005/00015/00032
d D 1.8 99/12/06 16:33:39 shannon 9 8
c Update copyright for SCSL release
e
s 00002/00002/00045
d D 1.7 99/05/21 13:49:17 shannon 8 7
c minor javadoc polish
e
s 00010/00010/00037
d D 1.6 99/03/25 17:34:57 shannon 7 6
c clean up code and javadocs
e
s 00002/00001/00045
d D 1.5 98/01/22 13:43:57 bhc 6 5
c clean up javadocs
c 
e
s 00003/00002/00043
d D 1.4 97/12/16 14:46:15 bhc 5 4
c setCommandContext now throws exception
e
s 00008/00005/00037
d D 1.3 97/12/09 10:32:07 bhc 4 3
c updated java docs and changed initCommandContext => setCommandContext
e
s 00007/00002/00035
d D 1.2 97/12/02 09:49:35 bhc 3 1
c updated APIs
e
s 00000/00000/00000
d R 1.2 97/09/05 16:22:24 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 2 1 src/share/classes/javax/activation/CommandObject.java
c Name history : 1 0 src/classes/javax/activation/CommandObject.java
e
s 00037/00000/00000
d D 1.1 97/09/05 16:22:23 bhc 1 0
c date and time created 97/09/05 16:22:23 by bhc
e
u
U
f e 0
t
T
I 1
/*
 * %W% %E%
D 7
 * 
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 * 
E 7
I 7
 *
D 9
 * Copyright (c) 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
E 7
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
D 7
 * 
E 7
I 7
 *
E 7
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
D 7
 * 
E 7
I 7
 *
E 9
I 9
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
E 9
E 7
 */

I 3
D 7

E 7
E 3
package javax.activation;

I 5
import java.io.IOException;
I 7

E 7
E 5
/**
D 4
 * This interface should be implemented by JavaBeans that are
 * <i>Activation Framework</i> aware. That is to say that, JavaBeans
 * written specifically for the framework (beans that do not implement
 * this interface can in most cases still be used with the framework).
E 4
I 4
D 8
 * JavaBeans that are Activation Framework aware implement this
 * interface to find out which command verb they're being asked
E 8
I 8
 * JavaBeans components that are Activation Framework aware implement
 * this interface to find out which command verb they're being asked
E 8
 * to perform, and to obtain the DataHandler representing the
 * data they should operate on.  JavaBeans that don't implement
 * this interface may be used as well.  Such commands may obtain
 * the data using the Externalizable interface, or using an
D 5
 * application-specific method.
E 5
I 5
 * application-specific method.<p>
E 5
E 4
 */
public interface CommandObject {

    /**
D 3
     * Set the <code>DataHandler</code> for this class.
E 3
I 3
D 7
     * Initialize the Command with the verb it is registered to
E 7
I 7
     * Initialize the Command with the verb it is requested to handle
E 7
     * and the DataHandler that describes the data it will
D 6
     * operate on.
E 6
I 6
     * operate on. <b>NOTE:</b> it is acceptable for the caller
     * to pass <i>null</i> as the value for <code>DataHandler</code>.
I 7
     *
E 7
E 6
     * @param verb The Command Verb this object refers to.
E 3
     * @param dh The DataHandler.
     */
D 3
    public void setDataHandler( DataHandler dh ); // throws Exception
E 3
I 3
D 4
    public void initCommandContext(String verb,
E 4
I 4
D 7
    public void setCommandContext(String verb,
E 4
D 5
				   DataHandler dh); // throws Exception
E 5
I 5
				   DataHandler dh) throws IOException; 
E 7
I 7
    public void setCommandContext(String verb, DataHandler dh)
						throws IOException;
E 7
E 5
E 3
}
D 7

E 7
E 1
