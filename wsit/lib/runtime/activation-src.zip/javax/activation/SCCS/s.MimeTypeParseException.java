h41392
s 00005/00015/00028
d D 1.5 99/12/06 16:33:42 shannon 6 5
c Update copyright for SCSL release
e
s 00035/00016/00008
d D 1.4 99/03/25 17:35:01 shannon 5 4
c clean up code and javadocs
e
s 00015/00011/00009
d D 1.3 97/10/20 10:42:46 jmoore 4 3
c Update MimeType to the latest code.
e
s 00002/00002/00018
d D 1.2 97/10/10 11:05:12 jmoore 3 1
c make the class public
e
s 00000/00000/00000
d R 1.2 97/10/07 11:18:02 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 2 1 src/share/classes/javax/activation/MimeTypeParseException.java
c Name history : 1 0 src/classes/javax/activation/MimeTypeParseException.java
e
s 00020/00000/00000
d D 1.1 97/10/07 10:18:01 jmoore 1 0
c First checked in.
e
u
U
f e 0
t
T
I 5
/*
 * %W% %E%
 *
D 6
 * Copyright (c) 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
E 6
I 6
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
E 6
 */

E 5
I 1
D 4
package	javax.activation;
E 4
I 4
package javax.activation;
E 4

/**
D 4
 *	A class to encapsulate MimeType parsing related exceptions
E 4
I 4
D 5
 *    A class to encapsulate MimeType parsing related exceptions
E 5
I 5
 * A class to encapsulate MimeType parsing related exceptions.
E 5
E 4
 */
D 3
class		MimeTypeParseException
	extends	Exception
E 3
I 3
D 4
public class	MimeTypeParseException
	extends		Exception
E 3
{
E 4
I 4
public class MimeTypeParseException extends Exception {
E 4

D 4
public	MimeTypeParseException()
{
	super();
E 4
I 4
D 5
/**
 * Constructs a MimeTypeParseException with no specified detail message. 
 */
public MimeTypeParseException() {
    super();
E 4
}
E 5
I 5
    /**
     * Constructs a MimeTypeParseException with no specified detail message. 
     */
    public MimeTypeParseException() {
	super();
    }
E 5

D 4
public	MimeTypeParseException(String inInfo)
{
	super(inInfo);
E 4
I 4
D 5
/**
 * Constructs a MimeTypeParseException with the specified detail message. 
 *
 * @param   s   the detail message.
 */
public MimeTypeParseException(String s) {
    super(s);
E 4
}

E 5
I 5
    /**
     * Constructs a MimeTypeParseException with the specified detail message. 
     *
     * @param   s   the detail message.
     */
    public MimeTypeParseException(String s) {
	super(s);
    }
E 5
}
E 1
