h55113
s 00005/00015/00026
d D 1.5 99/12/06 16:33:40 shannon 6 5
c Update copyright for SCSL release
e
s 00011/00014/00030
d D 1.4 99/03/25 17:35:00 shannon 5 4
c clean up code and javadocs
e
s 00010/00003/00034
d D 1.3 97/12/19 14:33:08 bhc 4 3
c javadoc fixes
c 
e
s 00006/00001/00031
d D 1.2 97/12/09 10:37:27 bhc 3 1
c added better javadocs
e
s 00000/00000/00000
d R 1.2 97/10/06 10:54:14 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 2 1 src/share/classes/javax/activation/DataContentHandlerFactory.java
c Name history : 1 0 src/classes/javax/activation/DataContentHandlerFactory.java
e
s 00032/00000/00000
d D 1.1 97/10/06 10:54:13 bhc 1 0
c date and time created 97/10/06 10:54:13 by bhc
e
u
U
f e 0
t
T
I 1
/*
 * %W% %E%
D 5
 * 
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 * 
E 5
I 5
 *
D 6
 * Copyright (c) 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 *
E 5
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
D 5
 * 
E 5
I 5
 *
E 5
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
D 5
 * 
E 5
I 5
 *
E 6
I 6
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
E 6
E 5
 */

package javax.activation;

D 5
import javax.activation.DataContentHandler;

I 3
D 4
/** This interface defines a factory for data content handlers. An
E 4
I 4
/** 
E 5
I 5
/**
E 5
 * This interface defines a factory for <code>DataContentHandlers</code>. An
E 4
 * implementation of this interface should map a MIME type into an
D 4
 * instance of DataContentHandler.
E 4
I 4
 * instance of DataContentHandler. The design pattern for classes implementing
D 5
 * this interface is the same as for the ContentHandler mechanism used in 
 * <code>java.net.URL</code>
E 5
I 5
 * this interface is the same as for the ContentHandler mechanism used in
 * <code>java.net.URL</code>.
E 5
E 4
 */

E 3
public interface DataContentHandlerFactory {
D 5
    
E 5
I 5

E 5
    /**
D 3
     * create a DataContentHandler for the mimeType
E 3
I 3
D 4
     * create a DataContentHandler for the mimeType 
E 4
I 4
D 5
     * Creates a new DataContentHandler object  for the MIME type.
E 5
I 5
     * Creates a new DataContentHandler object for the MIME type.
E 5
     *
     * @param mimeType the MIME type to create the DataContentHandler for.
D 5
     * @return The new <code>DataContentHandler</code>, returns <i>null</i>
E 5
I 5
     * @return The new <code>DataContentHandler</code>, or <i>null</i>
E 5
     * if none are found.
E 4
E 3
     */
    public DataContentHandler createDataContentHandler(String mimeType);
D 5
    
E 5
}
E 1
