h41745
s 00004/00014/00036
d D 1.8 99/12/06 16:33:43 shannon 9 8
c Update copyright for SCSL release
e
s 00001/00001/00049
d D 1.7 99/05/21 13:49:19 shannon 8 7
c minor javadoc polish
e
s 00002/00001/00048
d D 1.6 99/03/25 17:35:02 shannon 7 6
c clean up code and javadocs
e
s 00000/00020/00049
d D 1.5 98/02/10 16:06:12 bhc 6 5
c removed extra copyright
c 
e
s 00020/00000/00049
d D 1.4 98/02/10 16:05:26 bhc 5 4
c added copyright
c 
e
s 00011/00001/00038
d D 1.3 98/02/10 15:51:24 bhc 4 3
c updated javadocs
c 
e
s 00004/00004/00035
d D 1.2 97/12/19 14:38:01 bhc 3 1
c name change
e
s 00000/00000/00000
d R 1.2 97/12/18 13:18:23 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 3 2 src/share/classes/javax/activation/UnsupportedDataTypeException.java
c Name history : 2 1 src/classes/javax/activation/UnsupportedDataTypeException.java
c Name history : 1 0 src/classes/javax/activation/UnSupportedDataTypeException.java
e
s 00039/00000/00000
d D 1.1 97/12/18 13:18:22 bhc 1 0
c 
e
u
U
f e 0
t
T
I 1
/*
 * %W% %E%
I 9
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
E 9
 * 
D 6
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
I 5
/*
 * %W% %E%
 * 
E 6
D 7
 * Copyright (c) 1997, 1998 Sun Microsystems, Inc. All Rights Reserved.
E 7
I 7
D 9
 * Copyright (c) 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
E 9
I 9
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
E 9
E 7
 * 
D 9
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * 
E 9
D 6
 * 
E 6
 */
E 5

package javax.activation;

import java.io.IOException;

I 4
/**
D 8
 * Signals that requested operation does not support the
E 8
I 8
 * Signals that the requested operation does not support the
E 8
 * requested data type.
 *
 * @see javax.activation.DataHandler
 */

E 4
D 3
public class UnSupportedDataTypeException extends IOException {
E 3
I 3
public class UnsupportedDataTypeException extends IOException {
E 3
    /**
D 4
     * no argument constructor.
E 4
I 4
     * Constructs an UnsupportedDataTypeException with no detail
     * message.
E 4
     */
D 3
    public UnSupportedDataTypeException() {
E 3
I 3
    public UnsupportedDataTypeException() {
E 3
	super();
    }
I 7

E 7
    /**
D 3
     * Constructs an UnSupportedDataTypeException with the specified 
E 3
I 3
     * Constructs an UnsupportedDataTypeException with the specified 
E 3
     * message.
I 4
     * 
     * @param s The detail message.
E 4
     */
D 3
    public UnSupportedDataTypeException(String s) {
E 3
I 3
    public UnsupportedDataTypeException(String s) {
E 3
	super(s);
    }
}
E 1
