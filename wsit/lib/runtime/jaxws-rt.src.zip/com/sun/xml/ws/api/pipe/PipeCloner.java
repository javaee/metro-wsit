/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License).  You may not use this file except in
 * compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * you own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 * 
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 */
package com.sun.xml.ws.api.pipe;

import java.util.Map;
import java.util.HashMap;

/**
 * Clones the whole pipeline.
 *
 * <p>
 * Since {@link Pipe}s may form an arbitrary directed graph, someone needs
 * to keep track of isomorphism for a clone to happen correctly. This class
 * serves that role.
 *
 * @author Kohsuke Kawaguchi
 */
public final class PipeCloner {
    private final Map<Pipe,Pipe> master2copy = new HashMap<Pipe,Pipe>();

    /**
     * Invoked by a client of a pipe to clone the whole pipeline.
     *
     * <p>
     * {@link Pipe}s implementing the {@link Pipe#copy(PipeCloner)} method
     * shall use {@link #copy(Pipe)} method.
     *
     * @param p
     *      The entry point of a pipeline to be copied. must not be null.
     * @return
     *      The cloned pipeline. Always non-null.
     */
    public static Pipe clone(Pipe p) {
        return new PipeCloner().copy(p);
    }

    // no need to be constructed publicly. always use the static clone method.
    private PipeCloner() {}

    /**
     * Invoked by a {@link Pipe#copy(PipeCloner)} implementation
     * to copy a reference to another pipe.
     *
     * <p>
     * This method is for {@link Pipe} implementations, not for users.
     *
     * <p>
     * If the given pipe is already copied for this cloning episode,
     * this method simply returns that reference. Otherwise it copies
     * a pipe, make a note, and returns a copied pipe. This additional
     * step ensures that a graph is cloned isomorphically correctly.
     *
     * <p>
     * (Think about what happens when a graph is A->B, A->C, B->D, and C->D
     * if you don't have this step.)
     *
     * @param p
     *      The pipe to be copied.
     * @return
     *      The cloned pipe. Always non-null.
     */
    public <T extends Pipe> T copy(T p) {
        Pipe r = master2copy.get(p);
        if(r==null) {
            r = p.copy(this);
            // the pipe must puts its copy to the map by itself
            assert master2copy.get(p)==r : "the pipe must call the add(...) method to register itself before start copying other pipes, but "+p+" hasn't done so";
        }
        return (T)r;
    }

    /**
     * This method must be called from within the copy constructor
     * to notify that the copy was created.
     *
     * <p>
     * When your pipe has references to other pipes,
     * it's particularly important to call this method
     * before you start copying the pipes you refer to,
     * or else there's a chance of inifinite loop.
     */
    public void add(Pipe original, Pipe copy) {
        assert !master2copy.containsKey(original);
        assert original!=null && copy!=null;
        master2copy.put(original,copy);
    }
}
