package com.sun.xml.ws.transport.http;

/**
 * @author Jitendra Kotamraju
 */
public interface HttpDumpMBean {

    public void setDump(boolean dump);

    public boolean getDump();

}
