/**
 * JAX-WS RI vendor extension features that are available to the JAX-WS RI users.
 */
package com.sun.xml.ws.developer;