/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 * 
 * Copyright 1997-2007 Sun Microsystems, Inc. All rights reserved.
 * 
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 * 
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 * 
 * Contributor(s):
 * 
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */

package com.sun.xml.ws.encoding;


import com.sun.istack.NotNull;
import com.sun.istack.Nullable;
import com.sun.xml.messaging.saaj.packaging.mime.MessagingException;
import com.sun.xml.messaging.saaj.packaging.mime.internet.ContentType;
import com.sun.xml.messaging.saaj.packaging.mime.internet.InternetHeaders;
import com.sun.xml.messaging.saaj.packaging.mime.internet.ParseException;
import com.sun.xml.ws.message.stream.StreamAttachment;
import com.sun.xml.ws.util.ASCIIUtility;
import com.sun.xml.ws.util.ByteArrayBuffer;
import com.sun.xml.ws.api.message.Attachment;
import com.sun.xml.ws.developer.StreamingDataHandler;

import javax.xml.ws.WebServiceException;
import javax.xml.transform.Source;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPException;
import javax.activation.DataHandler;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Map;

import org.jvnet.mimepull.MIMEMessage;
import org.jvnet.mimepull.MIMEConfig;
import org.jvnet.mimepull.MIMEPart;

/**
 * Parses Mime multipart message into primary part and attachment parts. It
 * parses the stream lazily as and when required.
 *
 * TODO need a list to keep all the attachments so that even if Content-Id is
 * not there it is accounted
 *
 * @author Vivek Pandey
 * @author Jitendra Kotamraju
 */
public final class MimeMultipartParser {

    private final String start;
    private final Map<String, Attachment> attachments = new HashMap<String, Attachment>();
    private PartAttachment root;
    private final MIMEMessage message;

    public MimeMultipartParser(InputStream in, String contentType) {
        try {
            ContentType ct = new ContentType(contentType);
            String boundary = ct.getParameter("boundary");
            if (boundary == null || boundary.equals("")) {
                throw new WebServiceException("MIME boundary parameter not found" + contentType);
            }
            message = new MIMEMessage(in, boundary, new MIMEConfig(false, 8192, 20000));
            // Strip <...> from root part's Content-ID
            String st = ct.getParameter("start");
            if (st != null && st.length() > 2 && st.charAt(0) == '<' && st.charAt(st.length()-1) == '>') {
                st = st.substring(1, st.length()-1);
            }
            start = st;    
        } catch (ParseException e) {
            throw new WebServiceException(e);
        }
    }

    /**
     * Parses the stream and returns the root part. If start parameter is
     * present in Content-Type, it is used to determine the root part, otherwise
     * root part is the first part.
     *
     * @return StreamAttachment for root part
     *         null if root part cannot be found
     *
     */
    public @Nullable Attachment getRootPart() {
        if (root == null) {
            root = new PartAttachment((start != null) ? message.getPart(start) : message.getPart(0));
        }
        return root;
    }

    /**
     * Parses the entire stream and returns all MIME parts except root MIME part.
     *
     * @return Map<String, StreamAttachment> for all attachment parts
     */
    public @NotNull Map<String, Attachment> getAttachmentParts() {
        throw new UnsupportedOperationException();
    }

    /**
     * This method can be called to get a matching MIME attachment part for the
     * given contentId. It parses the stream until it finds a matching part.
     *
     * @return StreamAttachment attachment for contentId
     *         null if there is no attachment for contentId
     */
    public @Nullable Attachment getAttachmentPart(String contentId) throws IOException {
        //first see if this attachment is already parsed, if so return it
        Attachment attach = attachments.get(contentId);
        if (attach == null) {
            MIMEPart part = message.getPart(contentId);
            attach = new PartAttachment(part);
            attachments.put(contentId, attach);
        }
        return attach;
    }

    static class PartAttachment implements Attachment {

        final MIMEPart part;

        PartAttachment(MIMEPart part) {
            this.part = part;
        }

        public @NotNull String getContentId() {
            return part.getContentId();
        }

        public @NotNull String getContentType() {
            return part.getContentType();
        }

        public byte[] asByteArray() {
            throw new UnsupportedOperationException();
        }

        public DataHandler asDataHandler() {
            return new StreamingDataHandler(part);
        }

        public Source asSource() {
            throw new UnsupportedOperationException();
        }

        public InputStream asInputStream() {
            return part.readOnce();
        }

        public void writeTo(OutputStream os) throws IOException {
            throw new UnsupportedOperationException();
        }

        public void writeTo(SOAPMessage saaj) throws SOAPException {
            throw new UnsupportedOperationException();
        }
    }

}
