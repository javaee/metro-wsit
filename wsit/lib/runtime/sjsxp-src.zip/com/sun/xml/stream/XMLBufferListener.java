/*
 * $Id: XMLBufferListener.java,v 1.2 2006/04/01 06:01:49 jeffsuttor Exp $
 */

/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License).  You may not use this file except in
 * compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * you own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 * 
 * [Name of File] [ver.__] [Date]
 * 
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 */

package com.sun.xml.stream;

/**
 * XMLBufferListerner should be implemented by classes which wish to receive
 * call backs from XMLEntityReader.
 *
 * @author k.venugopal@sun.com,
 * @author Neeraj.bajaj@sun.com
 */
public interface XMLBufferListener {
    
    /**
     * Will be invoked by XMLEntityReader before it tries to resize,load new data
     * into current ScannedEntities buffer.
     */
    public void refresh();
    
    /**
     * receives callbacks from {@link XMLEntityReader } when buffer
     * is being changed.
     * @param refreshPosition
     */
    public void refresh(int loadPosition);
    
}
