/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: AttributedQNameImpl.java,v 1.1 2006/07/24 22:26:59 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved.
 */

package com.sun.xml.ws.addressing;

import static com.sun.xml.ws.addressing.Constants.WSA_NAMESPACE_NAME;
import com.sun.xml.ws.addressing.util.AddressingUtils;

import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPElement;
import javax.xml.ws.addressing.AddressingException;
import javax.xml.ws.addressing.AttributedQName;
import java.util.Map;

/**
 * @author JAX-WSA Development Team
 */
@XmlType(name = "AttributedQNameType", namespace = WSA_NAMESPACE_NAME)
public class AttributedQNameImpl extends AddressingValueBase implements
        AttributedQName {

    @XmlTransient
    protected QName qname;

    // package-private - used by MetadataImpl.getInterfaceName
    public AttributedQNameImpl() {
        super(WSA_NAMESPACE_NAME);
    }

    protected AttributedQNameImpl(String version) {
        super(version);
    }

    public AttributedQNameImpl(QName qname) {
        super(WSA_NAMESPACE_NAME);
        this.qname = qname;
        this.value = getValue();
    }

    /**
     * Accessor for the <code>QName</code> property.
     *
     * @return The value of the property.
     */
    public QName getQName() {
        return qname;
    }

    public void addElement(SOAPElement element) throws AddressingException {
        throw new AddressingException(
                "AttributedQName type does not support Extensibility elements.");
    }

//    @Override
//    public List<Object> getElements() {
//        return null;
//    }

    @Override
    public void read(SOAPElement element) throws AddressingException {

        text = null;
        super.read(element);

        qname = AddressingUtils.getQName(element, text);
    }

    @Override
    protected String getValue() {
        return qname.getPrefix() + ":" + qname.getLocalPart();
    }


    /* copy non-SOAP AttributedQName if necessary */
    public static AttributedQNameImpl getAddressingElement(AttributedQName qname) {
        if (qname instanceof AttributedQNameImpl) {
            return (AttributedQNameImpl) qname;
        }

        AttributedQNameImpl impl = new AttributedQNameImpl(qname.getQName());
        Map<QName, String> atts = qname.getAttributes();
        if (atts != null) {
            for (QName name : atts.keySet()) {
                impl.addAttribute(name, atts.get(name));
            }
        }

        return impl;
    }

    public String toString() {
        return qname.toString();
    }
}
