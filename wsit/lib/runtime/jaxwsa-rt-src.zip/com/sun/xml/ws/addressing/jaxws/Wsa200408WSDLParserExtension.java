/*
 The contents of this file are subject to the terms
 of the Common Development and Distribution License
 (the "License").  You may not use this file except
 in compliance with the License.
 
 You can obtain a copy of the license at
 https://jwsdp.dev.java.net/CDDLv1.0.html
 See the License for the specific language governing
 permissions and limitations under the License.
 
 When distributing Covered Code, include this CDDL
 HEADER in each file and include the License file at
 https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 add the following below this CDDL HEADER, with the
 fields enclosed by brackets "[]" replaced with your
 own identifying information: Portions Copyright [yyyy]
 [name of copyright owner]
*/
/*
 $Id: Wsa200408WSDLParserExtension.java,v 1.1 2006/07/24 22:26:53 arungupta Exp $

 Copyright (c) 2006 Sun Microsystems, Inc.
 All rights reserved.
*/

package com.sun.xml.ws.addressing.jaxws;

import java.util.HashMap;

import javax.xml.ws.addressing.AddressingBuilderFactory;
import javax.xml.ws.addressing.AddressingConstants;
import javax.xml.ws.addressing.AddressingException;
import javax.xml.stream.XMLStreamReader;

import com.sun.xml.ws.api.wsdl.parser.WSDLParserExtension;
import com.sun.xml.ws.api.model.wsdl.WSDLOperation;
import com.sun.xml.ws.api.model.wsdl.WSDLModel;
import com.sun.xml.ws.api.model.wsdl.WSDLPortType;
import com.sun.xml.ws.api.model.wsdl.WSDLFault;
import com.sun.xml.ws.wsdl.parser.ParserUtil;
import com.sun.xml.ws.addressing.v200408.Wsa200408WSDLOperationExtension;

/**
 * Runtime WSDL parser extension.
 *
 * @author JAX-WSA Development Team
 */
public class Wsa200408WSDLParserExtension extends WSDLParserExtension {
    private static final AddressingConstants ac = AddressingBuilderFactory.newInstance().newAddressingBuilder(com.sun.xml.ws.addressing.v200408.Constants.WSA_NAMESPACE_NAME).newAddressingConstants();

    @Override
    public boolean portTypeOperationInput(WSDLOperation op, XMLStreamReader reader) {
        String action = ParserUtil.getAttribute(reader, ac.getWSDLActionQName());
        Wsa200408WSDLOperationExtension ww = getWsaExtension(op);
        ww.setInputAction(action);
        ww.setInputDefault(action == null);

        return false;
    }

    @Override
    public boolean portTypeOperationOutput(WSDLOperation o, XMLStreamReader reader) {
        String action = ParserUtil.getAttribute(reader, ac.getWSDLActionQName());

        Wsa200408WSDLOperationExtension ww = getWsaExtension(o);
        ww.setOutputAction(action);

        return false;
    }

    @Override
    public boolean portTypeOperationFault(WSDLOperation o, XMLStreamReader reader) {
        HashMap<String,String> map = getWsaExtension(o).getFaultActions();

        String action = ParserUtil.getAttribute(reader, ac.getWSDLActionQName());
        if (action != null) {
            String name = ParserUtil.getMandatoryNonEmptyAttribute(reader, "name");
            map.put(name, action);
        }

        return false;
    }

    private static Wsa200408WSDLOperationExtension getWsaExtension(WSDLOperation o) {
        Wsa200408WSDLOperationExtension ww = o.getExtension(Wsa200408WSDLOperationExtension.class);
        if (ww == null) {
            ww = new Wsa200408WSDLOperationExtension();
            o.addExtension(ww);
        }

        return ww;
    }

    @Override
    public void finished(WSDLModel model) {
        populateActions(model);
    }

    private void populateActions(WSDLModel model) {
        // populate all the Actions
        for (WSDLPortType portType : model.getPortTypes().values()) {
            for (WSDLOperation o : portType.getOperations()) {
                Wsa200408WSDLOperationExtension ww = getWsaExtension(o);

                // In the absence of a wsaw:Action attribute on a WSDL input element where a
                // SOAPAction value is specified, the value of the [action] property for the
                // input message is the value of the SOAPAction specified.
                if (ww.getInputAction() == null) {
                    ww.setInputAction(defaultInputAction(o));
                }

                // skip output and fault processing for one-way methods
                if (o.getOutput() == null)
                    continue;

                if (ww.getOutputAction() == null) {
                    ww.setOutputAction(defaultOutputAction(o));
                }

                if (o.getFaults() == null || !o.getFaults().iterator().hasNext())
                    continue;

                HashMap<String, String> map = ww.getFaultActions();
                for (WSDLFault f : o.getFaults()) {
                    if (map.get(f.getName()) == null)
                        map.put(f.getName(), defaultFaultAction(f.getName(), o));
                }
            }
        }
    }
    private String defaultInputAction(WSDLOperation o) {
        return buildAction(o.getInput().getName(), o, false);
    }


    private String defaultOutputAction(WSDLOperation o) {
        return buildAction(o.getOutput().getName(), o, false);
    }

    private String defaultFaultAction(String name, WSDLOperation o) {
        return buildAction(name, o, true);
    }

    protected static final String buildAction(String name, WSDLOperation o, boolean isFault) {
        String tns = o.getName().getNamespaceURI();

        String delim = SLASH_DELIMITER;

        // TODO: is this the correct way to find the separator ?
        if (!tns.startsWith("http"))
            delim = COLON_DELIMITER;

        if (tns.endsWith(delim))
            tns = tns.substring(0, tns.length()-1);

        if (o.getPortTypeName() == null)
            throw new AddressingException("\"" + o.getName() + "\" operation's owning portType name is null.");

        return tns +
            delim +
            o.getPortTypeName().getLocalPart() +
            delim +
            (isFault ? o.getName().getLocalPart() + "Fault" + delim : "") +
            name;
    }

    private static final String SLASH_DELIMITER = "/";
    private static final String COLON_DELIMITER = ":";}
