/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: AddressingElementBase.java,v 1.1 2006/07/24 22:26:59 arungupta Exp $
 * 
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package com.sun.xml.ws.addressing;

import javax.xml.bind.annotation.XmlTransient;
import javax.xml.namespace.QName;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.Text;
import javax.xml.ws.addressing.AddressingException;
import javax.xml.ws.addressing.ElementExtensible;
import static javax.xml.ws.addressing.JAXWSAConstants.SOAP_FACTORY;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * Base class for AddressingElements with extensibility elements and default
 * implementations of Extensible and SOAPAddressingElement methods.
 *
 * @author JAX-WSA Development Team
 */
public abstract class AddressingElementBase extends AddressingValueBase
        implements ElementExtensible {

    /**
     * Internal Collection of elements.
     */
//    @XmlAnyElement(lax = false, value = W3CDomHandler.class)
    @XmlTransient
    protected List<Object> elements = new ArrayList<Object>();

//    /**
//     * Read-only view of element exposed by the <code>getElements</code> method.
//     */
//    @XmlTransient
//    protected List<Object> exposedElements = new ArrayList<Object>();

    /**
     * Public constructor initializes the <code>Extensible</code> subclass using
     * a <code>Map</code> and <code>Collection</code> that are passed to it and used
     * to initialize the underlying data structures.
     */
    protected AddressingElementBase() {
        super();
//        this.exposedElements = Collections.unmodifiableList(elements);

    }

    public List<Object> getElements() {
        return elements;
    }

    public void addElement(Object element) {
        elements.add(element);
    }

    public boolean removeElement(Object element) {
        return elements.remove(element);
    }

    @Override
    public void read(SOAPElement element) throws AddressingException {
        //read child elements
        Iterator it = element.getChildElements();

        //reinitialize elements collection
        elements = new ArrayList<Object>();

        while (it.hasNext()) {

            Object obj = it.next();
            if (obj instanceof Text) {
                throw new AddressingException("Invalid Text node in element.");
            } else {
                elements.add((SOAPElement) obj);
            }
        }

        //read attributes
        it = element.getAllAttributes();

        if (it.hasNext()) {
            attributes = new HashMap<QName, String>();
        } else {
            attributes = null;
        }

        while (it.hasNext()) {
            if (attributes == null) {
                throw new AddressingException("Unsupported attribute collection.");
            }

            Name name = (Name) it.next();
            String uri = name.getURI();
            String localName = name.getLocalName();
            String value = element.getAttributeValue(name);

            QName qname = new QName(uri, localName);
            attributes.put(qname, value);
        }
    }

    @Override
    public SOAPElement write(SOAPElement parent, QName name) {
        try {
            SOAPElement element = SOAP_FACTORY.createElement(name
                    .getLocalPart(), name.getPrefix(), name.getNamespaceURI());

            if (elements != null) {
                for (Object obj : elements) {
                    //BUGBUG -- This is broken when elements collection
                    //is initialized by a JAXB unmarshalling.  
                    SOAPElement el = (SOAPElement) obj;
                    element.addChildElement(el);
                }
            }

            if (attributes != null) {
                Set keys = attributes.keySet();
                for (Object qname : keys) {
                    Name saajname = SOAP_FACTORY.createName(((QName) qname)
                            .getLocalPart(), ((QName) qname).getPrefix(),
                                             ((QName) qname).getNamespaceURI());

                    element.addAttribute(saajname, attributes.get(qname));
                }
            }

            if (parent == null)
                throw new AddressingException("Cannot write " + name + " to null parent.");

            parent.addChildElement(element);
            return element;
        } catch (SOAPException e) {
            throw new AddressingException(e);
        }
    }
}

