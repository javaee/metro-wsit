/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: WsaServerPipe.java,v 1.1 2006/07/24 22:26:53 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved.
 */

package com.sun.xml.ws.addressing.jaxws;

import com.sun.xml.ws.api.EndpointAddress;
import com.sun.xml.ws.api.WSBinding;
import com.sun.xml.ws.api.message.Packet;
import com.sun.xml.ws.api.model.wsdl.WSDLPort;
import com.sun.xml.ws.api.model.SEIModel;
import com.sun.xml.ws.api.pipe.Pipe;
import com.sun.xml.ws.api.pipe.PipeCloner;
import com.sun.xml.ws.transport.http.client.HttpTransportPipe;

import javax.xml.ws.addressing.AddressingProperties;
import javax.xml.ws.addressing.JAXWSAConstants;
import java.net.URI;

/**
 * @author JAX-WSA Development Team
 */
public final class WsaServerPipe extends WsaPipe {

    public WsaServerPipe(SEIModel seiModel, WSDLPort wsdlPort, WSBinding binding, Pipe next) {
        super(seiModel, wsdlPort, binding, next);
    }

    public Pipe copy(PipeCloner pipeCloner) {
        WsaServerPipe that = new WsaServerPipe(seiModel, wsdlPort, binding, next);
        pipeCloner.add(this, that);

        return that;
    }

    public Packet process(Packet packet) {
        Packet p = helper.readServerInboundHeaders(packet);

        AddressingProperties inbound = (AddressingProperties)p.invocationProperties.get(JAXWSAConstants.SERVER_ADDRESSING_PROPERTIES_INBOUND);

        if (p.getMessage() != null && p.getMessage().isFault()) {
            return processFault(p, inbound, false);
        }

        // TODO: Evaluate the impact of other pipes that might have
        // TODO: executed before WS-A pipe. So far RM always sends the
        // TODO: protocol response along with application response ONLY.
        if (inbound != null && inbound.getReplyTo() != null) {
            // none ReplyTo
            if (inbound.getReplyTo().toString().equals(ac.getNoneURI()) &&
                    ((inbound.getFaultTo() == null) ||
                    (!inbound.getFaultTo().toString().equals(ac.getAnonymousURI())))) {
                if (p.transportBackChannel != null) {
                    p.transportBackChannel.close();
                }
                return next.process(p);
            }

            // non-anonymous ReplyTo
            if (!inbound.getReplyTo().getAddress().getURI().toString().equals(ac.getAnonymousURI()) &&
                    ((inbound.getFaultTo() == null) ||
                    (!inbound.getFaultTo().toString().equals(ac.getAnonymousURI())))) {
                return processNonAnonymousReply(p, inbound.getReplyTo().getAddress().getURI(), true);
            }
        }

        p = next.process(p);
        p = helper.writeServerOutboundHeaders(p);

        if (p.getMessage() != null && p.getMessage().isFault()) {
            return processFault(p, (AddressingProperties)p.invocationProperties.get(JAXWSAConstants.SERVER_ADDRESSING_PROPERTIES_INBOUND), false);
        }

        return p;
    }

    /**
     * Process none and non-anonymous Fault endpoints
     *
     * @param p packet
     * @param ap addressing properties
     * @param invokeEndpoint true if endpoint has been invoked, false otherwise
     * @return response packet received from endpoint
     */
    private Packet processFault(Packet p, AddressingProperties ap, final boolean invokeEndpoint) {
        if (ap == null)
            return p;

//        if (ap.getRelatesTo() != null)
//            return p;

        if (ap.getFaultTo() == null) {
            // default FaultTo is ReplyTo

            if (ap.getReplyTo() != null) {
                // if none, then fault message is not sent back
                if (ap.getReplyTo().toString().equals(ac.getNoneURI())) {
                    if (invokeEndpoint) {
                        return p.createResponse(null);
                    }
                    p.transportBackChannel.close();
                } else if (!ap.getReplyTo().toString().equals(ac.getAnonymousURI())) {
                    // non-anonymous default FaultTo
                    return processNonAnonymousReply(p, ap.getReplyTo().getAddress().getURI(), invokeEndpoint);
                }
            }
        } else {
            // explicit FaultTo

            // if none, then fault message is not sent back
            if (ap.getFaultTo().toString().equals(ac.getNoneURI())) {
                if (invokeEndpoint) {
                    return p.createResponse(null);
                }
                p.transportBackChannel.close();
            } else if (!ap.getFaultTo().toString().equals(ac.getAnonymousURI())) {
                // non-anonymous FaultTo
                return processNonAnonymousReply(p, ap.getFaultTo().getAddress().getURI(), invokeEndpoint);
            }
        }

        return p;
    }


    /**
     * Send response to non-anonymous address
     *
     * @param packet packet
     * @param uri endpoint address
     * @param invokeEndpoint true if endpoint has been invoked, false otherwise
     * @return response received from the non-anonymous endpoint
     */
    private Packet processNonAnonymousReply(final Packet packet, final URI uri, final boolean invokeEndpoint) {
        if (packet.transportBackChannel != null)
            packet.transportBackChannel.close();
        Packet response = packet;
        if (invokeEndpoint) {
            response = next.process(packet);
            response = helper.writeServerOutboundHeaders(response);
        }

//        AddressingProperties ap = (AddressingProperties)packet.invocationProperties.get(JAXWSAConstants.SERVER_ADDRESSING_PROPERTIES_OUTBOUND);
//        if (!ap.getReplyTo().getAddress().getURI().toString().equals(uri)) {
//            throw new AddressingException("ReplyTo address has changed");
//        }

        AddressingProperties ap = (AddressingProperties)packet.invocationProperties.get(JAXWSAConstants.SERVER_ADDRESSING_PROPERTIES_INBOUND);
        if ((response != null && response.getMessage() != null && response.getMessage().isFault() &&
                ap.getFaultTo() != null && ap.getFaultTo().toString().equals(ac.getNoneURI())) ||
                (ap.getReplyTo() != null && ap.getReplyTo().toString().equals(ac.getNoneURI()))) {
            return packet;
        }

        System.out.printf("Sending non-anonymous reply to %s\n", uri.toString());
        HttpTransportPipe tPipe = new HttpTransportPipe(binding);
        response.endpointAddress = new EndpointAddress(uri);
        response = tPipe.process(response);

        if (response != null) {
//            if (response.httpResponseHeaders != null) {
//                for (String headerKey : response.httpResponseHeaders.keySet()) {
//                    System.out.printf(headerKey + ":");
//                    for (String header : response.httpResponseHeaders.get(headerKey)) {
//                        System.out.printf("[" + header + "]");
//                    }
//                    System.out.println();
//                }
//            } else {
//                System.out.printf("%s: null response headers\n", uri.toString());
//            }
        } else {
            System.out.printf("%s: null response\n", uri.toString());
        }

        return response;
    }
}
