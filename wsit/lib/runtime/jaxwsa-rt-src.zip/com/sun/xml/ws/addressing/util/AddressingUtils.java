/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: AddressingUtils.java,v 1.1 2006/07/24 22:26:55 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved.
 */

package com.sun.xml.ws.addressing.util;

import static com.sun.xml.ws.addressing.Constants.WSA_NAMESPACE_NAME;

import java.util.Iterator;

import javax.xml.ws.addressing.AddressingException;
import javax.xml.namespace.QName;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;

/**
 * @author JAX-WSA Development Team
 */
public class AddressingUtils {

    /**
     * Utility method to remove all AddressingHeaders form a SOAPMessage
     */
    public static void removeAllAddressingHeaders(SOAPMessage message, String version)
    throws SOAPException {

        SOAPHeader header = message.getSOAPHeader();

        if (header != null) {
            Iterator it = header.getChildElements();

            while (it.hasNext()) {
                SOAPElement el = (SOAPElement) it.next();
                Name name = el.getElementName();
                if (name.getURI().equals(version)) {
                    el.detachNode();
                }
            }
        }
    }

    /**
     * Utility method to remove existing AddressingHeaders with a given QName
     * from a SOAPMessage
     */
    public static void removeAllAddressingHeaders(SOAPMessage message,
                                                  QName qname) throws SOAPException {

        SOAPHeader header = message.getSOAPHeader();
        Iterator it = header.getChildElements();

        while (it.hasNext()) {
            SOAPElement el = (SOAPElement) it.next();
            Name name = el.getElementName();
            if (name.getURI().equals(WSA_NAMESPACE_NAME)
            && name.getLocalName().equals(qname.getLocalPart())) {
                el.detachNode();
            }
        }
    }

    /**
     * Utility method to find an element with a given name in a Iteration of
     * SOAPElements. If the unique parameter is <code>true</code> and multiple
     * such elements exist, an AddressingException is thrown.
     */
    public static SOAPElement findElement(QName name,
                                          Iterator<Object> elements, boolean unique)
            throws AddressingException {

        SOAPElement ret = null;
        while (elements.hasNext()) {

            SOAPElement element = (SOAPElement) (elements.next());
            Name saajname = element.getElementName();
            QName qname = new QName(saajname.getURI(), saajname.getLocalName(),
                                    saajname.getPrefix());
            if (name.equals(qname)) {
                if (unique) {
                    if (ret != null) {
                        throw new AddressingException(
                                "Multiple elements with namne " + name);
                    } else {
                        ret = element;
                    }
                } else {
                    ret = element;
                    break;
                }
            }
        }
        return ret;
    }

    /**
     * Utility method to get the SOAPHeader from a SOAPMessage, adding one if
     * one is not present in the original message.
     */
    public static SOAPHeader ensureSOAPHeader(SOAPMessage message) {
        SOAPHeader header = null;

        try {
            header = message.getSOAPPart().getEnvelope().getHeader();
            if (header != null) {
                return header;
            } else {
                return message.getSOAPPart().getEnvelope().addHeader();
            }
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Get the QName represented as the text child node of a given SOAPElement
     */
    public static QName getQName(SOAPElement element, String data)
    throws AddressingException {

        int colon = -1;
        if (data == null || data.equals("")
        || -1 == (colon = data.indexOf(":"))) {
            throw new AddressingException("Invalid QName node.");
        }

        String prefix = data.substring(0, colon);
        String local = data.substring(colon + 1);
        String nameSpace = element.getNamespaceURI(prefix);
        if (nameSpace == null) {
            throw new AddressingException("Invalid QName node.");
        }
        return new QName(nameSpace, local, prefix);

    }

    public static final DocumentBuilder docBuilder;

    static {
        try {
            docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            throw new AddressingException(e);
        }
    }
}
