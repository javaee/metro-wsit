/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: AddressingConstantsImpl.java,v 1.1 2006/07/24 22:26:55 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved.
 */

package com.sun.xml.ws.addressing.v200408;

import javax.xml.namespace.QName;
import javax.xml.ws.addressing.AddressingConstants;

/**
 * Version specific constants for W3C WS-Addressing member submission
 *
 * @author JAX-WSA Development Team
 */
public class AddressingConstantsImpl implements AddressingConstants {
    
    /** Creates a new instance of AddressingConstantsImpl */
    public AddressingConstantsImpl() {
    }

    public String getNamespaceURI() {
        return Constants.WSA_NAMESPACE_NAME;
    }

    public String getNamespacePrefix() {
        return Constants.WSA_NAMESPACE_PREFIX;
    }

    public String getWSDLNamespaceURI() {
        return Constants.WSA_NAMESPACE_WSDL_NAME;
    }

    public String getWSDLNamespacePrefix() {
        return Constants.WSA_NAMESPACE_WSDL_PREFIX;
    }
    
    public QName getWSDLExtensionQName() {
        return null;
    }

    public QName getWSDLAnonymousExtensionQName() {
        return null;
    }

    public QName getWSDLActionQName() {
        return Constants.WSAW_ACTION_QNAME;
    }

    public String getAnonymousURI() {
        return Constants.WSA_ANONYMOUS_ADDRESS;
    }
    
    public String getNoneURI() {
        return Constants.WSA_NONE_ADDRESS;
    }

    public QName getFromQName() {
        return Constants.WSA_FROM_QNAME;
    }
    
    public QName getToQName() {
        return Constants.WSA_TO_QNAME;
    }
    
    public QName getReplyToQName() {
        return Constants.WSA_REPLYTO_QNAME;
    }
    
    public QName getFaultToQName() {
        return Constants.WSA_FAULTTO_QNAME;
    }

    public QName getActionQName() {
        return Constants.WSA_ACTION_QNAME;
    }
    
    public QName getMessageIDQName() {
        return Constants.WSA_MESSAGEID_QNAME;
    }
    
    public String getRelationshipReplyName() {
        return Constants.WSA_RELATIONSHIP_REPLY;
    }
    
    public QName getRelatesToQName() {
        return Constants.WSA_RELATESTO_QNAME;
    }
    
    public QName getRelationshipTypeQName() {
        return Constants.WSA_RELATIONSHIPTYPE_QNAME;
    }
    
    public QName getMetadataQName() {
        return Constants.WSA_METADATA_QNAME;
    }
    
    public QName getAddressQName() {
        return Constants.WSA_ADDRESS_QNAME;
    }
    
    public String getPackageName() {
        return Constants.PACKAGE_NAME;
    }
    
    public QName getIsReferenceParameterQName() {
        return Constants.IS_REFERENCE_PARAMETER_QNAME;
    }
    
    public QName getInvalidMapQName() {
        return Constants.INVALID_MAP_QNAME;
    }
    
    public QName getMapRequiredQName() {
        return Constants.MAP_REQUIRED_QNAME;
    }
    
    public QName getDestinationUnreachableQName() {
        return Constants.DESTINATION_UNREACHABLE_QNAME;
    }
    
    public QName getActionNotSupportedQName() {
        return Constants.ACTION_NOT_SUPPORTED_QNAME;
    }
    
    public QName getEndpointUnavailableQName() {
        return Constants.ENDPOINT_UNAVAILABLE_QNAME;
    }
    
    public String getDefaultFaultAction() {
        return Constants.WSA_DEFAULT_FAULT_ACTION;
    }
    
    public String getActionNotSupportedText() {
        return Constants.ACTION_NOT_SUPPORTED_TEXT;
    }
    
    public String getDestinationUnreachableText() {
        return Constants.DESTINATION_UNREACHABLE_TEXT;
    }
    
    public String getEndpointUnavailableText() {
        return Constants.ENDPOINT_UNAVAILABLE_TEXT;
    }
    
    public String getInvalidMapText() {
        return Constants.INVALID_MAP_TEXT;
    }
        
    public String getMapRequiredText() {
        return Constants.MAP_REQUIRED_TEXT;
    }

    public QName getFaultDetailQName() {
        return Constants.FAULT_DETAIL_QNAME;
    }
}
