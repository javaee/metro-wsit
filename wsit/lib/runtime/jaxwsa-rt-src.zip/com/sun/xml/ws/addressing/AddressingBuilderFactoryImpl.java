/*
 The contents of this file are subject to the terms
 of the Common Development and Distribution License
 (the "License").  You may not use this file except
 in compliance with the License.
 
 You can obtain a copy of the license at
 https://jwsdp.dev.java.net/CDDLv1.0.html
 See the License for the specific language governing
 permissions and limitations under the License.
 
 When distributing Covered Code, include this CDDL
 HEADER in each file and include the License file at
 https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 add the following below this CDDL HEADER, with the
 fields enclosed by brackets "[]" replaced with your
 own identifying information: Portions Copyright [yyyy]
 [name of copyright owner]
*/
/*
 $Id: AddressingBuilderFactoryImpl.java,v 1.1 2006/07/24 22:26:58 arungupta Exp $

 Copyright (c) 2006 Sun Microsystems, Inc.
 All rights reserved.
*/

package com.sun.xml.ws.addressing;

import javax.xml.ws.addressing.AddressingBuilder;
import javax.xml.ws.addressing.AddressingBuilderFactory;
import javax.xml.ws.addressing.AddressingConstants;

import java.util.HashMap;
import java.util.Map;

import com.sun.xml.ws.addressing.jaxws.WsaFactoryHelper;
import com.sun.xml.ws.addressing.jaxws.WsaPipeHelper;
import com.sun.xml.ws.api.BindingID;

/**
 * @author Arun Gupta
 */
public class AddressingBuilderFactoryImpl extends AddressingBuilderFactory implements WsaFactoryHelper {
    private static final Map<String, AddressingBuilder> abMap = new HashMap<String, AddressingBuilder>();

    static {
        abMap.put(com.sun.xml.ws.addressing.Constants.WSA_NAMESPACE_NAME, new com.sun.xml.ws.addressing.AddressingBuilderImpl());
        abMap.put(com.sun.xml.ws.addressing.v200408.Constants.WSA_NAMESPACE_NAME, new com.sun.xml.ws.addressing.v200408.AddressingBuilderImpl());
    }

    @Override
    public AddressingBuilder newAddressingBuilder() {
        return abMap.get(com.sun.xml.ws.addressing.Constants.WSA_NAMESPACE_NAME);
    }

    @Override
    public AddressingBuilder newAddressingBuilder(String namespace) {
        return abMap.get(namespace);
    }

    @Override
    public boolean isSupported(String namespace) {
        return abMap.keySet().contains(namespace);
    }

    public boolean isAddressingEnabled(BindingID binding) {
        if (binding == null)
            return false;

        String param = binding.getParameter("addressing", "");

        return param.equals("1.0") || param.equals("submission");
    }

    public boolean isW3CVersion(BindingID bid) {
        if (bid == null)
            return false;

        String param = bid.getParameter("addressing", "");

        if (param == null)
            return false;

        return param.equals("1.0");
    }

    public AddressingConstants newAddressingConstants(BindingID binding) {
        if (isW3CVersion(binding))
            return new AddressingConstantsImpl();
        else
            return new com.sun.xml.ws.addressing.v200408.AddressingConstantsImpl();
    }
}
