/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: WsaRuntimeFactory.java,v 1.1.2.6 2006/06/16 02:00:00 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved.
 */

package com.sun.xml.ws.addressing.spi;

import com.sun.xml.ws.api.message.Packet;
import com.sun.xml.ws.api.model.wsdl.WSDLPort;
import com.sun.xml.ws.api.model.SEIModel;
import com.sun.xml.ws.api.WSBinding;

import javax.xml.ws.addressing.AddressingProperties;

/**
 * @author JAX-WSA Development Team
 */
public abstract class WsaRuntimeFactory {
    private static final WsaRuntimeFactory factory = new WsaRuntimeFactoryImpl();
    protected static SEIModel seiModel;
    protected static WSDLPort wsdlPort;
    protected static WSBinding wsBinding;

    /**
     * Provides an instance of WsaRuntimeFactory.
     *
     * @param port WSDLPort from the requesting pipe.
     * @param binding WSBinding from the requesting pipe.
     * @return WsaRuntimeFactory
     */
    public static WsaRuntimeFactory newInstance(WSDLPort port, WSBinding binding) {
        return newInstance(null, port, binding);
    }

    /**
     * Provides an instance of WsaRuntimeFactory.
     *
     * @param sModel SEI Model.
     * @param port WSDLPort from the requesting pipe.
     * @param binding WSBinding from the requesting pipe.
     * @return WsaRuntimeFactory
     */
    public static WsaRuntimeFactory newInstance(SEIModel sModel, WSDLPort port, WSBinding binding) {
        seiModel = sModel;
        wsdlPort = port;
        wsBinding = binding;

        return factory;
    }

    /**
     * Writes the headers populated in AddressingContext in Pipe.getMessage()
     *
     * @param p Packet from the requesting pipe
     * @param ap AddressingProperties from the requesting pipe
     */
    public abstract void writeHeaders(Packet p, AddressingProperties ap);

    /**
     * Reads the headers from Pipe.getMessage()
     *
     * @param p Packet from the requesting pipe
     */
    public abstract AddressingProperties readHeaders(Packet p);

    /**
     * Initializes the inbound addressing properties to outbound
     *
     * @param inbound inbound addressing properties
     * @param packet Packet from the requesting pipe
     */
    public abstract AddressingProperties toOutbound(AddressingProperties inbound, Packet packet);

}
