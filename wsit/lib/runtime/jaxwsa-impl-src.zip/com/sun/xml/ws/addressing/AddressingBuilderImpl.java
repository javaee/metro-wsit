/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: AddressingBuilderImpl.java,v 1.9.2.4 2006/04/06 22:21:12 arungupta Exp $
 * 
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package com.sun.xml.ws.addressing;

import static com.sun.xml.ws.addressing.Constants.WSA_NAMESPACE_NAME;

import javax.xml.namespace.QName;
import javax.xml.ws.addressing.AddressingConstants;
import javax.xml.ws.addressing.AddressingProperties;
import javax.xml.ws.addressing.AttributedQName;
import javax.xml.ws.addressing.AttributedURI;
import javax.xml.ws.addressing.EndpointReference;
import javax.xml.ws.addressing.Relationship;
import javax.xml.ws.addressing.soap.SOAPAddressingBuilder;
import java.net.URI;

/**
 * @author JAX-WSA Development Team
 */
public class AddressingBuilderImpl extends SOAPAddressingBuilder {

    public AttributedURI newURI(URI uri) {
        return new AttributedURIImpl(uri);
    }
    
    public AttributedURI newURI(String str) {
        return new AttributedURIImpl(URI.create(str));
    }

    public Relationship newRelationship(URI uri) {
        return new RelationshipImpl(uri);
    }

    public Relationship newRelationship(String uri) {
        return new RelationshipImpl(uri);
    }

    public EndpointReference newEndpointReference(URI uri) {
        return new EndpointReferenceImpl(uri);
    }

    public EndpointReference newEndpointReference(String uri) {
        return new EndpointReferenceImpl(uri);
    }

    public AddressingProperties newAddressingProperties() {
        return new AddressingPropertiesImpl();
    }

    public AttributedQName newQName(QName name) {
        return new AttributedQNameImpl(name);
    }

    public AttributedQName newQName(String namespace, String localname) {
        return new AttributedQNameImpl(new QName(namespace, localname));
    }

    public AddressingConstants newAddressingConstants() {
        return new AddressingConstantsImpl();
    }

    public String getNamespaceURI() {
        return WSA_NAMESPACE_NAME;
    }
}
