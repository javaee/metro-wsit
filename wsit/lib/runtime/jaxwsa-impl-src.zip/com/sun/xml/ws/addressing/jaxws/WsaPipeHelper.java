/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: WsaPipeHelper.java,v 1.1.2.50 2006/06/16 02:02:40 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved.
 */

package com.sun.xml.ws.addressing.jaxws;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.lang.reflect.Method;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.Detail;
import javax.xml.soap.SOAPConstants;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.ws.addressing.ActionNotSupportedException;
import javax.xml.ws.addressing.AddressingBuilder;
import javax.xml.ws.addressing.AddressingConstants;
import javax.xml.ws.addressing.AddressingException;
import javax.xml.ws.addressing.AddressingProperties;
import javax.xml.ws.addressing.AttributedURI;
import javax.xml.ws.addressing.EndpointReference;
import javax.xml.ws.addressing.InvalidMapException;
import javax.xml.ws.addressing.JAXWSAConstants;
import javax.xml.ws.addressing.MapRequiredException;
import javax.xml.ws.addressing.ReferenceParameters;
import javax.xml.ws.addressing.Relationship;
import javax.jws.WebMethod;

import com.sun.tools.ws.util.xml.XmlUtil;
import com.sun.xml.ws.api.EndpointAddress;
import com.sun.xml.ws.api.SOAPVersion;
import com.sun.xml.ws.api.WSBinding;
import com.sun.xml.ws.api.message.Header;
import com.sun.xml.ws.api.message.HeaderList;
import com.sun.xml.ws.api.message.Headers;
import com.sun.xml.ws.api.message.Message;
import com.sun.xml.ws.api.message.Messages;
import com.sun.xml.ws.api.message.Packet;
import com.sun.xml.ws.api.model.wsdl.WSDLBoundOperation;
import com.sun.xml.ws.api.model.wsdl.WSDLFault;
import com.sun.xml.ws.api.model.wsdl.WSDLOperation;
import com.sun.xml.ws.api.model.wsdl.WSDLPort;
import com.sun.xml.ws.api.model.SEIModel;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * @author JAX-WSA Development Team
 */
public abstract class WsaPipeHelper {

    public void writeHeaders(Packet packet, AddressingProperties ap) {
        Message message = packet.getMessage();
        HeaderList hl = message.getHeaders();
        SOAPVersion soapVersion = binding.getSOAPVersion();

        if (ap.getTo() != null && !ap.getTo().equals("")) {
            hl.add(Headers.create(soapVersion, marshaller, ac.getToQName(), ap.getTo()));
        }

        if (ap.getMessageID() != null && !ap.getMessageID().equals("")) {
            hl.add(Headers.create(soapVersion, marshaller, ac.getMessageIDQName(), ap.getMessageID()));
        }

        if (ap.getFrom() != null && !ap.getFrom().equals("")) {
            hl.add(Headers.create(soapVersion, marshaller, ac.getFromQName(), ap.getFrom()));
        }

        if (ap.getReplyTo() != null && !ap.getReplyTo().equals("")) {
            hl.add(Headers.create(soapVersion, marshaller, ac.getReplyToQName(), ap.getReplyTo()));
        }

        if (ap.getFaultTo() != null && !ap.getFaultTo().equals("")) {
            hl.add(Headers.create(soapVersion, marshaller, ac.getFaultToQName(), ap.getFaultTo()));
        }

        if (ap.getAction() != null && !ap.getAction().equals("")) {
            hl.add(Headers.create(soapVersion, marshaller, ac.getActionQName(), ap.getAction()));
            packet.soapAction = ap.getAction().toString();
        }

        if (ap.getReferenceParameters() != null && !ap.getReferenceParameters().getElements().isEmpty()) {
            ReferenceParameters refps = ap.getReferenceParameters();
            for (Object refp : refps.getElements()) {
                if (refp instanceof Element) {
                    hl.add(Headers.create(soapVersion, (Element)refp));
                }
            }
        }

        if (ap.getRelatesTo() != null && ap.getRelatesTo().length > 0) {
            for (Relationship rel : ap.getRelatesTo()) {
                hl.add(Headers.create(soapVersion, marshaller, ac.getRelatesToQName(), rel));
            }
        }
    }

    private AddressingProperties readInboundHeaders(Packet packet, StringBuffer mid) {
        Message message = packet.getMessage();

        if (message == null)
            return null;

        if (message.getHeaders() == null)
            return null;

        AddressingProperties ap = ab.newAddressingProperties();
        java.util.Iterator<Header> hIter = message.getHeaders().getHeaders(ab.getNamespaceURI(), true);

        try {
            Header midHeader = message.getHeaders().get(ac.getMessageIDQName(), true);
            if (midHeader != null) {
                mid.append(((AttributedURI)((JAXBElement)midHeader.readAsJAXB(unmarshaller)).getValue()).getURI().toString());
            }

            QName faultyHeader = null;

            while (hIter.hasNext()) {
                Header h = hIter.next();

                // check if the Header is in current role
                if (!isInCurrentRole(h)) {
                    continue;
                }

                String local = h.getLocalPart();
                if (local.equals(ac.getFromQName().getLocalPart())) {
                    if (ap.getFrom() != null) {
                        faultyHeader = ac.getFromQName();
                        break;
                    }
                    ap.setFrom((EndpointReference)((JAXBElement)h.readAsJAXB(unmarshaller)).getValue());
                } else if (local.equals(ac.getToQName().getLocalPart())) {
                    if (ap.getTo() != null) {
                        faultyHeader = ac.getToQName();
                        break;
                    }
                    ap.setTo((AttributedURI)((JAXBElement)h.readAsJAXB(unmarshaller)).getValue());
                } else if (local.equals(ac.getReplyToQName().getLocalPart())) {
                    if (ap.getReplyTo() != null) {
                        faultyHeader = ac.getReplyToQName();
                        break;
                    }
                    ap.setReplyTo((EndpointReference)((JAXBElement)h.readAsJAXB(unmarshaller)).getValue());
                } else if (local.equals(ac.getFaultToQName().getLocalPart())) {
                    if (ap.getFaultTo() != null) {
                        faultyHeader = ac.getFaultToQName();
                        break;
                    }
                    ap.setFaultTo((EndpointReference)((JAXBElement)h.readAsJAXB(unmarshaller)).getValue());
                } else if (local.equals(ac.getActionQName().getLocalPart())) {
                    if (ap.getAction() != null) {
                        faultyHeader = ac.getActionQName();
                        break;
                    }
                    ap.setAction((AttributedURI)((JAXBElement)h.readAsJAXB(unmarshaller)).getValue());
                } else if (local.equals(ac.getMessageIDQName().getLocalPart())) {
                    if (ap.getMessageID() != null) {
                        faultyHeader = ac.getMessageIDQName();
                        break;
                    }
                    ap.setMessageID((AttributedURI)((JAXBElement)h.readAsJAXB(unmarshaller)).getValue());
                } else if (local.equals(ac.getRelatesToQName().getLocalPart())) {

                    // TODO: RelatesTo header is unmarshalled twice
                    // TODO: needs cleanup
                    AttributedURI mid2 = (AttributedURI)((JAXBElement)h.readAsJAXB(unmarshaller)).getValue();
                    Relationship rel = ab.newRelationship(mid2.getURI());
                    if (mid2.getAttributes() != null) {
                        String relType = mid2.getAttributes().get(ac.getRelationshipTypeQName());
                        if (relType != null) {
                            rel.setType(relType);
                        }
                    }
                    List<Relationship> lRels = new ArrayList<Relationship>();
                    if (ap.getRelatesTo() != null) {
                        Relationship[] rels = ap.getRelatesTo();
                        for (Relationship r : rels) {
                            lRels.add(r);
                        }
                    }
                    lRels.add(rel);
                    ap.setRelatesTo(lRels.toArray(new Relationship[0]));
                } else if (local.equals(ac.getFaultDetailQName().getLocalPart())) {
                    // TODO: should anything be done here ?
                    // TODO: fault detail element - only for SOAP 1.1
                } else {
                    throw new AddressingException("unknown WS-A header");
                }
            }

            if (faultyHeader != null) {
                throw new InvalidMapException(faultyHeader, InvalidMapException.INVALID_CARDINALITY);
            }

            HeaderList hl = message.getHeaders();
            for (Header h : hl) {
                if (isReferenceParameter(h)) {
                    ap.getReferenceParameters().addElement(unmarshalRefp(h));
                }
            }

        } catch (JAXBException e) {
            throw new AddressingException(e);
        }

        return ap;
    }

    private AddressingProperties readInboundHeaders(Packet packet) {
        StringBuffer mid = new StringBuffer();
        return readInboundHeaders(packet, mid);
    }

    private boolean isInCurrentRole(Header header) {
        String role;

        // TODO: binding will be null for protocol messages
        // TODO: returning true assumes that protocol messages are
        // TODO: always in current role, this may not to be fixed.
        if (binding == null)
            return true;

        if (binding.getSOAPVersion() == SOAPVersion.SOAP_11) {
            return true;
        } else {
            role = header.getAttribute(s12Role);

            return !(role != null && role.equals(SOAPConstants.URI_SOAP_1_2_ROLE_NONE));
        }
    }

    public final Packet readClientInboundHeaders(Packet packet) {
        AddressingProperties ap = readInboundHeaders(packet);

        if (ap != null) {
            packet.invocationProperties.put(JAXWSAConstants.CLIENT_ADDRESSING_PROPERTIES, ap);
        }

        return packet;
    }

    public final Packet readServerInboundHeaders(Packet packet) {
        // no need to re-read WS-A headers if already read
        if (packet.invocationProperties.get(JAXWSAConstants.SERVER_ADDRESSING_PROPERTIES_INBOUND) != null) {
            return prepareOutbound(packet);
        }

        wbo = packet.getMessage().getOperation(wsdlPort);
        AddressingProperties inbound = null;

        SOAPFault soapFault = null;
        Element s11FaultDetail = getSoap11FaultDetail();
        StringBuffer mid = new StringBuffer();

        try {
            inbound = readInboundHeaders(packet, mid);

            // TODO: RelatesTo header in case of WS-A faults
            checkMandatoryHeaders(inbound);

            packet.invocationProperties.put(JAXWSAConstants.SERVER_ADDRESSING_PROPERTIES_INBOUND, inbound);

            return prepareOutbound(packet);
        } catch (InvalidMapException e) {
            soapFault = newInvalidMapFault(e);
            getInvalidMapDetail(e.getMapQName(), s11FaultDetail);
        } catch (MapRequiredException e) {
            soapFault = newMapRequiredFault(e);
            getMapRequiredDetail(e.getName(), s11FaultDetail);
        } catch (ActionNotSupportedException e) {
            soapFault = newActionNotSupportedFault(e.getAction());
            getProblemActionDetail(e.getAction(), s11FaultDetail);
        }

        if (soapFault != null) {
            Message m = Messages.create(soapFault);
            Header defaultFaultAction = Headers.create(binding.getSOAPVersion(), marshaller, ac.getActionQName(), ab.newURI(ac.getDefaultFaultAction()));
            Header actionHeader = m.getHeaders().get(ac.getActionQName(), true);
            if (actionHeader == null) {
                m.getHeaders().add(defaultFaultAction);
            } else {
                // TODO: use the default fault actions for service-specific faults
                // TODO: this will make W3C CR happy for now

                // remove any existing Action headers
                m.getHeaders().remove(actionHeader);

                // add the default fault action header
                m.getHeaders().add(defaultFaultAction);
            }

            if (binding.getSOAPVersion() == SOAPVersion.SOAP_11) {
                m.getHeaders().add(Headers.create(s11FaultDetail));
            }

            if (mid != null) {
                Relationship rel = ab.newRelationship(mid.toString());
                m.getHeaders().add(Headers.create(binding.getSOAPVersion(), marshaller, ac.getRelatesToQName(), rel));
            }

            return packet.createResponse(m);
        }

        return packet;
    }

    /**
     * Validates inbound Action and prepares outbound Action
     * @param packet inbound packet
     * @return Packet with outbound action
     */
    private Packet prepareOutbound(Packet packet) {
        AddressingProperties inbound = (AddressingProperties)packet.invocationProperties.get(JAXWSAConstants.SERVER_ADDRESSING_PROPERTIES_INBOUND);

        //There may not be a WSDL operation.  There may not even be a WSDL.
        //For instance this may be a RM CreateSequence message.
        WSDLBoundOperation wbo = null;
        if (wsdlPort != null) {
            wbo = packet.getMessage().getOperation(wsdlPort);
        }

        WSDLOperation op = null;

        if (wbo != null) {
            op = wbo.getOperation();
        }

        if (wbo == null || op == null) {
            return packet;
        }

        if (op.isOneWay()) {
            validateAction(packet, inbound.getAction());
            return packet;
        }

        AddressingProperties outbound = toOutbound(inbound, packet);

        if (packet.invocationProperties.get(JAXWSAConstants.SERVER_ADDRESSING_PROPERTIES_OUTBOUND) == null) {
            packet.invocationProperties.put(JAXWSAConstants.SERVER_ADDRESSING_PROPERTIES_OUTBOUND, outbound);
        }

        validateAction(packet, inbound.getAction());

        return packet;
    }

    public final AddressingProperties toOutbound(AddressingProperties inbound, Packet packet) {
        AddressingProperties outbound = ab.newAddressingProperties();
        outbound.initializeAsReply(inbound);
        outbound.setAction(ab.newURI(getOutputAction(packet)));

        return outbound;
    }

    public final Packet writeClientOutboundHeaders(Packet packet) {
        AddressingProperties props = (AddressingProperties)packet.proxy.getRequestContext().get(JAXWSAConstants.CLIENT_ADDRESSING_PROPERTIES);

        if (props == null) {
            props = ab.newAddressingProperties();
//            throw new AddressingException("no outbound addressing properties");
        }

        if (props.getTo() == null) {
            EndpointAddress to = packet.endpointAddress;
            if (to == null)
                to = EndpointAddress.create("http://null.ENDPOINT_ADDRESS_PROPERTY");
            props.setTo(ab.newURI(to.toString()));
        }

        // TODO: Cache UUID generation since it's expensive operation
        if (props.getMessageID() == null) {
            props.setMessageID(ab.newURI("uuid:" + UUID.randomUUID().toString()));
        }

        if (props.getReplyTo() == null) {
            // null or "true" is equivalent to request/response MEP
            if (wsdlPort != null && !packet.getMessage().isOneWay(wsdlPort)) {
                EndpointReference epr = ab.newEndpointReference(ac.getAnonymousURI());
                props.setReplyTo(epr);
            }
        }

        //Choose wsa:Action and SOAPAction HTTP Header.
        //
        //Per WS-Addressing spec, these must always be the same.  There are several possible
        //  values:
        //     1. Value of wsaw:Action set by programmer in BindingProviderProperties.
        //     2. Value of wsaw:Action in WSDL
        //     4. Default value based on (namespace URI)/portTypeName/operation.
        if (props.getAction() == null) {
            String ia = getInputAction(packet);
            if (isInputActionDefault(packet) && (packet.soapAction != null && !packet.soapAction.equals(""))) {
                ia = packet.soapAction;
            }
            props.setAction(ab.newURI(ia == null ? "http://fake.input.action" : ia));
        }


        packet.soapAction = props.getAction().toString();

        writeHeaders(packet, props);

        packet.proxy.getRequestContext().put(JAXWSAConstants.CLIENT_ADDRESSING_PROPERTIES, ab.newAddressingProperties());

        return packet;
    }

    public final Packet writeServerOutboundHeaders(Packet packet) {
        // outbound addressing context is populated only for non oneway messages
        AddressingProperties outbound = (AddressingProperties)packet.invocationProperties.get(JAXWSAConstants.SERVER_ADDRESSING_PROPERTIES_OUTBOUND);
        if (outbound == null) {
            return packet;
        }

        Message message = packet.getMessage();
        if (message == null) {
            return packet;
        }

        // set FaultTo reference parameters
        if (message.isFault()) {
            AddressingProperties inbound = (AddressingProperties)packet.invocationProperties.get(JAXWSAConstants.SERVER_ADDRESSING_PROPERTIES_INBOUND);
            outbound.initializeAsFault(inbound);

            String action = getFaultAction(message);
            if (action != null)
                outbound.setAction(action);
        }

        if (outbound.getTo() == null) {
            EndpointAddress to = packet.endpointAddress;
            if (to == null)
                to = EndpointAddress.create("http://null.ENDPOINT_ADDRESS_PROPERTY");
            outbound.setTo(ab.newURI(to.toString()));
        }

        writeHeaders(packet, outbound);

        return packet;
    }

    private String getFaultAction(Message message) {
        String action = ac.getDefaultFaultAction();

        if (wsdlPort == null)
            return null;

        try {
            SOAPMessage sm = message.readAsSOAPMessage();
            if (sm == null)
                return action;

            if (sm.getSOAPBody() == null)
                return action;

            if (sm.getSOAPBody().getFault() == null)
                return action;

            Detail detail = sm.getSOAPBody().getFault().getDetail();
            if (detail == null)
                return action;

            String ns = detail.getFirstChild().getNamespaceURI();
            String name = detail.getFirstChild().getLocalName();

            WSDLOperation o = wbo.getOperation();
            if (o == null)
                return action;

            WSDLFault fault = o.getFault(new QName(ns, name));
            if (fault == null)
                return action;

            WsaWSDLOperationExtension ww = wbo.getOperation().getExtension(WsaWSDLOperationExtension.class);
            if (ww == null)
                return action;

            if (ww.getFaultAction(fault.getName()) != null)
                action = ww.getFaultAction(fault.getName());

            return action;
        } catch (SOAPException e) {
            throw new AddressingException(e);
        }
    }

    private QName tagname(Message message) {
        SOAPMessage sm;
        try {
            sm = message.readAsSOAPMessage();
            Node detail = sm.getSOAPBody().getFault().getDetail().getFirstChild();
            return new QName(detail.getNamespaceURI(), detail.getLocalName());
        } catch (SOAPException e) {
            throw new AddressingException(e);
        }
    }

    private boolean isReferenceParameter(Header h) {
        String val = h.getAttribute(ac.getIsReferenceParameterQName());

        return (val != null && Boolean.valueOf(val));
    }

    private Object unmarshalRefp(Header h) {
        try {
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
            Element element = doc.createElement("wrapper");
            DOMResult dom = new DOMResult();
            dom.setNode(element);
            XMLStreamWriter xsw = XMLOutputFactory.newInstance().createXMLStreamWriter(dom);
            h.writeTo(xsw);
            DOMSource source = new DOMSource(dom.getNode().getFirstChild());
            DOMResult result = new DOMResult();

            XmlUtil.newTransformer().transform(source, result);
            return result.getNode().getFirstChild();
        } catch (Exception ex) {
            throw new AddressingException(ex);
        }
    }

    private void validateAction(Packet packet, AttributedURI gotA) {
        // TODO: For now, validation happens only on server-side
        if (packet.proxy != null) {
            return;
        }

        if (gotA == null)
            throw new AddressingException("null input action"); // TODO: i18n

        String got = gotA.toString();
        if (got == null)
            throw new AddressingException("null string in input action");   // TODO: i18n

        // TODO: is this a valid check ?
        // TODO: wsaw:Action may be explcitly set to "".
        if (got.length() == 0)
            throw new AddressingException("0-length input action"); // TODO: i18n

        String expected = getInputAction(packet);
        String soapAction = getSOAPAction(packet);
        if (isInputActionDefault(packet) && !soapAction.equals(""))
            expected = soapAction;

        if (expected != null && !got.equals(expected)) {
            throw new ActionNotSupportedException(got);
        }
    }

    private String getInputAction(Packet packet) {
        String action = null;
        WsaWSDLOperationExtension ww = null;

        if (wsdlPort != null) {
            if (wsdlPort.getBinding() != null) {
                WSDLBoundOperation wbo = wsdlPort.getBinding().getOperation(packet.getMessage().getPayloadNamespaceURI(), packet.getMessage().getPayloadLocalPart());
                if (wbo != null) {
                    WSDLOperation op = wbo.getOperation();
                    if (op != null) {
                        ww = op.getExtension(WsaWSDLOperationExtension.class);
                        if (ww != null) {
                            action = ww.getInputAction();
                        }
                    }
                }
            }
        }

        return action;
    }

    private boolean isInputActionDefault(Packet packet) {
        if (wsdlPort == null)
            return false;

        if (wsdlPort.getBinding() == null)
            return false;

        WSDLBoundOperation wbo = wsdlPort.getBinding().getOperation(packet.getMessage().getPayloadNamespaceURI(), packet.getMessage().getPayloadLocalPart());
        if (wbo == null)
            return false;

        WSDLOperation op = wbo.getOperation();
        if (op == null)
            return false;

        WsaWSDLOperationExtension ww = op.getExtension(WsaWSDLOperationExtension.class);
        if (ww != null)
            return ww.isInputDefault();
        else
            return false;
    }

    private String getSOAPAction(Packet packet) {
        String action = "";

        if (packet.getMessage() == null)
            return action;

        Method method = packet.getMessage().getMethod(seiModel);
        if (method == null)
            return action;

        WebMethod webMethod = method.getAnnotation(WebMethod.class);
        if (webMethod == null)
            return action;

        if (!webMethod.action().equals(""))
            return webMethod.action();

        return action;
    }

    private String getOutputAction(Packet packet) {
        String action = "http://fake.output.action";
        WsaWSDLOperationExtension ww = null;

        if (wsdlPort != null) {
            if (wsdlPort.getBinding() != null) {
                WSDLBoundOperation wbo = wsdlPort.getBinding().getOperation(packet.getMessage().getPayloadNamespaceURI(), packet.getMessage().getPayloadLocalPart());
                if (wbo != null) {
                    WSDLOperation op = wbo.getOperation();
                    if (op != null) {
                        ww = op.getExtension(WsaWSDLOperationExtension.class);
                        if (ww != null) {
                            action = ww.getOutputAction();
                        }
                    }
                }
            }
        }

        return action;
    }

    private SOAPFault newActionNotSupportedFault(String action) {
        QName subcode = ac.getActionNotSupportedQName();
        String faultstring = String.format(ac.getActionNotSupportedText(), action);

        try {
            SOAPFactory factory;
            SOAPFault fault;
            if (binding.getSOAPVersion() == SOAPVersion.SOAP_12) {
                factory = SOAPVersion.SOAP_12.saajSoapFactory;
                fault = factory.createFault();
                fault.setFaultCode(JAXWSAConstants.SOAP12_SENDER_QNAME);
                fault.appendFaultSubcode(subcode);
                getProblemActionDetail(action, fault.addDetail());
            } else {
                factory = SOAPVersion.SOAP_11.saajSoapFactory;
                fault = factory.createFault();
                fault.setFaultCode(subcode);
            }

            fault.setFaultString(faultstring);

            return fault;
        } catch (SOAPException e) {
            throw new AddressingException(e);
        }
    }

    private SOAPFault newInvalidMapFault(InvalidMapException e) {
        QName name = e.getMapQName();
        QName subsubcode = e.getSubsubcode();
        QName subcode = ac.getInvalidMapQName();
        String faultstring = String.format(ac.getInvalidMapText(), name, subsubcode);

        try {
            SOAPFactory factory;
            SOAPFault fault;
            if (binding.getSOAPVersion() == SOAPVersion.SOAP_12) {
                factory = SOAPVersion.SOAP_12.saajSoapFactory;
                fault = factory.createFault();
                fault.setFaultCode(JAXWSAConstants.SOAP12_SENDER_QNAME);
                fault.appendFaultSubcode(subcode);
                fault.appendFaultSubcode(subsubcode);
                getInvalidMapDetail(name, fault.addDetail());
            } else {
                factory = SOAPVersion.SOAP_11.saajSoapFactory;
                fault = factory.createFault();
                fault.setFaultCode(subsubcode);
            }

            fault.setFaultString(faultstring);

            return fault;
        } catch (SOAPException se) {
            throw new AddressingException(se);
        }
    }

    private SOAPFault newMapRequiredFault(MapRequiredException e) {
        QName subcode = e.getSubcode();
        QName subsubcode = ac.getMapRequiredQName();
        String faultstring = ac.getMapRequiredText();

        try {
            SOAPFactory factory;
            SOAPFault fault;
            if (binding.getSOAPVersion() == SOAPVersion.SOAP_12) {
                factory = SOAPVersion.SOAP_12.saajSoapFactory;
                fault = factory.createFault();
                fault.setFaultCode(JAXWSAConstants.SOAP12_SENDER_QNAME);
                fault.appendFaultSubcode(subcode);
                fault.appendFaultSubcode(subsubcode);
                getMapRequiredDetail(e.getName(), fault.addDetail());
            } else {
                factory = SOAPVersion.SOAP_11.saajSoapFactory;
                fault = factory.createFault();
                fault.setFaultCode(subsubcode);
            }

            fault.setFaultString(faultstring);

            return fault;
        } catch (SOAPException se) {
            throw new AddressingException(se);
        }
    }

    private void checkMandatoryHeaders(AddressingProperties ap) {
        if (ap == null) {
            throw new AddressingException("No WS-A headers are found"); // TODO: i18n
        }

        if (ap.getAction() == null) {
            throw new MapRequiredException(ac.getActionQName());
        }

        if (ap.getTo() == null) {
            throw new MapRequiredException(ac.getToQName());
        }

        // TODO: Add check for other WS-A headers based upon MEP
    }

    protected abstract void getProblemActionDetail(String action, Element element);
    protected abstract void getInvalidMapDetail(QName name, Element element);
    protected abstract void getMapRequiredDetail(QName name, Element element);
    protected abstract Header getDefaultFaultAction();
    protected abstract SOAPElement getSoap11FaultDetail();

    protected static final DocumentBuilder db;

    static {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        try {
            db = dbf.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            throw new AddressingException(e);
        }
    }


    protected JAXBContext jc;
    protected Unmarshaller unmarshaller;
    protected Marshaller marshaller;
    protected AddressingBuilder ab;
    public AddressingConstants ac;

    protected SEIModel seiModel;
    protected WSDLPort wsdlPort;
    protected WSBinding binding;
    private WSDLBoundOperation wbo;

    private static final QName s11Role = new QName(SOAPConstants.URI_NS_SOAP_1_1_ENVELOPE, "Actor");
    private static final QName s12Role = new QName(SOAPConstants.URI_NS_SOAP_1_2_ENVELOPE, "role");
}
