/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: AttributedURIImpl.java,v 1.6.2.4 2006/04/06 22:21:12 arungupta Exp $
 * 
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package com.sun.xml.ws.addressing;

import static com.sun.xml.ws.addressing.Constants.WSA_NAMESPACE_NAME;

import javax.xml.bind.annotation.XmlType;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPElement;
import javax.xml.ws.addressing.AddressingException;
import javax.xml.ws.addressing.AttributedURI;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Map;

/**
 * @author JAX-WSA Development Team
 */
@XmlType(name = "AttributedURIType", namespace = WSA_NAMESPACE_NAME)
public class AttributedURIImpl extends AddressingValueBase implements
        AttributedURI {

    public AttributedURIImpl() {
        super(WSA_NAMESPACE_NAME);
    }

    public AttributedURIImpl(URI uri) {
        this();
        value = uri.toString();
    }

    public AttributedURIImpl(String uri) {
        this();
        value = uri;
    }

    /**
     * Accessor for the URI property.
     *
     * @return The value of the property.
     */
    public URI getURI() throws AddressingException {
        return URI.create(value);
    }

    public void addElement(SOAPElement element) throws AddressingException {
        throw new AddressingException(
                "AttributedURI type does not support Extensibility elements.");
    }

    @Override
    public void read(SOAPElement element) throws AddressingException {

        text = null;
        super.read(element);

        try {
            new URI(text);
        } catch (URISyntaxException e) {
            throw new AddressingException("Invalid URI in addressing element.", e);
        }

        value = text;
    }


    /* copy non-SOAP AttributedURI if necessary */
    public static AttributedURIImpl getAddressingElement(AttributedURI uri) {
        if (uri instanceof AttributedURIImpl) {
            return (AttributedURIImpl) uri;
        }

        AttributedURIImpl impl = new AttributedURIImpl(uri.getURI());
        Map<QName, String> atts = uri.getAttributes();
        if (atts != null) {
            for (QName name : atts.keySet()) {
                impl.addAttribute(name, atts.get(name));
            }
        }

        return impl;
    }

    @Override
    public String getValue() {
        return value;
    }

    public String toString() {
        return value;
    }
}
