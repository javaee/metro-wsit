/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: WsaJavaGeneratorExtension.java,v 1.1.2.8 2006/06/14 00:26:49 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved.
 */

package com.sun.xml.ws.addressing.jaxws;

import com.sun.codemodel.JAnnotationArrayMember;
import com.sun.codemodel.JAnnotationUse;
import com.sun.codemodel.JClass;
import com.sun.codemodel.JMethod;
import com.sun.tools.ws.api.TJavaGeneratorExtension;
import com.sun.tools.ws.api.wsdl.TWSDLExtension;
import com.sun.tools.ws.api.wsdl.TWSDLOperation;

import javax.xml.ws.addressing.Action;
import javax.xml.ws.addressing.FaultAction;
import java.util.Map;

/**
 * @author JAX-WSA Development Team
 */
public class WsaJavaGeneratorExtension extends TJavaGeneratorExtension {

    @Override
    public void writeMethodAnnotations(TWSDLOperation two, JMethod jMethod) {
        JAnnotationUse actionAnn = null;

        WsaWSDLOperationExtension ww = getWsaExtension(two);
        if (ww == null)
            return;

        // explicit input action
        if (ww.getInputAction() != null && !ww.getInputAction().equals("")) {
            // explicitly specified
            actionAnn = jMethod.annotate(Action.class);
            actionAnn.param("input", ww.getInputAction());
        }

        // explicit output action
        if (ww.getOutputAction() != null && !ww.getOutputAction().equals("")) {
            // explicitly specified
            if (actionAnn == null)
                actionAnn = jMethod.annotate(Action.class);

            actionAnn.param("output", ww.getOutputAction());
        }

        // explicit fault action
        if (ww.getFaultActions().size() > 0) {
            Map<String, String> fasMap = ww.getFaultActions();
            Map<String, JClass> classMap = two.getFaults();

            JAnnotationArrayMember jam = null;
            for (String faultName : classMap.keySet()) {
                String fa = fasMap.get(faultName);

                if (fa == null || fa.equals(""))
                    continue;

                if (actionAnn == null) {
                    actionAnn = jMethod.annotate(Action.class);
                }
                if (jam == null) {
                    jam = actionAnn.paramArray("fault");
                }
                final JAnnotationUse faAnn = jam.annotate(FaultAction.class);
                faAnn.param("className", classMap.get(faultName));
                faAnn.param("value", fa);
            }
        }
    }

    WsaWSDLOperationExtension getWsaExtension(TWSDLOperation two) {
        if (two == null)
            return null;

        if (two.extensions() == null)
            return null;

        if (!two.extensions().iterator().hasNext())
            return null;

        for (TWSDLExtension e : two.extensions()) {
            if (e != null && e instanceof WsaWSDLOperationExtension) {
                return (WsaWSDLOperationExtension)e;
            }
        }

        return null;
    }

//
//    protected String explicitFaultAction(Fault f, Operation o, Port p) {
//        AddressingConstants c = AddressingBuilder.getAddressingBuilder().newAddressingConstants();
//        
//        HashMap<String, String> fa = (HashMap<String,String>)o.getProperty(JAXWSATooltimeModule.FAULT_ACTION);
//        String a = null;
//        
//        if (fa != null) {
//            a = fa.get(f.getWsdlFaultName());
//        }
//        
//        return a;
//    }
//    


}
