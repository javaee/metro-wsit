/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: WsaPipeLineAssemblerFactoryImpl.java,v 1.1.2.3 2006/03/28 21:13:05 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved.
 */

package com.sun.xml.ws.addressing.jaxws;

import com.sun.xml.ws.api.EndpointAddress;
import com.sun.xml.ws.api.WSBinding;
import com.sun.xml.ws.api.WSService;
import com.sun.xml.ws.api.BindingID;
import com.sun.xml.ws.api.model.wsdl.WSDLPort;
import com.sun.xml.ws.api.pipe.Pipe;
import com.sun.xml.ws.api.pipe.PipelineAssembler;
import com.sun.xml.ws.api.pipe.PipelineAssemblerFactory;
import com.sun.xml.ws.api.server.WSEndpoint;
import com.sun.xml.ws.client.dispatch.StandalonePipeAssembler;
import com.sun.xml.ws.util.pipe.DumpPipe;

/**
 *  Pipeline assembler factory.
 *
 * @author JAX-WSA Development Team
 */
public final class WsaPipeLineAssemblerFactoryImpl extends PipelineAssemblerFactory {

    public PipelineAssembler doCreate(BindingID bindingId) {
        return new StandalonePipeAssembler() {
            @Override
            public Pipe createClient(EndpointAddress address, WSDLPort wsdlModel, WSService service, WSBinding binding) {
                Pipe p;

                p = createTransport(address,wsdlModel, service, binding);

                if(Boolean.getBoolean("log")) {
                    p = new DumpPipe(System.out,p);
                }

                p = new WsaClientPipe(wsdlModel, binding, p);

                return p;
            }

            @Override
            public Pipe createServer(WSDLPort wsdlModel, WSEndpoint endpoint, Pipe terminal) {
                Pipe pipe;

                pipe = new WsaServerPipe(wsdlModel, endpoint.getBinding(), terminal);

                return pipe;
            }
        };
    }
}
