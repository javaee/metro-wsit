/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: EndpointReferenceImpl.java,v 1.12.2.5 2006/06/08 23:31:00 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package com.sun.xml.ws.addressing.v200408;

import com.sun.xml.ws.addressing.AddressingElementBase;
import com.sun.xml.ws.addressing.util.AddressingUtils;
import static com.sun.xml.ws.addressing.v200408.Constants.WSA_ADDRESS_NAME;
import static com.sun.xml.ws.addressing.v200408.Constants.WSA_ADDRESS_QNAME;
import static com.sun.xml.ws.addressing.v200408.Constants.WSA_NAMESPACE_NAME;
import static com.sun.xml.ws.addressing.v200408.Constants.WSA_REFERENCEPARAMETERS_NAME;
import static com.sun.xml.ws.addressing.v200408.Constants.WSA_REFERENCEPARAMETERS_QNAME;
import static com.sun.xml.ws.addressing.v200408.Constants.WSA_REFERENCEPROPERTIES_NAME;
import static com.sun.xml.ws.addressing.v200408.Constants.WSA_REFERENCEPROPERTIES_QNAME;
import static com.sun.xml.ws.addressing.v200408.Constants.WSA_TO_QNAME;

import javax.xml.bind.annotation.W3CDomHandler;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.addressing.AddressingException;
import javax.xml.ws.addressing.AttributedURI;
import javax.xml.ws.addressing.EndpointReference;
import static javax.xml.ws.addressing.JAXWSAConstants.SOAP_FACTORY;
import javax.xml.ws.addressing.Metadata;
import javax.xml.ws.addressing.ReferenceParameters;
import java.net.URI;
import java.util.List;

/**
 * @author JAX-WSA Development Team
 */
@XmlAccessorType(value = XmlAccessType.FIELD)
@XmlType(name = "EndpointReferenceType", namespace = WSA_NAMESPACE_NAME)
public class EndpointReferenceImpl extends AddressingElementBase implements
        EndpointReference {

    @XmlElement(name = WSA_ADDRESS_NAME, namespace = WSA_NAMESPACE_NAME)
    private AttributedURIImpl iri;

    @XmlElement(name = WSA_REFERENCEPROPERTIES_NAME, namespace = WSA_NAMESPACE_NAME)
    private ReferenceParametersImpl refParams;

    @XmlElement(name = WSA_REFERENCEPARAMETERS_NAME, namespace = WSA_NAMESPACE_NAME)
    private MetadataImpl metadata;

    //or use by JAXB
    protected EndpointReferenceImpl() {
        setNamespaceURI(WSA_NAMESPACE_NAME);
    }

    public EndpointReferenceImpl(URI uri) {
        this();
        this.iri = new AttributedURIImpl(uri);
    }

    public EndpointReferenceImpl(String uri) {
        this();
        this.iri = new AttributedURIImpl(uri);
    }

    public AttributedURI getAddress() {
        return iri;
    }

    public Metadata getMetadata() {
        if (metadata == null)
            metadata = new MetadataImpl();

        return metadata;
    }

    public ReferenceParameters getReferenceParameters() {
        if (refParams == null)
            refParams = new ReferenceParametersImpl();

        return refParams;
    }

    public void addReferenceParameter(QName name, String value) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getReferenceParameter(QName name) {
        if (getReferenceParameters() == null)
            return null;

        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    /* Copy to an instance of AddressingElement, if necessary */
    public static EndpointReferenceImpl getAddressingElement(EndpointReference ref) {
        if (ref instanceof EndpointReferenceImpl) {
            return (EndpointReferenceImpl) ref;
        }

        AttributedURIImpl attURI = AttributedURIImpl.getAddressingElement(ref.getAddress());
        EndpointReferenceImpl impl = new EndpointReferenceImpl();

        impl.iri = attURI;
        impl.metadata = MetadataImpl.getAddressingElement(ref.getMetadata());
        impl.refParams = ReferenceParametersImpl.getAddressingElement(ref.getReferenceParameters());
        return impl;
    }

    @Override
    public void read(SOAPElement element) {

        super.read(element);
        SOAPElement addressElement;

        if (elements == null
                || null == (addressElement = AddressingUtils.findElement(
                WSA_ADDRESS_QNAME, elements.iterator(), true))) {
            throw new AddressingException("Missing Address in EndpointReference.");
        }

        iri = new AttributedURIImpl();
        iri.read(addressElement);

        SOAPElement refParamsElement = null;

        refParamsElement = AddressingUtils.findElement(
                WSA_REFERENCEPROPERTIES_QNAME, elements.iterator(), true);

        refParams = new ReferenceParametersImpl();
        if (refParamsElement != null) {
            refParams.read(refParamsElement);
        }

        SOAPElement metadataElement = null;

        metadataElement = AddressingUtils.findElement(
                WSA_REFERENCEPARAMETERS_QNAME, elements.iterator(), true);

        metadata = new MetadataImpl();
        if (metadataElement != null) {
            metadata.read(metadataElement);
        }
    }

    @Override
    public SOAPElement write(SOAPElement parent, QName name) {
        try {
            SOAPElement element = SOAP_FACTORY.createElement(name
                    .getLocalPart(), name.getPrefix(), name.getNamespaceURI());

            iri.write(element, WSA_ADDRESS_QNAME);

            refParams.write(element, WSA_REFERENCEPROPERTIES_QNAME);
            metadata.write(element, WSA_REFERENCEPARAMETERS_QNAME);

            if (parent == null)
                throw new AddressingException("Cannot write " + name + " to null parent.");

            parent.addChildElement(element);
            return element;
        } catch (SOAPException e) {
            throw new AddressingException(e);
        }
    }

    public void writeTo(SOAPMessage message) {
        try {
            SOAPHeader header = AddressingUtils.ensureSOAPHeader(message);

            if (iri == null) {
                throw new AddressingException("Missing address in EndpointReference.");
            }

            AddressingUtils.removeAllAddressingHeaders(message, WSA_TO_QNAME);

            iri.write(header, WSA_TO_QNAME);

            List<Object> refParamElements = refParams.getElements();

            for (Object obj : refParamElements) {
                SOAPElement el = (SOAPElement) obj;
                header.addChildElement(el);
            }

            List<Object> metadataElements = metadata.getElements();
            for (Object obj : metadataElements) {
                SOAPElement el = (SOAPElement) obj;
                header.addChildElement(el);
            }

            message.saveChanges();

        } catch (SOAPException e) {
            throw new AddressingException(e);
        }
    }

    @XmlAnyElement(lax = false, value = W3CDomHandler.class)
    public List<Object> getElements() {
        return elements;
    }

    void setElements(List<Object> list) {
        this.elements = list;
    }

    public String toString() {
        return iri.getValue();
    }
}
