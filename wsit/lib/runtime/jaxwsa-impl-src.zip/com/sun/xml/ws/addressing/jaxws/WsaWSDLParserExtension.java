/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: WsaWSDLParserExtension.java,v 1.1.2.27 2006/07/14 00:49:06 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved.
 */

package com.sun.xml.ws.addressing.jaxws;

import java.util.HashMap;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.ws.addressing.AddressingBuilderFactory;
import javax.xml.ws.addressing.AddressingConstants;
import javax.xml.ws.addressing.AddressingException;

import com.sun.xml.ws.api.model.wsdl.WSDLBoundOperation;
import com.sun.xml.ws.api.model.wsdl.WSDLBoundPortType;
import com.sun.xml.ws.api.model.wsdl.WSDLFault;
import com.sun.xml.ws.api.model.wsdl.WSDLModel;
import com.sun.xml.ws.api.model.wsdl.WSDLOperation;
import com.sun.xml.ws.api.model.wsdl.WSDLPort;
import com.sun.xml.ws.api.model.wsdl.WSDLPortType;
import com.sun.xml.ws.api.model.wsdl.WSDLService;
import com.sun.xml.ws.api.wsdl.parser.WSDLParserExtension;
import com.sun.xml.ws.streaming.XMLStreamReaderUtil;
import com.sun.xml.ws.wsdl.parser.ParserUtil;
import com.sun.xml.ws.wsdl.parser.WSDLConstants;

/**
 * Runtime WSDL parser extension.
 *
 * @author JAX-WSA Development Team
 */
public class WsaWSDLParserExtension extends WSDLParserExtension {
    private static final AddressingConstants ac = AddressingBuilderFactory.newInstance().newAddressingBuilder().newAddressingConstants();

    @Override
    public boolean bindingElements(WSDLBoundPortType binding, XMLStreamReader reader) {
        QName ua = reader.getName();
        if (ua.equals(ac.getWSDLExtensionQName())) {
            WsaWSDLBindingExtension ww = new WsaWSDLBindingExtension(true);
            String required = reader.getAttributeValue(WSDLConstants.NS_WSDL, "required");
            ww.setRequired(Boolean.parseBoolean(required));
            binding.addExtension(ww);

            XMLStreamReaderUtil.skipElement(reader);
            return true;        // UsingAddressing is consumed
        }

        return false;
    }

    @Override
    public boolean portElements(WSDLPort port, XMLStreamReader reader) {
        QName ua = reader.getName();
        if (ua.equals(ac.getWSDLExtensionQName())) {
            WsaWSDLPortExtension ww = new WsaWSDLPortExtension(true);
            String required = reader.getAttributeValue(WSDLConstants.NS_WSDL, "required");
            ww.setRequired(Boolean.parseBoolean(required));
            port.addExtension(ww);

            XMLStreamReaderUtil.skipElement(reader);
            return true;        // UsingAddressing is consumed
        }

        return false;
    }

    @Override
    public boolean bindingOperationElements(WSDLBoundOperation operation, XMLStreamReader reader) {
        QName anon = reader.getName();
        if (anon.equals(ac.getWSDLAnonymousExtensionQName())) {
            WsaWSDLBindingOperationExtension ww = getWsaBindingOperationExtension(operation);
            try {
                String value = reader.getElementText();
                if (value == null || value.trim().equals("")) {
                    throw new AddressingException("Null values not permitted in wsaw:Anonymous.");
                    // TODO: throw exception only if wsdl:required=true
                } else if (value.equals("optional")) {
                    ww.setAnonymous(WsaWSDLBindingOperationExtension.ANONYMOUS.optional);
                } else if (value.equals("required")) {
                    ww.setAnonymous(WsaWSDLBindingOperationExtension.ANONYMOUS.required);
                } else if (value.equals("prohibited")) {
                    ww.setAnonymous(WsaWSDLBindingOperationExtension.ANONYMOUS.prohibited);
                } else {
                    throw new AddressingException("wsaw:Anonymous value \"" + value + "\" not understood.");
                    // TODO: throw exception only if wsdl:required=true
                }
            } catch (XMLStreamException e) {
                throw new AddressingException(e);       // TODO: is this the correct behavior ?
            }

            return true;        // consumed the element
        }

        return false;
    }

    @Override
    public boolean portTypeOperationInput(WSDLOperation op, XMLStreamReader reader) {
        String action = ParserUtil.getAttribute(reader, ac.getWSDLActionQName());
        WsaWSDLOperationExtension ww = getWsaPortTypeOperationExtension(op);
        ww.setInputAction(action);
        ww.setInputDefault(action == null);

        return false;
    }

    @Override
    public boolean portTypeOperationOutput(WSDLOperation o, XMLStreamReader reader) {
        String action = ParserUtil.getAttribute(reader, ac.getWSDLActionQName());
        WsaWSDLOperationExtension ww = getWsaPortTypeOperationExtension(o);
        ww.setOutputAction(action);

        return false;
    }

    @Override
    public boolean portTypeOperationFault(WSDLOperation o, XMLStreamReader reader) {
        HashMap<String,String> map = getWsaPortTypeOperationExtension(o).getFaultActions();

        String action = ParserUtil.getAttribute(reader, ac.getWSDLActionQName());
        if (action != null) {
            String name = ParserUtil.getMandatoryNonEmptyAttribute(reader, "name");
            map.put(name, action);
        }

        return false;
    }

    @Override
    public void finished(WSDLModel model) {
        populateDefaultActions(model);
        copyExtensionsFromBindingToPortTypeOperation(model);
        patchBindingAndPortUsingAddressing(model);
    }

    private void patchBindingAndPortUsingAddressing(WSDLModel model) {
        // patch the value of UsingAddressing in wsdl:port and wsdl:binding
        for (WSDLService service : model.getServices().values()) {
            for (WSDLPort port : service.getPorts()) {
                WSDLBoundPortType binding = port.getBinding();
                WsaWSDLBindingExtension bindingExtension = binding.getExtension(WsaWSDLBindingExtension.class);
                if (bindingExtension == null) {
                    bindingExtension = new WsaWSDLBindingExtension(false);
                    binding.addExtension(bindingExtension);
                }

                WsaWSDLPortExtension portExtension = port.getExtension(WsaWSDLPortExtension.class);
                if (portExtension == null) {
                    portExtension = new WsaWSDLPortExtension(false);
                    port.addExtension(portExtension);
                }

                // TODO: what if wsdl:required is in contradiction ?
                if (bindingExtension.isEnabled() == portExtension.isEnabled())
                    continue;

                if (bindingExtension.isEnabled() && !portExtension.isEnabled()) {
                    portExtension.setEnabled(true);
                    portExtension.setRequired(bindingExtension.isRequired());
                }

                if (!bindingExtension.isEnabled() && portExtension.isEnabled()) {
                    bindingExtension.setEnabled(true);
                    bindingExtension.setRequired(portExtension.isRequired());
                }
            }
        }
    }

    /**
     * Process wsdl:portType operation after the entire WSDL model has been populated.
     * The task list includes: <p>
     * <ul>
     * <li>Populate default actions for the operations that do not have an explicit wsaw:Action</li>
     * <li>Populate the default value of wsaw:Anonymous=optional if none is specified
     * </ul>
     * @param model
     */
    private void populateDefaultActions(WSDLModel model) {
        // populate all the Actions
        for (WSDLPortType portType : model.getPortTypes().values()) {
            for (WSDLOperation o : portType.getOperations()) {
                WsaWSDLOperationExtension ww = getWsaPortTypeOperationExtension(o);

                // In the absence of a wsaw:Action attribute on a WSDL input element where a
                // SOAPAction value is specified, the value of the [action] property for the
                // input message is the value of the SOAPAction specified.
                if (ww.getInputAction() == null) {
                    ww.setInputAction(defaultInputAction(o));
                }

                // skip output and fault processing for one-way methods
                if (o.getOutput() == null)
                    continue;

                if (ww.getOutputAction() == null) {
                    ww.setOutputAction(defaultOutputAction(o));
                }

                if (o.getFaults() == null || !o.getFaults().iterator().hasNext())
                    continue;

                HashMap<String, String> map = ww.getFaultActions();
                for (WSDLFault f : o.getFaults()) {
                    if (map.get(f.getName()) == null)
                        map.put(f.getName(), defaultFaultAction(f.getName(), o));
                }
            }
        }
    }

    private void copyExtensionsFromBindingToPortTypeOperation(WSDLModel model) {
        for (WSDLBoundPortType wbp : model.getBindings().values()) {
            for (WSDLBoundOperation wbo : wbp.getBindingOperations()) {
                // default value of wsaw:Anonymous
                WsaWSDLBindingOperationExtension wwb = getWsaBindingOperationExtension(wbo);
                if (wwb.getAnonymous() == null) {
                    wwb.setAnonymous(WsaWSDLBindingOperationExtension.ANONYMOUS.optional);
                }

                wbo.getOperation().addExtension(wwb);
            }
        }
    }

    @Override
    public void postFinished(WSDLModel model) {
        // populate PolicyMap for Addressing depending upon the values of
        // UsingAddressing in wsdl:port or wsdl:binding
    }

    private static WsaWSDLOperationExtension getWsaPortTypeOperationExtension(WSDLOperation o) {
        WsaWSDLOperationExtension ww = o.getExtension(WsaWSDLOperationExtension.class);
        if (ww == null) {
            ww = new WsaWSDLOperationExtension();
            o.addExtension(ww);
        }

        return ww;
    }

    private static WsaWSDLBindingOperationExtension getWsaBindingOperationExtension(WSDLBoundOperation o) {
        WsaWSDLBindingOperationExtension ww = o.getExtension(WsaWSDLBindingOperationExtension.class);
        if (ww == null) {
            ww = new WsaWSDLBindingOperationExtension();
            o.addExtension(ww);
        }

        return ww;
    }

    private String defaultInputAction(WSDLOperation o) {
        return buildAction(o.getInput().getName(), o, false);
    }

    private String defaultOutputAction(WSDLOperation o) {
        return buildAction(o.getOutput().getName(), o, false);
    }

    private String defaultFaultAction(String name, WSDLOperation o) {
        return buildAction(name, o, true);
    }

    protected static final String buildAction(String name, WSDLOperation o, boolean isFault) {
        String tns = o.getName().getNamespaceURI();

        String delim = SLASH_DELIMITER;

        // TODO: is this the correct way to find the separator ?
        if (!tns.startsWith("http"))
            delim = COLON_DELIMITER;

        if (tns.endsWith(delim))
            tns = tns.substring(0, tns.length()-1);

        if (o.getPortTypeName() == null)
            throw new AddressingException("\"" + o.getName() + "\" operation's owning portType name is null.");

        return tns +
            delim +
            o.getPortTypeName().getLocalPart() +
            delim +
            (isFault ? o.getName().getLocalPart() + "Fault" + delim : "") +
            name;
    }

    private static final String SLASH_DELIMITER = "/";
    private static final String COLON_DELIMITER = ":";
}
