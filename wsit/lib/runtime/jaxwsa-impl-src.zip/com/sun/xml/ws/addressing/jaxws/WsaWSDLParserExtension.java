/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: WsaWSDLParserExtension.java,v 1.1.2.20 2006/06/26 18:10:50 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved.
 */

package com.sun.xml.ws.addressing.jaxws;

import com.sun.xml.ws.api.model.wsdl.WSDLFault;
import com.sun.xml.ws.api.model.wsdl.WSDLModel;
import com.sun.xml.ws.api.model.wsdl.WSDLOperation;
import com.sun.xml.ws.api.model.wsdl.WSDLPortType;
import com.sun.xml.ws.api.model.wsdl.WSDLBoundPortType;
import com.sun.xml.ws.api.model.wsdl.WSDLPort;
import com.sun.xml.ws.api.model.wsdl.WSDLService;
import com.sun.xml.ws.api.wsdl.parser.WSDLParserExtension;
import com.sun.xml.ws.wsdl.parser.ParserUtil;

import javax.xml.stream.XMLStreamReader;
import javax.xml.ws.addressing.AddressingBuilderFactory;
import javax.xml.ws.addressing.AddressingConstants;
import javax.xml.ws.addressing.AddressingException;
import javax.xml.namespace.QName;

import java.util.HashMap;

/**
 * Runtime WSDL parser extension.
 *
 * @author JAX-WSA Development Team
 */
public final class WsaWSDLParserExtension extends WSDLParserExtension {
    private static final AddressingConstants ac = AddressingBuilderFactory.newInstance().newAddressingBuilder().newAddressingConstants();

    @Override
    public boolean bindingElements(WSDLBoundPortType binding, XMLStreamReader reader) {
        QName ua = reader.getName();
        if (ua.equals(ac.getWSDLExtensibilityQName())) {
            binding.addExtension(new WsaWSDLBindingExtension(true));
            return false;
        }

        return false;
    }

    @Override
    public boolean portElements(WSDLPort port, XMLStreamReader reader) {
        QName ua = reader.getName();
        if (ua.equals(ac.getWSDLExtensibilityQName())) {
            port.addExtension(new WsaWSDLPortExtension(true));
            return false;
        }

        return false;
    }

    @Override
    public final boolean portTypeOperationInput(WSDLOperation op, XMLStreamReader reader) {
        String action = ParserUtil.getAttribute(reader, ac.getWSDLActionQName());
        WsaWSDLOperationExtension ww = getWsaExtension(op);
        ww.setInputAction(action);
        ww.setInputDefault(action == null);

        return false;
    }

    @Override
    public final boolean portTypeOperationOutput(WSDLOperation o, XMLStreamReader reader) {
        String action = ParserUtil.getAttribute(reader, ac.getWSDLActionQName());

        WsaWSDLOperationExtension ww = getWsaExtension(o);
        ww.setOutputAction(action);

        return false;
    }

    @Override
    public final boolean portTypeOperationFault(WSDLOperation o, XMLStreamReader reader) {
        HashMap<String,String> map = getWsaExtension(o).getFaultActions();

        String action = ParserUtil.getAttribute(reader, ac.getWSDLActionQName());
        if (action != null) {
            String name = ParserUtil.getMandatoryNonEmptyAttribute(reader, "name");
            map.put(name, action);
        }

        return false;
    }

    @Override
    public void finished(WSDLModel model) {
        // populate all the Actions
        for (WSDLPortType portType : model.getPortTypes().values()) {
            for (WSDLOperation o : portType.getOperations()) {
                WsaWSDLOperationExtension ww = getWsaExtension(o);

                // In the absence of a wsaw:Action attribute on a WSDL input element where a
                // SOAPAction value is specified, the value of the [action] property for the
                // input message is the value of the SOAPAction specified.
                if (ww.getInputAction() == null) {
                    ww.setInputAction(defaultInputAction(o));
                }

                // skip output and fault processing for one-way methods
                if (o.getOutput() == null)
                    continue;

                if (ww.getOutputAction() == null) {
                    ww.setOutputAction(defaultOutputAction(o));
                }

                if (o.getFaults() == null || !o.getFaults().iterator().hasNext())
                    continue;

                HashMap<String, String> map = ww.getFaultActions();
                for (WSDLFault f : o.getFaults()) {
                    if (map.get(f.getName()) == null)
                        map.put(f.getName(), defaultFaultAction(f.getName(), o));
                }
            }
        }

        // patch the value of UsingAddressing in wsdl:port and wsdl:binding
        for (WSDLService service : model.getServices().values()) {
            for (WSDLPort port : service.getPorts()) {
                WSDLBoundPortType binding = port.getBinding();
                WsaWSDLBindingExtension bindingExtension = binding.getExtension(WsaWSDLBindingExtension.class);
                if (bindingExtension == null) {
                    bindingExtension = new WsaWSDLBindingExtension(false);
                    binding.addExtension(bindingExtension);
                }

                WsaWSDLPortExtension portExtension = port.getExtension(WsaWSDLPortExtension.class);
                if (portExtension == null) {
                    portExtension = new WsaWSDLPortExtension(false);
                    port.addExtension(portExtension);
                }
                
                if (bindingExtension.isEnabled() == portExtension.isEnabled())
                    continue;

                if (bindingExtension.isEnabled() && !portExtension.isEnabled()) {
                    portExtension.setEnabled(true);
                }

                if (!bindingExtension.isEnabled() && portExtension.isEnabled()) {
                    bindingExtension.setEnabled(true);
                }
            }
        }
    }

    @Override
    public void postFinished(WSDLModel model) {
        // populate PolicyMap for Addressing depending upon the values of
        // UsingAddressing in wsdl:port or wsdl:binding
    }

    private static WsaWSDLOperationExtension getWsaExtension(WSDLOperation o) {
        WsaWSDLOperationExtension ww = o.getExtension(WsaWSDLOperationExtension.class);
        if (ww == null) {
            ww = new WsaWSDLOperationExtension();
            o.addExtension(ww);
        }

        return ww;
    }

    private String defaultInputAction(WSDLOperation o) {
        return buildAction(o.getInput().getName(), o, false);
    }


    private String defaultOutputAction(WSDLOperation o) {
        return buildAction(o.getOutput().getName(), o, false);
    }

    private String defaultFaultAction(String name, WSDLOperation o) {
        return buildAction(name, o, true);
    }

    private static final String buildAction(String name, WSDLOperation o, boolean isFault) {
        String tns = o.getName().getNamespaceURI();

        String delim = SLASH_DELIMITER;

        // TODO: is this the correct way to find the separator ?
        if (!tns.startsWith("http"))
            delim = COLON_DELIMITER;

        if (tns.endsWith(delim))
            tns = tns.substring(0, tns.length()-1);

        if (o.getPortTypeName() == null)
            throw new AddressingException("\"" + o.getName() + "\" operation's owning portType name is null.");

        return tns +
            delim +
            o.getPortTypeName().getLocalPart() +
            delim +
            (isFault ? o.getName().getLocalPart() + "Fault" + delim : "") +
            name;
    }

    private static final String SLASH_DELIMITER = "/";
    private static final String COLON_DELIMITER = ":";
}
