/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: WsaPipeHelperImpl.java,v 1.1.2.12 2006/06/16 00:44:50 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved.
 */

package com.sun.xml.ws.addressing;

import com.sun.xml.ws.addressing.jaxws.WsaPipeHelper;
import com.sun.xml.ws.api.WSBinding;
import com.sun.xml.ws.api.message.Header;
import com.sun.xml.ws.api.message.Headers;
import com.sun.xml.ws.api.model.wsdl.WSDLPort;
import com.sun.xml.ws.api.model.SEIModel;
import org.w3c.dom.Element;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.ws.addressing.AddressingException;

/**
 * @author JAX-WSA Development Team
 */
public class WsaPipeHelperImpl extends WsaPipeHelper {

    public WsaPipeHelperImpl() {
        try {
            ab = new AddressingBuilderImpl();
            ac = new AddressingConstantsImpl();
            jc = JAXBContext.newInstance(EndpointReferenceImpl.class,
                    RelationshipImpl.class,
                    ObjectFactory.class,
                    ProblemAction.class,
                    ProblemHeaderQName.class);
            unmarshaller = jc.createUnmarshaller();
            marshaller = jc.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
        } catch (JAXBException e) {
            throw new AddressingException(e);
        }
    }

    public WsaPipeHelperImpl(WSDLPort wsdlPort, WSBinding binding) {
        this(null, wsdlPort, binding);
    }

    public WsaPipeHelperImpl(SEIModel seiModel, WSDLPort wsdlPort, WSBinding binding) {
        this();
        this.seiModel = seiModel;
        this.wsdlPort = wsdlPort;
        this.binding = binding;
    }

    @Override
    protected void getProblemActionDetail(String action, Element element) {
        ProblemAction pa = new ProblemAction(action);
        try {
            marshaller.marshal(pa, element);
        } catch (JAXBException e) {
            throw new AddressingException(e);
        }
    }

    @Override
    protected void getInvalidMapDetail(QName name, Element element) {
        ProblemHeaderQName phq = new ProblemHeaderQName(name);
        try {
            marshaller.marshal(phq, element);
        } catch (JAXBException e) {
            throw new AddressingException(e);
        }
    }

    @Override
    protected void getMapRequiredDetail(QName name, Element element) {
        getInvalidMapDetail(name, element);
    }

    @Override
    protected Header getDefaultFaultAction() {
        return Headers.create(binding.getSOAPVersion(), marshaller, ac.getActionQName(), ab.newURI(ac.getDefaultFaultAction()));
    }

    @Override
    protected SOAPElement getSoap11FaultDetail() {
        try {
            if (binding == null)
                return null;
            
            return binding.getSOAPVersion().saajSoapFactory.createElement(new QName(Constants.WSA_NAMESPACE_NAME, "FaultDetail"));
        } catch (SOAPException e) {
            throw new AddressingException(e);
        }
    }

    @XmlRegistry
    class ObjectFactory {
        @XmlElementDecl(namespace=Constants.WSA_NAMESPACE_NAME,name="From")
        JAXBElement<EndpointReferenceImpl> createFrom(EndpointReferenceImpl u) {
            return null;
        }

        @XmlElementDecl(namespace=Constants.WSA_NAMESPACE_NAME,name="Action")
        JAXBElement<AttributedURIImpl> createAction(AttributedURIImpl u) {
            return null;
        }

        @XmlElementDecl(namespace=Constants.WSA_NAMESPACE_NAME,name="To")
        JAXBElement<AttributedURIImpl> createTo(AttributedURIImpl u) {
            return null;
        }

        @XmlElementDecl(namespace=Constants.WSA_NAMESPACE_NAME,name="ReplyTo")
        JAXBElement<EndpointReferenceImpl> createReplyTo(EndpointReferenceImpl u) {
            return null;
        }

        @XmlElementDecl(namespace=Constants.WSA_NAMESPACE_NAME,name="FaultTo")
        JAXBElement<EndpointReferenceImpl> createFaultTo(EndpointReferenceImpl u) {
            return null;
        }

        @XmlElementDecl(namespace=Constants.WSA_NAMESPACE_NAME,name="MessageID")
        JAXBElement<AttributedURIImpl> createMessageID(AttributedURIImpl u) {
            return null;
        }

        @XmlElementDecl(namespace=Constants.WSA_NAMESPACE_NAME,name="RelatesTo")
        JAXBElement<AttributedURIImpl> createRelationship(AttributedURIImpl u) {
            return null;
        }

    }
}

