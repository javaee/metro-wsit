/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: AddressingPropertiesImpl.java,v 1.17.2.7 2006/07/13 18:03:33 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved.
 */

package com.sun.xml.ws.addressing;

import static com.sun.xml.ws.addressing.Constants.WSA_ACTION_QNAME;
import static com.sun.xml.ws.addressing.Constants.WSA_FAULTTO_QNAME;
import static com.sun.xml.ws.addressing.Constants.WSA_FROM_QNAME;
import static com.sun.xml.ws.addressing.Constants.WSA_IS_REFERENCE_PARAMETER_QNAME;
import static com.sun.xml.ws.addressing.Constants.WSA_MESSAGEID_QNAME;
import static com.sun.xml.ws.addressing.Constants.WSA_NAMESPACE_NAME;
import static com.sun.xml.ws.addressing.Constants.WSA_RELATESTO_QNAME;
import static com.sun.xml.ws.addressing.Constants.WSA_REPLYTO_QNAME;
import static com.sun.xml.ws.addressing.Constants.WSA_TO_QNAME;
import static com.sun.xml.ws.addressing.Constants.isW3CVersion;
import com.sun.xml.ws.addressing.util.AddressingUtils;
import org.w3c.dom.Element;

import javax.xml.namespace.QName;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.addressing.AddressingException;
import javax.xml.ws.addressing.AddressingProperties;
import javax.xml.ws.addressing.AddressingType;
import javax.xml.ws.addressing.AttributedURI;
import javax.xml.ws.addressing.EndpointReference;
import javax.xml.ws.addressing.InvalidMapException;
import javax.xml.ws.addressing.MapRequiredException;
import javax.xml.ws.addressing.ReferenceParameters;
import javax.xml.ws.addressing.Relationship;
import javax.xml.ws.addressing.soap.SOAPAddressingProperties;
import javax.xml.XMLConstants;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
/**
 * @author JAX-WSA Development Team
 */
public class AddressingPropertiesImpl extends HashMap<QName, AddressingType>
        implements SOAPAddressingProperties {
    
    private AttributedURIImpl to;
    private AttributedURIImpl action;
    private AttributedURIImpl messageID;
    private RelationshipImpl[] relatesTo;
    private EndpointReferenceImpl replyTo;
    private EndpointReferenceImpl faultTo;
    private EndpointReferenceImpl from;
    private ReferenceParametersImpl refParams;
    private boolean mu;
    
    /** Creates a new instance of AddressingPropertiesImpl */
    public AddressingPropertiesImpl() {
    }
    
    public String getNamespaceURI() {
        return WSA_NAMESPACE_NAME;
    }
    
    public AttributedURI getTo() {
        return to;
    }
    
    public void setTo(AttributedURI to) {
        this.to = AttributedURIImpl.getAddressingElement(to);
    }

    public void setTo(String to) {
        this.to = new AttributedURIImpl(to);
    }

    public AttributedURI getAction() {
        return action;
    }
    
    public void setAction(AttributedURI action) {
        this.action = AttributedURIImpl.getAddressingElement(action);
    }

    public void setAction(String action) {
        this.action = new AttributedURIImpl(action);
    }
    
    public AttributedURI getMessageID() {
        return messageID;
    }
    
    public void setMessageID(AttributedURI messageID) {
        this.messageID = AttributedURIImpl.getAddressingElement(messageID);
    }

    public void setMessageID(String messageID) {
        this.messageID = new AttributedURIImpl(messageID);
    }

    public Relationship[] getRelatesTo() {
        if (relatesTo == null) {
            return null;
        }
        
        Relationship[] ret = new Relationship[relatesTo.length];
        int i = 0;
        for (RelationshipImpl rel : relatesTo) {
            ret[i++] = rel;
        }
        
        return ret;
    }
    
    public void setRelatesTo(Relationship[] rel) {
        if (rel == null) {
            relatesTo = null;
            return;
        }
        int len = rel.length;
        relatesTo = new RelationshipImpl[len];
        for (int i = 0; i < len; i++) {
            relatesTo[i] = RelationshipImpl.getAddressingElement(rel[i]);
        }
    }
    
    public EndpointReference getReplyTo() {
        return replyTo;
    }
    
    public void setReplyTo(EndpointReference replyTo) {
        this.replyTo = EndpointReferenceImpl.getAddressingElement(replyTo);
    }

    public void setReplyTo(String replyTo) {
        this.replyTo = new EndpointReferenceImpl(replyTo);
    }

    public EndpointReference getFaultTo() {
        return faultTo;
    }
    
    public void setFaultTo(EndpointReference faultTo) {
        this.faultTo = EndpointReferenceImpl.getAddressingElement(faultTo);
    }

    public void setFaultTo(String faultTo) {
        this.faultTo = new EndpointReferenceImpl(faultTo);
    }

    public EndpointReference getFrom() {
        return from;
    }
    
    public void setFrom(EndpointReference from) {
        this.from = EndpointReferenceImpl.getAddressingElement(from);
    }

    public void setFrom(String from) {
        this.from = new EndpointReferenceImpl(from);
    }

    public ReferenceParameters getReferenceParameters() {
        if (refParams == null)
            refParams = new ReferenceParametersImpl();
        return refParams;
    }
    
    private void setReferenceParameters(ReferenceParameters params) {
        this.refParams = ReferenceParametersImpl.getAddressingElement(params);
    }
    
    public void initializeAsDestination(EndpointReference source) {
        if (source == null) {
            throw new AddressingException("Source addressing properties is null."); // TODO i18n
        }

        AttributedURI uri = source.getAddress();
        if (uri == null)
            throw new InvalidMapException(Constants.INVALID_MAP_QNAME, InvalidMapException.MISSING_ADDRESS_IN_EPR);

        setTo(uri);
        
        ReferenceParameters params = source.getReferenceParameters();
        
        if (params != null) {
            setReferenceParameters(params);
            for (Object refp : refParams.getElements()) {
                if (refp instanceof Element)
                    addIsRefp((Element)refp);
            }
        }
    }
    
    void addIsRefp(Element refp) {
        refp.setAttributeNS(Constants.WSA_NAMESPACE_NAME,
            Constants.WSA_NAMESPACE_PREFIX + ":" + Constants.WSA_IS_REFERENCE_PARAMETER_QNAME.getLocalPart(),
            "true");
        
        // TODO: This may cause a namespace prefix conflict and is a tricky problem
        // TODO: to solve. For example, parent might have a similar prefix used
        // TODO: for some other purpose, etc.
        refp.setAttributeNS(XMLConstants.XMLNS_ATTRIBUTE_NS_URI,"xmlns:"+Constants.WSA_NAMESPACE_PREFIX,
            Constants.WSA_NAMESPACE_NAME);
    }
    
    private void initializeAsReplyOrFault(AddressingProperties source, boolean isFault) {
        if (source == null) {
            throw new AddressingException("Source addressing properties is null."); // TODO i18n
        }
        
        EndpointReference destination;
        if (isFault) {
            destination = (source.getFaultTo() != null) ?
                source.getFaultTo() :
                source.getReplyTo();
        } else {
            destination = source.getReplyTo();
        }

        if (destination == null) {
            destination = new EndpointReferenceImpl();
        }
        
        initializeAsDestination(destination);

        AttributedURI uri = source.getMessageID();
        if (uri == null) {
            throw new MapRequiredException(Constants.WSA_MESSAGEID_QNAME);
        }

        RelationshipImpl impl = new RelationshipImpl(uri.getURI());
        Map<QName, String> atts = uri.getAttributes();
        if (atts != null) {
            for (QName name: atts.keySet()) {
                impl.addAttribute(name, atts.get(name));
            }
        }

        Relationship[] r = new Relationship[1];
        r[0] = impl;
        setRelatesTo(r);
    }

    public void initializeAsReply(AddressingProperties destination) {
        initializeAsReplyOrFault(destination, false);
    }

    public void initializeAsFault(AddressingProperties destination) {
        initializeAsReplyOrFault(destination, true);
    }
    
    public void writeHeaders(SOAPMessage message) throws AddressingException {
        try {
            
            SOAPHeader header = AddressingUtils.ensureSOAPHeader(message);
            
            AddressingUtils.removeAllAddressingHeaders(message, WSA_NAMESPACE_NAME);
            
            if (to != null) {
                to.write(header, WSA_TO_QNAME);
            }
            
            if (action != null) {
                action.write(header, WSA_ACTION_QNAME);
            }
            
            if (messageID != null) {
                messageID.write(header, WSA_MESSAGEID_QNAME);
            }
            
            if (relatesTo != null) {
                for (RelationshipImpl ri : relatesTo) {
                    ri.write(header, WSA_RELATESTO_QNAME);
                }
            }
            
            if (replyTo != null) {
                replyTo.write(header, WSA_REPLYTO_QNAME);
                
            }
            
            if (faultTo != null) {
                faultTo.write(header, WSA_FAULTTO_QNAME);
            }
            
            if (from != null) {
                from.write(header, WSA_FROM_QNAME);
            }
            
            if (refParams != null) {
                List<Object> refParamElements = refParams.getElements();
//                Name refParamName = SOAP_FACTORY.createName(WSA_IS_REFERENCE_PARAMETER_QNAME.getLocalPart(),
//                        WSA_NAMESPACE_PREFIX,
//                        WSA_NAMESPACE_NAME);
                
                for (Object obj : refParamElements) {
                    
                    if (!(obj instanceof Element))
                        continue;
                    
//                    SOAPElement el = (SOAPElement) obj;
//                    if (isW3CVersion()) {
//                        el.addAttribute(refParamName, "1");
//                    }
                    
                    header.addChildElement((SOAPElement)obj);
//                    header.appendChild((Element)obj);
                }
            }
            
            message.saveChanges();
            
        } catch (SOAPException e) {
            throw new AddressingException(e);
        }
    }
    
    public void readHeaders(SOAPMessage message) throws AddressingException {

        SOAPHeader header = null;
        try {
            header = message.getSOAPHeader();
        } catch (SOAPException e) {
            // no header
        }

        if (header == null) {
            return;
        }

        Iterator it = header.getChildElements();
        ArrayList<RelationshipImpl> relationships = new ArrayList<RelationshipImpl>();

        while (it.hasNext()) {

            SOAPElement el = (SOAPElement) it.next();
            Name name = el.getElementName();
            if (!name.getURI().equals(WSA_NAMESPACE_NAME)) {
                continue;
            }

            if (name.equals(WSA_TO_QNAME)) {
                to = new AttributedURIImpl();
                to.read(el);
            } else if (name.equals(WSA_ACTION_QNAME)) {
                action = new AttributedURIImpl();
                action.read(el);
            } else if (name.equals(WSA_RELATESTO_QNAME)) {
                RelationshipImpl ri = new RelationshipImpl();
                ri.read(el);
                relationships.add(ri);
            } else if (name.equals(WSA_MESSAGEID_QNAME)) {
                messageID = new AttributedURIImpl();
                messageID.read(el);
            } else if (name.equals(WSA_REPLYTO_QNAME)) {
                replyTo = new EndpointReferenceImpl();
                replyTo.read(el);
            } else if (name.equals(WSA_FAULTTO_QNAME)) {
                faultTo = new EndpointReferenceImpl();
                faultTo.read(el);
            } else if (name.equals(WSA_FROM_QNAME)) {
                from = new EndpointReferenceImpl();
                from.read(el);
            } else if (isW3CVersion()) {
                String val = el.getAttributeValue(WSA_IS_REFERENCE_PARAMETER_QNAME);
                if (val != null && !val.equals("")) {
                    refParams.addElement(el);
                }
            }
        }

        if (relationships.size() == 0) {
            relatesTo = null;
        } else {
            relatesTo = (RelationshipImpl[])(relationships.toArray(new RelationshipImpl[relationships.size()]));
        }
    }

    public void writeReplyHeaders(SOAPMessage message, String version)
    throws AddressingException {
        
        try {
            AddressingUtils.removeAllAddressingHeaders(message, version);
            
            replyTo.writeTo(message);
            
            RelationshipImpl relationship = new RelationshipImpl(getMessageID()
            .getURI());
            relationship.write(message.getSOAPHeader(),
                    WSA_RELATESTO_QNAME);
            message.saveChanges();
            
        } catch (SOAPException e) {
            throw new AddressingException(e);
        }
    }
    
    public void setMu(boolean mu) {
        this.mu = mu;
    }
}
