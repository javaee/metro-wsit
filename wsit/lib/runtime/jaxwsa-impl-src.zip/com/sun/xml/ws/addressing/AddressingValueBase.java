/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: AddressingValueBase.java,v 1.10.2.2 2006/04/14 00:18:21 arungupta Exp $
 * 
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved. 
 */

package com.sun.xml.ws.addressing;

import static com.sun.xml.ws.addressing.Constants.WSA_NAMESPACE_NAME;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyAttribute;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlValue;
import javax.xml.namespace.QName;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.Text;
import javax.xml.ws.addressing.AddressingException;
import javax.xml.ws.addressing.AttributeExtensible;
import static javax.xml.ws.addressing.JAXWSAConstants.SOAP_FACTORY;
import javax.xml.ws.addressing.soap.SOAPAddressingElement;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Base class for AddressingElements that have only attribute extensibility elements.
 * Includes default implementations SOAPAddressingElement methods.
 *
 * @author JAX-WSA Development Team
 */
@XmlAccessorType(value = XmlAccessType.FIELD)
public abstract class AddressingValueBase implements AttributeExtensible,
        SOAPAddressingElement {

    protected AddressingValueBase(String version) {
        this.version = version;
    }


    @XmlValue
    protected String value;

    /**
     * Internal Map of attributes.
     */
    @XmlAnyAttribute
    protected Map<QName, String> attributes = new HashMap<QName, String>();

    /**
     * Read-only view of attributes exposed by the <code>getAttributes</code>
     * method.
     */
    @XmlTransient
    protected Map<QName, String> exposedAttributes;

    /**
     * Text child node if any.
     */
    @XmlTransient
    protected String text;

    /**
     * Addressing version to use as return value for <code>getNamespaceURI</code>
     */
    @XmlTransient
    protected String version;

    /**
     * Public constructor initializes the <code>Extensible</code> subclass using
     * a <code>Map</code> and <code>Collection</code> that are passed to it and used
     * to initialize the underlying data structures.
     */

    protected AddressingValueBase() {
        this(WSA_NAMESPACE_NAME);
        this.exposedAttributes = Collections.unmodifiableMap(attributes);
        this.text = null;
    }


    public Map<QName, String> getAttributes() {
        return exposedAttributes;
    }

//    public List<Object> getElements() {
//        return null;
//    }

    public void addAttribute(QName name, String value) {
        if (name.getNamespaceURI().equals(version)) {
            throw new AddressingException(
                    "Extensibility attributes for the AttributedURI type"
                            + " may not belong to the namespace defined in the WS-Addressing"
                            + " specification.");
        }

        attributes.put(name, value);
    }

//    public void addElement(Object element) {
//        throw new UnsupportedOperationException(
//                "Class does not support an element collection");
//    }

    public void read(SOAPElement element) throws AddressingException {

        //read child elements      
        Iterator it = element.getChildElements();

        while (it.hasNext()) {

            Object obj = it.next();
            if (obj instanceof Text) {
                if (text != null) {
                    throw new AddressingException(
                            "Invalid Addressing header -- "
                                    + "too many Text nodes.");
                }
                text = ((Text) obj).getValue();
            } else {
                throw new IllegalStateException("Invalid child element.");
            }
        }

        //read attributes
        it = element.getAllAttributes();

        if (it.hasNext()) {
            attributes = new HashMap<QName, String>();
        } else {
            attributes = null;
        }

        while (it.hasNext()) {

            if (attributes == null) {
                throw new AddressingException(
                        "Unsupported attribute collection.");
            }

            Name name = (Name) it.next();
            String uri = name.getURI();
            String localName = name.getLocalName();
            String value = element.getAttributeValue(name);

            QName qname = new QName(uri, localName);
            attributes.put(qname, value);

        }
    }

    public SOAPElement write(SOAPElement parent, QName name) {
        try {
            SOAPElement element = SOAP_FACTORY.createElement(name
                    .getLocalPart(), name.getPrefix(), name.getNamespaceURI());

            String value = getValue();
            if (value != null && !value.equals("")) {
                element.addTextNode(value);
            }

            if (attributes != null) {
                Set keys = attributes.keySet();
                for (Object qname : keys) {
                    Name saajname = SOAP_FACTORY.createName(((QName) qname)
                            .getLocalPart(), ((QName) qname).getPrefix(),
                                             ((QName) qname).getNamespaceURI());
                    element.addAttribute(saajname, attributes.get(qname));
                }
            }

            if (parent == null)
                throw new AddressingException("Cannot write " + name + " to null parent.");

            parent.addChildElement(element);
            return element;
        } catch (SOAPException e) {
            throw new AddressingException(e);
        }
    }

    protected String getValue() {
        return text;
    }

    public String getNamespaceURI() {
        return version;
    }

    protected void setNamespaceURI(String version) {
        this.version = version;
    }
}
