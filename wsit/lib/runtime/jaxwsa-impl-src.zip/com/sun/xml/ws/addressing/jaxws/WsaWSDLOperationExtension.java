/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: WsaWSDLOperationExtension.java,v 1.1.2.1 2006/06/14 00:26:54 arungupta Exp $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc.
 * All rights reserved.
 */

package com.sun.xml.ws.addressing.jaxws;

import java.util.HashMap;

import javax.xml.namespace.QName;
import javax.xml.ws.addressing.AddressingBuilderFactory;
import javax.xml.ws.addressing.AddressingConstants;

import com.sun.tools.ws.api.wsdl.TWSDLExtensible;
import com.sun.tools.ws.api.wsdl.TWSDLExtension;
import com.sun.xml.ws.api.model.wsdl.WSDLExtension;

/**
 * WS-A WSDL extension. Used by both tooltime and runtime.
 *
 * @author JAX-WSA Development Team
 */
public class WsaWSDLOperationExtension implements TWSDLExtension, WSDLExtension {
    private static final AddressingConstants ac = AddressingBuilderFactory.newInstance().newAddressingBuilder().newAddressingConstants();

    private boolean enabled;
    private String ia;
    private String oa;
    private HashMap<String,String> fa;
    
    public TWSDLExtensible getParent() {
        return null;
    }

    public String getInputAction() {
        return ia;
    }

    public void setInputAction(String ia) {
        this.ia = ia;
    }

    public String getOutputAction() {
        return oa;
    }

    public void setOutputAction(String oa) {
        this.oa = oa;
    }

    public HashMap<String, String> getFaultActions() {
        if (fa == null)
            fa = new HashMap<String,String>();
        return fa;
    }

    public String getFaultAction(String name) {
        if (fa != null)
            return fa.get(name);
        else
            return null;
    }

    public QName getName() {
        return ac.getWSDLActionQName();
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}
