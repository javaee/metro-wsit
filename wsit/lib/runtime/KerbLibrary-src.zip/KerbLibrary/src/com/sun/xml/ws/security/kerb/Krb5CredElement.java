/*
 * @(#)Krb5CredElement.java	1.8 05/11/17
 *
 * Copyright 2006 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
  
package com.sun.xml.ws.security.kerb;

import org.ietf.jgss.*;
import sun.security.jgss.spi.*;
import sun.security.krb5.*;
import java.security.Provider;

/**
 * Provides type safety for Krb5 credential elements.
 *
 * @author Mayank Upadhyay
 * @version 1.8, 11/17/05
 * @since 1.4
 */
interface Krb5CredElement 
    extends GSSCredentialSpi {
}
