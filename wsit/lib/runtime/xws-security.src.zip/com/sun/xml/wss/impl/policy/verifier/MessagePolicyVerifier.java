/*
 * MessagePolicyVerifier.java
 *
 * Created on 26 October, 2006, 5:52 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.sun.xml.wss.impl.policy.verifier;

import com.sun.xml.wss.ProcessingContext;
import com.sun.xml.wss.XWSSecurityException;
import com.sun.xml.wss.impl.MessageConstants;
import com.sun.xml.wss.impl.PolicyTypeUtil;
import com.sun.xml.wss.impl.PolicyViolationException;
import com.sun.xml.wss.impl.ProcessingContextImpl;
import com.sun.xml.wss.impl.WSSAssertion;
import com.sun.xml.wss.impl.policy.MLSPolicy;
import com.sun.xml.wss.impl.policy.SecurityPolicy;
import com.sun.xml.wss.impl.policy.mls.AuthenticationTokenPolicy;
import com.sun.xml.wss.impl.policy.mls.DerivedTokenKeyBinding;
import com.sun.xml.wss.impl.policy.mls.EncryptionPolicy;
import com.sun.xml.wss.impl.policy.mls.EncryptionTarget;
import com.sun.xml.wss.impl.policy.mls.IssuedTokenKeyBinding;
import com.sun.xml.wss.impl.policy.mls.MessagePolicy;
import com.sun.xml.wss.impl.policy.mls.SecureConversationTokenKeyBinding;
import com.sun.xml.wss.impl.policy.mls.SignaturePolicy;
import com.sun.xml.wss.impl.policy.mls.SignatureTarget;
import com.sun.xml.wss.impl.policy.mls.SymmetricKeyBinding;
import com.sun.xml.wss.impl.policy.mls.Target;
import com.sun.xml.wss.impl.policy.mls.WSSPolicy;
import com.sun.xml.wss.impl.policy.spi.PolicyVerifier;
import com.sun.xml.wss.logging.LogDomainConstants;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author
 */
public class MessagePolicyVerifier implements PolicyVerifier{
    private ProcessingContext ctx = null;
    private TargetResolver targetResolver;
    
    private static Logger log = Logger.getLogger(
            LogDomainConstants.WSS_API_DOMAIN,
            LogDomainConstants.WSS_API_DOMAIN_BUNDLE);

    /** Creates a new instance of MessagePolicyVerifier */
    public MessagePolicyVerifier(ProcessingContext ctx, TargetResolver targetResolver) {
        this.ctx = ctx;
        this.targetResolver = targetResolver;
    }
    
    public void verifyPolicy(SecurityPolicy ip, SecurityPolicy ap) throws PolicyViolationException {

        MessagePolicy actualPolicy = (MessagePolicy)ap;
        MessagePolicy inferredSecurityPolicy = (MessagePolicy)ip;
        
        if(actualPolicy == null || actualPolicy.size() <= 0){
            if ((inferredSecurityPolicy != null) && (inferredSecurityPolicy.size() > 0)) {
                //this could be a plain SSL scenario
                log.log(Level.SEVERE, "WSS0805.policy.null");
                throw new PolicyViolationException("ERROR: Policy for the service could not be obtained");
            }
        } else if(inferredSecurityPolicy == null || inferredSecurityPolicy.size() <= 0){
            throw new PolicyViolationException("ERROR: No security header found in the message");
        } else{ // verify policy now
            try{
                for(int i = 0; i < actualPolicy.size(); i++) {
                    WSSPolicy actualPol = (WSSPolicy)actualPolicy.get(i);
                    if(PolicyTypeUtil.isSecondaryPolicy(actualPol)){
                        processSecondaryPolicy(actualPol, inferredSecurityPolicy);
                    } else if(PolicyTypeUtil.isPrimaryPolicy(actualPol)){
                        processPrimaryPolicy(actualPol, inferredSecurityPolicy);
                    }
                }
                
            } catch(Exception e){
                throw new PolicyViolationException(e);
            }
        }
    }
    
    
    private  void processSecondaryPolicy(WSSPolicy actualPol,
            MessagePolicy inferredSecurityPolicy) throws XWSSecurityException{
        try{
            if(PolicyTypeUtil.timestampPolicy(actualPol)){
                boolean found = false;
                for(int j = 0; j < inferredSecurityPolicy.size(); j++) {
                    WSSPolicy pol = (WSSPolicy)inferredSecurityPolicy.get(j);
                    if(PolicyTypeUtil.timestampPolicy(pol)){
                        inferredSecurityPolicy.remove(pol);
                        found = true;
                        break;
                    }
                }
                if(!found){
                    if (MessageConstants.debug) {
                        log.log(Level.WARNING, "Timestamp not found in configured policy but occurs in message");
                    }
                    // commenting for now, uncomment once this is corrected in SecurityPolicy
                    /*throw new XWSSecurityException("Policy Verification error:"
                            + "Timestamp not found in configured policy but occurs in message");*/
                }
            } else if(PolicyTypeUtil.usernameTokenPolicy(actualPol)){
                boolean found = false;
                for(int j = 0; j < inferredSecurityPolicy.size(); j++) {
                    WSSPolicy pol = (WSSPolicy)inferredSecurityPolicy.get(j);
                    if(PolicyTypeUtil.usernameTokenPolicy(pol)){
                        inferredSecurityPolicy.remove(pol);
                        found = true;
                        break;
                    }
                }
                if(!found){
                    throw new XWSSecurityException("Policy Verification error:"
                            + "UsernameToken not found in configured policy but occurs in message");
                }
            }
        } catch(Exception e){
            throw new XWSSecurityException(e);
        }
    }
    
    private  void processPrimaryPolicy(WSSPolicy actualPol,
            MessagePolicy inferredSecurityPolicy) throws XWSSecurityException{
        
        WSSAssertion wssAssertion = ((ProcessingContextImpl)ctx).getWSSAssertion();
        if(PolicyTypeUtil.signaturePolicy(actualPol)){
            SignaturePolicy actualSignPolicy = (SignaturePolicy)actualPol;
            boolean isEndorsing = ((SignaturePolicy.FeatureBinding)actualSignPolicy.getFeatureBinding()).isEndorsingSignature();
            WSSPolicy pol = getFirstPrimaryPolicy(inferredSecurityPolicy, isEndorsing);
            if(pol == null){
                throw new XWSSecurityException("Policy verification error:" +
                        "Missing Signature Element");
            }
            
            if(PolicyTypeUtil.signaturePolicy(pol)){
                SignaturePolicy inferredPol = (SignaturePolicy)pol;
                // verify key binding
                boolean isKBTrue = verifyKeyBinding(actualSignPolicy.getKeyBinding(), inferredPol.getKeyBinding(),
                        wssAssertion, false);
                // verify target binding
                boolean isTBTrue = verifySignTargetBinding((SignaturePolicy.FeatureBinding)actualSignPolicy.getFeatureBinding(),
                        (SignaturePolicy.FeatureBinding)inferredPol.getFeatureBinding());
                
                inferredSecurityPolicy.remove(pol);
                if(!isKBTrue){
                    log.log(Level.SEVERE, "WSS0206.policy.violation.exception");
                    throw new XWSSecurityException("Policy verification error: " +
                            "Incorrect Key types or references were used in Signature");
                }
                if(!isTBTrue){
                    log.log(Level.SEVERE, "WSS0206.policy.violation.exception");
                    throw new XWSSecurityException("Policy verification error: " +
                            "One or more Signed Parts could not be validated");
                }
                checkTargets(actualPol, pol);
            } else{
                log.log(Level.SEVERE, "WSS0206.policy.violation.exception");
                throw new XWSSecurityException("Signature Policy verification error: Looking for a Signature Element "
                        + " in Security header, but found " +  pol +  ".");
                
            }
        } else if(PolicyTypeUtil.encryptionPolicy(actualPol)){
            EncryptionPolicy actualEncryptionPolicy = (EncryptionPolicy)actualPol;
            WSSPolicy pol = getFirstPrimaryPolicy(inferredSecurityPolicy, false);
            if(pol == null){
                throw new XWSSecurityException("Encryption Policy verification error:" +
                        "Missing encryption element");
            }
            
            if(PolicyTypeUtil.encryptionPolicy(pol)){
                EncryptionPolicy inferredPol = (EncryptionPolicy)pol;
                //verify key binding
                boolean isKBTrue = verifyKeyBinding(actualEncryptionPolicy.getKeyBinding(),
                        inferredPol.getKeyBinding(), wssAssertion, true);
                // verify target binding
                boolean isTBTrue = verifyEncTargetBinding((EncryptionPolicy.FeatureBinding)actualEncryptionPolicy.getFeatureBinding(),
                        (EncryptionPolicy.FeatureBinding)inferredPol.getFeatureBinding());
                
                inferredSecurityPolicy.remove(pol);
                if(!isKBTrue){
                    log.log(Level.SEVERE, "WSS0206.policy.violation.exception");
                    throw new XWSSecurityException("Encryption Policy verification error: " +
                            "Incorrect Key types or references were used in encryption");
                }
                if(!isTBTrue){
                    log.log(Level.SEVERE, "WSS0206.policy.violation.exception");
                    throw new XWSSecurityException("Policy verification error: " +
                            "One or more encrypted parts could not be validated");
                }
                checkTargets(actualPol, pol);
            } else{
                log.log(Level.SEVERE, "WSS0206.policy.violation.exception");
                throw new XWSSecurityException("Encryption Policy verification error: Looking for an Encryption Element "
                        + " in Security header, but found " +  pol +  ".");
            }
            
        }
        
    }
    
    private void checkTargets(WSSPolicy actualPol, WSSPolicy inferredPol) throws XWSSecurityException{
        
        List<Target> inferredTargets = null;
        List<Target> actualTargets = null;
        
        if(PolicyTypeUtil.signaturePolicy(actualPol)){
            
            SignaturePolicy.FeatureBinding inferredFeatureBinding =
                    (SignaturePolicy.FeatureBinding)inferredPol.getFeatureBinding();
            SignaturePolicy.FeatureBinding actualFeatureBinding =
                    (SignaturePolicy.FeatureBinding)actualPol.getFeatureBinding();

            inferredTargets = (List<Target>)inferredFeatureBinding.getTargetBindings();
            actualTargets = (List<Target>)actualFeatureBinding.getTargetBindings();
            
        }else if(PolicyTypeUtil.encryptionPolicy(actualPol)){
            
            EncryptionPolicy.FeatureBinding inferredFeatureBinding =
                    (EncryptionPolicy.FeatureBinding)inferredPol.getFeatureBinding();
            EncryptionPolicy.FeatureBinding actualFeatureBinding =
                    (EncryptionPolicy.FeatureBinding)actualPol.getFeatureBinding();

            inferredTargets = (List<Target>)inferredFeatureBinding.getTargetBindings();
            actualTargets = (List<Target>)actualFeatureBinding.getTargetBindings();
            
        }
        targetResolver.resolveAndVerifyTargets(actualTargets, inferredTargets, actualPol);
    }
    
    private boolean verifyKeyBinding(MLSPolicy actualKeyBinding,
            MLSPolicy inferredKeyBinding, WSSAssertion wssAssertion, 
            boolean isEncryptPolicy) throws XWSSecurityException {
        boolean verified = false;
        if(actualKeyBinding != null && inferredKeyBinding != null){
            if(PolicyTypeUtil.x509CertificateBinding(actualKeyBinding) &&
                    PolicyTypeUtil.x509CertificateBinding(inferredKeyBinding)){
                    /* TODO: cannot change actual policy, there seems to be a bug in
                     * security policy
                    AuthenticationTokenPolicy.X509CertificateBinding actualX509Bind =
                            (AuthenticationTokenPolicy.X509CertificateBinding)actualKeyBinding;
                    AuthenticationTokenPolicy.X509CertificateBinding inferredX509Bind =
                            (AuthenticationTokenPolicy.X509CertificateBinding)inferredKeyBinding;
                    // workaround - policy sets reference type as Thumprint
                    if(actualX509Bind.getReferenceType().equals(MessageConstants.THUMB_PRINT_TYPE))
                        actualX509Bind.setReferenceType(MessageConstants.KEY_INDETIFIER_TYPE);
                    correctIncludeTokenPolicy(actualX509Bind, wssAssertion);
                    if(actualX509Bind.getReferenceType().equals(inferredX509Bind.getReferenceType()))*/
                verified =  true;
            } else if(PolicyTypeUtil.symmetricKeyBinding(actualKeyBinding) &&
                    PolicyTypeUtil.symmetricKeyBinding(inferredKeyBinding)){
                verified = verifyKeyBinding(
                        actualKeyBinding.getKeyBinding(), inferredKeyBinding.getKeyBinding(),
                        wssAssertion, isEncryptPolicy);
            } else if(PolicyTypeUtil.issuedTokenKeyBinding(actualKeyBinding) &&
                    PolicyTypeUtil.issuedTokenKeyBinding(inferredKeyBinding)){
                
                verified = true;
            } else if(PolicyTypeUtil.secureConversationTokenKeyBinding(actualKeyBinding) &&
                    PolicyTypeUtil.secureConversationTokenKeyBinding(inferredKeyBinding)){
                
                verified = true;
            } else if(PolicyTypeUtil.derivedTokenKeyBinding(actualKeyBinding) &&
                    PolicyTypeUtil.derivedTokenKeyBinding(inferredKeyBinding)){
                
                verified = verifyKeyBinding(((DerivedTokenKeyBinding)actualKeyBinding).getOriginalKeyBinding(),
                        ((DerivedTokenKeyBinding)inferredKeyBinding).getOriginalKeyBinding(),
                        wssAssertion, isEncryptPolicy);
            } else if (PolicyTypeUtil.x509CertificateBinding(actualKeyBinding) &&
                    PolicyTypeUtil.symmetricKeyBinding(inferredKeyBinding)){
                MLSPolicy ikbkb = inferredKeyBinding.getKeyBinding();
                if (isEncryptPolicy && PolicyTypeUtil.x509CertificateBinding(ikbkb)) {
                    verified = true;
                }
            } else if (PolicyTypeUtil.samlTokenPolicy(actualKeyBinding) &&
                    PolicyTypeUtil.symmetricKeyBinding(inferredKeyBinding)){
                MLSPolicy ikbkb = inferredKeyBinding.getKeyBinding();
                if (isEncryptPolicy && PolicyTypeUtil.samlTokenPolicy(ikbkb)) {
                    verified = true;
                }
            } else if (PolicyTypeUtil.samlTokenPolicy(actualKeyBinding) &&
                    PolicyTypeUtil.samlTokenPolicy(inferredKeyBinding)){                
                    
                verified = true;                
            } else if (PolicyTypeUtil.symmetricKeyBinding(actualKeyBinding) &&
                             PolicyTypeUtil.x509CertificateBinding(inferredKeyBinding)) {
                MLSPolicy akbkb = actualKeyBinding.getKeyBinding();
                if (isEncryptPolicy && PolicyTypeUtil.x509CertificateBinding(akbkb)) {
                    verified = true;
                }
            } else if (PolicyTypeUtil.derivedTokenKeyBinding(actualKeyBinding)) {
                //workaround for IssuedToken under Endorsing, with PublicKey inside IssuedToken
                if (PolicyTypeUtil.issuedTokenKeyBinding(inferredKeyBinding) &&
                       PolicyTypeUtil.issuedTokenKeyBinding(
                        ((DerivedTokenKeyBinding)actualKeyBinding).getOriginalKeyBinding())) {
                    verified = true;
                }
            }
        }
        
        return verified;
    }
    
    private boolean verifySignTargetBinding(SignaturePolicy.FeatureBinding actualFeatureBinding,
            SignaturePolicy.FeatureBinding inferredFeatureBinding) throws XWSSecurityException {
            String actualCanonAlgo = actualFeatureBinding.getCanonicalizationAlgorithm ();
            String inferredCanonAlgo = inferredFeatureBinding.getCanonicalizationAlgorithm ();

            if(actualCanonAlgo == null || inferredCanonAlgo == null){
                throw new XWSSecurityException("ActualCanonicalizationAlgorithm or InferredCanonicalizationAlgorithm "
                        +" is null while verifying SignatureTargetBinding");
            }
            if(actualCanonAlgo.length () >0 && inferredCanonAlgo.length () >0 ){
                if(!inferredCanonAlgo.equals (actualCanonAlgo)){
                    log.warning("Receiver side requirement verification failed,"+
                            " canonicalization algorithm received in the message is "+ inferredCanonAlgo
                            + " policy requires "+actualCanonAlgo);
                    return false;
                }
            }
        
        return true;
    }
    
    private boolean verifyEncTargetBinding(EncryptionPolicy.FeatureBinding actualFeatureBinding,
            EncryptionPolicy.FeatureBinding inferredFeatureBinding){
            String rDA = inferredFeatureBinding.getDataEncryptionAlgorithm ();
            String cDA = actualFeatureBinding.getDataEncryptionAlgorithm ();
            if(cDA != null && cDA.length () > 0 ){
                if(!cDA.equals (rDA)){
                    log.warning ("Receiver side requirement verification failed, "+
                            "DataEncryptionAlgorithm specified in the receiver requirements did match with"
                            +" DataEncryptionAlgorithm used to encrypt the message."+
                            "Configured DataEncryptionAlgorithm is "+cDA+"  DataEncryptionAlgorithm used in the" +
                            "message is "+rDA);
                    return false;
                }
            }        
        return true;
    }
    
    private WSSPolicy getFirstPrimaryPolicy(MessagePolicy securityPolicy, boolean isEndorsingSign) throws 
            XWSSecurityException{
        try{
            if(!isEndorsingSign){
                for(int i = 0; i < securityPolicy.size(); i++){
                    WSSPolicy pol = (WSSPolicy)securityPolicy.get(i);
                    if(PolicyTypeUtil.isPrimaryPolicy(pol)){
                        // accounts for encrypted SAML tokens issued by STS 
                        if(PolicyTypeUtil.encryptionPolicy(pol) && 
                               ((EncryptionPolicy.FeatureBinding)pol.getFeatureBinding()).encryptsIssuedToken() ){
                            continue;
                        } else
                            return pol;
                    }
                }
            } else{
                // endorsingSign policy is not placed correctly in actual policy
                for(int i = 0; i < securityPolicy.size(); i++){
                    WSSPolicy pol = (WSSPolicy)securityPolicy.get(i);
                    if(PolicyTypeUtil.isPrimaryPolicy(pol) && PolicyTypeUtil.signaturePolicy(pol)){
                        SignaturePolicy signPol = (SignaturePolicy)pol;
                        SignaturePolicy.FeatureBinding fb = (SignaturePolicy.FeatureBinding)signPol.getFeatureBinding();
                        if(fb.getTargetBindings().size() == 1){
                            SignatureTarget target = (SignatureTarget)fb.getTargetBindings().get(0);
                            if("{http://www.w3.org/2000/09/xmldsig#}Signature".equals(target.getValue()))
                                return pol;
                        }
                    }
                }
            }
        } catch(Exception e){
            throw new XWSSecurityException(e);
        }
        return null;
    }
    
    private void correctIncludeTokenPolicy(AuthenticationTokenPolicy.X509CertificateBinding x509Bind, 
            WSSAssertion wssAssertion){
        if(x509Bind.INCLUDE_NEVER.equals(x509Bind.getIncludeToken())){
            if(MessageConstants.DIRECT_REFERENCE_TYPE.equals(x509Bind.getReferenceType())){
                if(wssAssertion != null){
                    if(wssAssertion.getRequiredProperties().contains(WSSAssertion.MUST_SUPPORT_REF_KEYIDENTIFIER))
                        x509Bind.setReferenceType(MessageConstants.KEY_INDETIFIER_TYPE);
                    else if(wssAssertion.getRequiredProperties().contains(WSSAssertion.MUSTSUPPORT_REF_THUMBPRINT))
                        x509Bind.setReferenceType(MessageConstants.THUMB_PRINT_TYPE);                    
                } else {
                    // when wssAssertion is not set use KeyIdentifier
                    x509Bind.setReferenceType(MessageConstants.KEY_INDETIFIER_TYPE);
                }
            }
        } else if(x509Bind.INCLUDE_ALWAYS_TO_RECIPIENT.equals(x509Bind.getIncludeToken()) || 
                x509Bind.INCLUDE_ALWAYS.equals(x509Bind.getIncludeToken())){
            x509Bind.setReferenceType(MessageConstants.DIRECT_REFERENCE_TYPE);
        }
    }
    
    public void printInferredSecurityPolicy(MessagePolicy inferredSecurityPolicy) throws Exception{
        StringBuffer buffer = new StringBuffer();
        if(inferredSecurityPolicy == null){
            buffer.append("Security Policy not set\n");
        } else{
            buffer.append("Size of Policy:: " + inferredSecurityPolicy.size() + "\n");
            for(int i = 0; i < inferredSecurityPolicy.size(); i++){
                WSSPolicy pol = (WSSPolicy)inferredSecurityPolicy.get(i);
                if(PolicyTypeUtil.timestampPolicy(pol)){
                    buffer.append("Timestamp Policy\n");
                } else if(PolicyTypeUtil.usernameTokenPolicy(pol)){
                    buffer.append("UsernameToken Policy\n");                    
                } else if(PolicyTypeUtil.signaturePolicy(pol)){
                    buffer.append("Signature Policy\n");
                    SignaturePolicy sigPol = (SignaturePolicy)pol;
                    SignaturePolicy.FeatureBinding featureBinding = 
                            (SignaturePolicy.FeatureBinding)sigPol.getFeatureBinding();
                    ArrayList targets = featureBinding.getTargetBindings();
                    buffer.append("\tCanonicalizationAlgorithm" + featureBinding.getCanonicalizationAlgorithm() + "\n");
                    buffer.append("\t Targets\n");
                    for(int j = 0; j < targets.size(); j++){
                        SignatureTarget target = (SignatureTarget)targets.get(j);
                        buffer.append("\t " + j + ":Type:" + target.getType() + "\n");
                        buffer.append("\t  Value:" + target.getValue() + "\n");
                        buffer.append("\t  DigestAlgorithm:" + target.getDigestAlgorithm() + "\n");
                        ArrayList transforms = target.getTransforms();
                        
                        if(transforms != null){
                            buffer.append("\t  " + "Transforms::\n");
                            for(int k = 0; k < transforms.size(); k++){
                                buffer.append("\t " + "   " + ((SignatureTarget.Transform)transforms.get(k)).getTransform() + "\n");
                            }
                        }
                    }
                    MLSPolicy keyBinding = sigPol.getKeyBinding();
                    if(keyBinding != null){
                        buffer.append("\tKeyBinding\n");
                        printKeyBinding(keyBinding, buffer);
                    }
                } else if(PolicyTypeUtil.encryptionPolicy(pol)){
                    buffer.append("Encryption Policy\n");
                    EncryptionPolicy encPol = (EncryptionPolicy)pol;
                    EncryptionPolicy.FeatureBinding featureBinding = 
                            (EncryptionPolicy.FeatureBinding)encPol.getFeatureBinding();
                    ArrayList targets = featureBinding.getTargetBindings();
                    buffer.append("\t Targets\n");
                    for(int j = 0; j < targets.size(); j++){
                        EncryptionTarget target = (EncryptionTarget)targets.get(j);
                        buffer.append("\t " + j + ":"+ "Type:" + target.getType() + "\n");
                        buffer.append("\t  Value:" + target.getValue() + "\n");
                        buffer.append("\t  ContentOnly:" + target.getContentOnly() + "\n");
                        buffer.append("\t  DataEncryptionAlgorithm:" + target.getDataEncryptionAlgorithm() + "\n");
                    }
                    MLSPolicy keyBinding = encPol.getKeyBinding();
                    if(keyBinding != null){
                        buffer.append("\tKeyBinding\n");
                        printKeyBinding(keyBinding, buffer);
                    }                   
                } else if(PolicyTypeUtil.signatureConfirmationPolicy(pol)){
                    buffer.append("SignatureConfirmation Policy\n");
                } else{
                    buffer.append(pol + "\n");
                }
            }
        }
        if (MessageConstants.debug) {
            System.out.println(buffer.toString());
        }
    }
    
    private void printKeyBinding(MLSPolicy keyBinding, StringBuffer buffer){
        if(keyBinding != null){        
            if(keyBinding instanceof AuthenticationTokenPolicy.X509CertificateBinding){
                AuthenticationTokenPolicy.X509CertificateBinding x509Binding =
                        (AuthenticationTokenPolicy.X509CertificateBinding)keyBinding;
                buffer.append("\t  X509CertificateBinding\n");
                buffer.append("\t    ValueType:" + x509Binding.getValueType() + "\n");
                buffer.append("\t    ReferenceType:" + x509Binding.getReferenceType() + "\n");
            } else if(keyBinding instanceof AuthenticationTokenPolicy.SAMLAssertionBinding){
                AuthenticationTokenPolicy.SAMLAssertionBinding samlBinding =
                        (AuthenticationTokenPolicy.SAMLAssertionBinding)keyBinding;
                buffer.append("\t  SAMLAssertionBinding\n");
                //buffer.append("\t    ValueType:" + samlBinding.getValueType() + "\n");
                buffer.append("\t    ReferenceType:" + samlBinding.getReferenceType() + "\n");
            } else if(keyBinding instanceof SymmetricKeyBinding){
                SymmetricKeyBinding skBinding = (SymmetricKeyBinding)keyBinding;
                buffer.append("\t  SymmetricKeyBinding\n");
                AuthenticationTokenPolicy.X509CertificateBinding x509Binding =
                        (AuthenticationTokenPolicy.X509CertificateBinding)skBinding.getKeyBinding();
                if(x509Binding != null){
                    buffer.append("\t     X509CertificateBinding\n");
                    buffer.append("\t       ValueType:" + x509Binding.getValueType() + "\n");
                    buffer.append("\t       ReferenceType:" + x509Binding.getReferenceType() + "\n");
                }
            } else if(keyBinding instanceof IssuedTokenKeyBinding){
                buffer.append("\t  IssuedTokenKeyBinding\n");
                            
            } else if(keyBinding instanceof SecureConversationTokenKeyBinding){
                buffer.append("\t  SecureConversationTokenKeyBinding\n");
                            
            }else if(keyBinding instanceof DerivedTokenKeyBinding){
                buffer.append("\t  DerivedTokenKeyBinding\n");
                DerivedTokenKeyBinding dtkBinding = (DerivedTokenKeyBinding)keyBinding;
                buffer.append("\t  OriginalKeyBinding:\n");
                printKeyBinding(dtkBinding.getOriginalKeyBinding(), buffer);
            }
        }        
    }
}
