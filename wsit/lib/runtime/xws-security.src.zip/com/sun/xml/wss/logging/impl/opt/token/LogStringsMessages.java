
package com.sun.xml.wss.logging.impl.opt.token;

import com.sun.xml.ws.util.localization.Localizable;
import com.sun.xml.ws.util.localization.LocalizableMessageFactory;
import com.sun.xml.ws.util.localization.Localizer;


/**
 * Defines string formatting method for each constant in the resource file
 * 
 */
public final class LogStringsMessages {

    private final static LocalizableMessageFactory messageFactory = new LocalizableMessageFactory("com.sun.xml.wss.logging.impl.opt.token.LogStrings");
    private final static Localizer localizer = new Localizer();

    public static Localizable localizableWSS_1810_NULL_PRIVATEKEY_SAML() {
        return messageFactory.getMessage("WSS1810.null.privatekey.saml");
    }

    /**
     * WSS1810: Private key is set to null inside the private key binding for SAML policy used for Signature
     * 
     */
    public static String WSS_1810_NULL_PRIVATEKEY_SAML() {
        return localizer.localize(localizableWSS_1810_NULL_PRIVATEKEY_SAML());
    }

    public static Localizable localizableWSS_1811_NULL_SAML_ASSERTION() {
        return messageFactory.getMessage("WSS1811.null.saml.assertion");
    }

    /**
     * WSS1811: SAML assertion is set to null for SAML Binding used for Signature
     * 
     */
    public static String WSS_1811_NULL_SAML_ASSERTION() {
        return localizer.localize(localizableWSS_1811_NULL_SAML_ASSERTION());
    }

    public static Localizable localizableWSS_1807_CERT_PROOF_KEY_NULL_ISSUEDTOKEN() {
        return messageFactory.getMessage("WSS1807.cert.proofKey.null.issuedtoken");
    }

    /**
     * WSS1807: Requestor Certificate and Proof Key are both null for Issued Token
     * 
     */
    public static String WSS_1807_CERT_PROOF_KEY_NULL_ISSUEDTOKEN() {
        return localizer.localize(localizableWSS_1807_CERT_PROOF_KEY_NULL_ISSUEDTOKEN());
    }

    public static Localizable localizableWSS_1804_WRONG_ENCRYPTED_KEY() {
        return messageFactory.getMessage("WSS1804.wrong.encrypted.key");
    }

    /**
     * WSS1804: The length of encryptedKey Id is 0
     * 
     */
    public static String WSS_1804_WRONG_ENCRYPTED_KEY() {
        return localizer.localize(localizableWSS_1804_WRONG_ENCRYPTED_KEY());
    }

    public static Localizable localizableWSS_1801_BST_CREATION_FAILED() {
        return messageFactory.getMessage("WSS1801.bst.creation.failed");
    }

    /**
     * WSS1801: Error occured while constructing BinarySecurityToken.
     * 
     */
    public static String WSS_1801_BST_CREATION_FAILED() {
        return localizer.localize(localizableWSS_1801_BST_CREATION_FAILED());
    }

    public static Localizable localizableWSS_1803_UNSUPPORTED_REFERENCE_TYPE(Object arg0) {
        return messageFactory.getMessage("WSS1803.unsupported.reference.type", arg0);
    }

    /**
     * WSS1803: The reference type {0} is not supported
     * 
     */
    public static String WSS_1803_UNSUPPORTED_REFERENCE_TYPE(Object arg0) {
        return localizer.localize(localizableWSS_1803_UNSUPPORTED_REFERENCE_TYPE(arg0));
    }

    public static Localizable localizableWSS_1812_MISSING_CERT_SAMLASSERTION() {
        return messageFactory.getMessage("WSS1812.missing.cert.samlassertion");
    }

    /**
     * WSS1812: Could not locate Certificate corresponding to Key in SubjectConfirmation of SAML Assertion
     * 
     */
    public static String WSS_1812_MISSING_CERT_SAMLASSERTION() {
        return localizer.localize(localizableWSS_1812_MISSING_CERT_SAMLASSERTION());
    }

    public static Localizable localizableWSS_1809_SCT_NOT_FOUND() {
        return messageFactory.getMessage("WSS1809.sct.not.found");
    }

    /**
     * WSS1809: SecureConversation token not found in the session.
     * 
     */
    public static String WSS_1809_SCT_NOT_FOUND() {
        return localizer.localize(localizableWSS_1809_SCT_NOT_FOUND());
    }

    public static Localizable localizableWSS_1802_WRONG_TOKENINCLUSION_POLICY() {
        return messageFactory.getMessage("WSS1802.wrong.tokeninclusion.policy");
    }

    /**
     * WSS1802: IncludeToken policy is Never and WSSAssertion has KeyIndentifier/Thumbprint reference types set to false
     * 
     */
    public static String WSS_1802_WRONG_TOKENINCLUSION_POLICY() {
        return localizer.localize(localizableWSS_1802_WRONG_TOKENINCLUSION_POLICY());
    }

    public static Localizable localizableWSS_1805_DERIVEDKEYS_WITH_ASYMMETRICBINDING_UNSUPPORTED() {
        return messageFactory.getMessage("WSS1805.derivedkeys.with.asymmetricbinding.unsupported");
    }

    /**
     * WSS1805: Asymmetric Binding with DerivedKeys under X509Token Policy Not Yet Supported
     * 
     */
    public static String WSS_1805_DERIVEDKEYS_WITH_ASYMMETRICBINDING_UNSUPPORTED() {
        return localizer.localize(localizableWSS_1805_DERIVEDKEYS_WITH_ASYMMETRICBINDING_UNSUPPORTED());
    }

    public static Localizable localizableWSS_1806_ERROR_GENERATING_SYMMETRIC_KEY() {
        return messageFactory.getMessage("WSS1806.error.generating.symmetric.key");
    }

    /**
     * WSS1806: Error in generating symmetric keys. The algorithm provided was incorrect.
     * 
     */
    public static String WSS_1806_ERROR_GENERATING_SYMMETRIC_KEY() {
        return localizer.localize(localizableWSS_1806_ERROR_GENERATING_SYMMETRIC_KEY());
    }

    public static Localizable localizableWSS_1813_UNSUPPORTED_EMBEDDEDREFERENCETYPE_SAML() {
        return messageFactory.getMessage("WSS1813.unsupported.embeddedreferencetype.saml");
    }

    /**
     * WSS1813: Embedded Reference Type for SAML Assertions not supported yet
     * 
     */
    public static String WSS_1813_UNSUPPORTED_EMBEDDEDREFERENCETYPE_SAML() {
        return localizer.localize(localizableWSS_1813_UNSUPPORTED_EMBEDDEDREFERENCETYPE_SAML());
    }

    public static Localizable localizableWSS_1808_ID_NOTSET_ENCRYPTED_ISSUEDTOKEN() {
        return messageFactory.getMessage("WSS1808.id.notset.encrypted.issuedtoken");
    }

    /**
     * WSS1808: Id attribute not set on Encrypted IssuedToken
     * 
     */
    public static String WSS_1808_ID_NOTSET_ENCRYPTED_ISSUEDTOKEN() {
        return localizer.localize(localizableWSS_1808_ID_NOTSET_ENCRYPTED_ISSUEDTOKEN());
    }

}
