/*
 * AlgorithmSuite.java
 *
 * Created on September 5, 2006, 10:44 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.sun.xml.wss.impl;

/**
 *
 * @author sk112103
 */
public class AlgorithmSuite {
    
    private String digestAlgo;
    private String encryptionAlgo;
    private String symKeyAlgo;
    private String asymKeyAlgo;
    
    /** Creates a new instance of AlgorithmSuite 
     * TODO : Created a minimal CTOR for now. Add more info into this as needed.
     * Created to remove dependence of XWSS on WS-SecurityPolicy.
     */
    public AlgorithmSuite(String digAlgo, String encAlgo, String symkAlgo, String asymkAlgo ) {
        this.digestAlgo = digAlgo;
        this.encryptionAlgo = encAlgo;
        this.symKeyAlgo = symkAlgo;
        this.asymKeyAlgo = asymkAlgo;
    }
    
    public String getDigestAlgorithm() {
        return digestAlgo;
    }
    
    
    public String getEncryptionAlgorithm() {
        return encryptionAlgo;
    }
    
    
    public String getSymmetricKeyAlgorithm() {
        return symKeyAlgo;
    }
    
    public String getAsymmetricKeyAlgorithm() {
        return asymKeyAlgo;
    }
    
    public String getSignatureKDAlogrithm() {
        throw new UnsupportedOperationException("getSignatureKDAlogrithm not supported");
    }
    
    public String getEncryptionKDAlogrithm() {
        throw new UnsupportedOperationException("getEncryptionKDAlogrithm not supported");
    }
    
    public int getMinSKLAlgorithm() {
        throw new UnsupportedOperationException("getMinSKLAlgorithm not supported");
    }
    
    public String getSymmetricKeySignatureAlgorithm() {
        throw new UnsupportedOperationException("getSymmetricKeySignatureAlgorithm not supported");
    }
    
    public String getAsymmetricKeySignatureAlgorithm() {
      throw new UnsupportedOperationException(" getAsymmetricKeySignatureAlgorithm not supported");
    }
    
}
