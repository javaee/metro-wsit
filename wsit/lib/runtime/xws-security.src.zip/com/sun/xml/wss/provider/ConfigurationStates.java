/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://jwsdp.dev.java.net/CDDLv1.0.html
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * https://jwsdp.dev.java.net/CDDLv1.0.html  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
/*
 * $Id: ConfigurationStates.java,v 1.2 2006/09/21 05:41:51 kumarjayanti Exp $
 *
 * Copyright 2004 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.xml.wss.provider;

import com.sun.enterprise.security.jauth.AuthPolicy;

public interface ConfigurationStates {
     public static final int AUTHENTICATE_RECIPIENT_ONLY = 1;
     public static final int AUTHENTICATE_SENDER_TOKEN_ONLY = 2;
     public static final int AUTHENTICATE_SENDER_SIGNATURE_ONLY = 3;
     public static final int AUTHENTICATE_RECIPIENT_AUTHENTICATE_SENDER_TOKEN = 4;
     public static final int AUTHENTICATE_SENDER_TOKEN_AUTHENTICATE_RECIPIENT = 5;
     public static final int AUTHENTICATE_RECIPIENT_AUTHENTICATE_SENDER_SIGNATURE = 6;
     public static final int AUTHENTICATE_SENDER_SIGNATURE_AUTHENTICATE_RECIPIENT = 7;
     public static final int EMPTY_POLICY_STATE = 8;

     // resolve required config. state 
     int resolveConfigurationState(AuthPolicy policy, 
                                   boolean isRequestPolicy, 
                                   boolean isClientAuthModule); 
}