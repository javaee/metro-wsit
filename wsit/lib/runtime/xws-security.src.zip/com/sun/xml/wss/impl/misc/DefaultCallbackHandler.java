/*
 * $Id: DefaultCallbackHandler.java,v 1.14 2007/01/29 13:35:57 shyam_rao Exp $
 *
 */
/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License).  You may not use this file except in
 * compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * you own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 * 
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 */

package com.sun.xml.wss.impl.misc;

import com.sun.xml.wss.logging.LogDomainConstants;
import java.io.IOException;
import java.io.InputStream;
import java.io.FileInputStream;

import java.net.URI;
import java.util.Enumeration;
import java.util.Map;
import java.util.Properties;
import java.util.Arrays;
import java.util.Date;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.text.SimpleDateFormat;
import java.math.BigInteger;

import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.CertPathBuilder;
import java.security.cert.Certificate;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateNotYetValidException;
import java.security.cert.PKIXBuilderParameters;
import java.security.cert.PKIXCertPathBuilderResult;
import java.security.cert.X509CertSelector;
import java.security.cert.X509Certificate;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;

import com.sun.xml.wss.impl.callback.CertificateValidationCallback;
import com.sun.xml.wss.impl.callback.DecryptionKeyCallback;
import com.sun.xml.wss.impl.callback.EncryptionKeyCallback;
import com.sun.xml.wss.impl.callback.PasswordCallback;
import com.sun.xml.wss.impl.callback.PasswordValidationCallback;
import com.sun.xml.wss.impl.callback.SignatureKeyCallback;
import com.sun.xml.wss.impl.callback.SignatureVerificationKeyCallback;
import com.sun.xml.wss.impl.callback.UsernameCallback;
import com.sun.xml.wss.impl.callback.TimestampValidationCallback;
import com.sun.xml.wss.impl.callback.SAMLAssertionValidator;
import com.sun.xml.wss.impl.callback.DynamicPolicyCallback;

import com.sun.org.apache.xml.internal.security.utils.RFC2253Parser;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateEncodingException;


import com.sun.xml.ws.security.trust.WSTrustConstants;
import com.sun.xml.wss.RealmAuthenticationAdapter;

import com.sun.xml.wss.XWSSecurityException;
import com.sun.xml.wss.impl.MessageConstants;
import com.sun.xml.wss.impl.callback.SAMLCallback;
import com.sun.xml.wss.impl.policy.SecurityPolicy;
import com.sun.xml.wss.impl.policy.mls.AuthenticationTokenPolicy;
import com.sun.xml.wss.impl.policy.mls.PrivateKeyBinding;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Iterator;
import java.util.Set;
import javax.security.auth.Subject;
import org.w3c.dom.Element;


/**
 * A sample implementation of a CallbackHandler.
 */
public  class DefaultCallbackHandler implements CallbackHandler {

    public static final String KEYSTORE_URL="keystore.url";
    public static final String KEYSTORE_TYPE="keystore.type";
    public static final String KEYSTORE_PASSWORD="keystore.password";
    public static final String KEY_PASSWORD="key.password";
    public static final String MY_ALIAS="my.alias";
    public static final String MY_USERNAME="my.username";
    public static final String MY_PASSWORD="my.password";

    public static final String TRUSTSTORE_URL="truststore.url";
    public static final String TRUSTSTORE_TYPE="truststore.type";
    public static final String TRUSTSTORE_PASSWORD="truststore.password";
    public static final String PEER_ENTITY_ALIAS="peerentity.alias";
    public static final String STS_ALIAS="sts.alias";
    public static final String SERVICE_ALIAS="service.alias";

    public static final String USERNAME_CBH="username.callback.handler";
    public static final String PASSWORD_CBH="password.callback.handler";
    public static final String SAML_CBH="saml.callback.handler";

    public static final String USERNAME_VALIDATOR="username.validator";
    public static final String SAML_VALIDATOR="saml.validator";
    public static final String TIMESTAMP_VALIDATOR="timestamp.validator";
    public static final String CERTIFICATE_VALIDATOR="certificate.validator";

    public static final String MAX_CLOCK_SKEW_PROPERTY="max.clock.skew";
    public static final String MAX_NONCE_AGE_PROPERTY="max.nonce.age";
    public static final String TIMESTAMP_FRESHNESS_LIMIT_PROPERTY="timestamp.freshness.limit";
   

    private String keyStoreURL;
    private String keyStorePassword;
    private String keyStoreType;
    private String myAlias;
    private String keyPwd;
    private char[] keyPassword=null;
    
    private String trustStoreURL;
    private String trustStorePassword;
    private String trustStoreType;
    private String peerEntityAlias;
    //private String stsAlias;
    //private String serviceAlias;

    private String myUsername;
    private String myPassword;

    private KeyStore keyStore;
    private KeyStore trustStore;

    private Class usernameCbHandler;
    private Class passwordCbHandler;
    private Class samlCbHandler;

    private Class usernameValidator;
    private Class timestampValidator;
    private Class samlValidator;
    private Class certificateValidator;

    //private String home = null;

    protected long maxClockSkewG;
    protected long timestampFreshnessLimitG;
    protected long maxNonceAge;

    private static Logger log = Logger.getLogger(LogDomainConstants.IMPL_MISC_DOMAIN,LogDomainConstants.IMPL_MISC_DOMAIN_BUNDLE);

    private static final String fileSeparator = System.getProperty("file.separator");
    private static final UnsupportedCallbackException unsupported = 
        new UnsupportedCallbackException(null, "Unsupported Callback Type Encountered");
    private static final URI ISSUE_REQUEST_URI = URI.create(WSTrustConstants.REQUEST_SECURITY_TOKEN_ISSUE_ACTION);        
   
    private CallbackHandler usernameHandler;
    private CallbackHandler passwordHandler;
    private CallbackHandler samlHandler;

    private PasswordValidationCallback.PasswordValidator pwValidator;
    private TimestampValidationCallback.TimestampValidator tsValidator;
    private CertificateValidationCallback.CertificateValidator certValidator;
    private SAMLAssertionValidator sValidator;

    private CertificateValidationCallback.CertificateValidator defaultCertValidator;
    private TimestampValidationCallback.TimestampValidator defaultTSValidator;
    //private PasswordValidationCallback.PasswordValidator defaultPWValidator;
    private RealmAuthenticationAdapter  usernameAuthenticator = null;
    private RealmAuthenticationAdapter  defRealmAuthenticator = null;
          

    public DefaultCallbackHandler(String clientOrServer, Properties assertions) throws Exception {

             Properties properties = null;
             if (assertions != null && !assertions.isEmpty()) {
                 properties = assertions;
             } else {
                 //fallback option
                 properties = new Properties();
                 String resource = clientOrServer + "-security-env.properties";
                 InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream(resource);
                 if (in != null) {
                     properties.load(in);
                 } else {                     
                     //throw new XWSSecurityException("Resource " + resource + " could not be located in classpath");
                 }
             }


             this.keyStoreURL =  properties.getProperty(KEYSTORE_URL);
             this.keyStoreURL = resolveHome(this.keyStoreURL);
             this.keyStoreType = properties.getProperty(KEYSTORE_TYPE);
             this.keyStorePassword = properties.getProperty(KEYSTORE_PASSWORD);
             this.keyPwd = properties.getProperty(KEY_PASSWORD);
             this.myAlias = properties.getProperty(MY_ALIAS);
             this.myUsername =  properties.getProperty(MY_USERNAME);
             this.myPassword =  properties.getProperty(MY_PASSWORD);

                                                                                                         
             this.trustStoreURL = properties.getProperty(TRUSTSTORE_URL);
             this.trustStoreURL = resolveHome(this.trustStoreURL);
             this.keyStoreType = properties.getProperty(KEYSTORE_TYPE);
             this.trustStoreType = properties.getProperty(TRUSTSTORE_TYPE);
             this.trustStorePassword = properties.getProperty(TRUSTSTORE_PASSWORD);
             this.peerEntityAlias =  properties.getProperty(PEER_ENTITY_ALIAS);
             //this.stsAlias =  properties.getProperty(STS_ALIAS);
             //this.serviceAlias = properties.getProperty(SERVICE_ALIAS);


             String uCBH = properties.getProperty(USERNAME_CBH);
             String pCBH = properties.getProperty(PASSWORD_CBH);
             String sCBH = properties.getProperty(SAML_CBH);
             
             String uV = properties.getProperty(USERNAME_VALIDATOR);
             String sV = properties.getProperty(SAML_VALIDATOR);
             String tV = properties.getProperty(TIMESTAMP_VALIDATOR);
             String cV = properties.getProperty(CERTIFICATE_VALIDATOR);

             usernameCbHandler = loadClass(uCBH);
             passwordCbHandler = loadClass(pCBH);
             samlCbHandler = loadClass(sCBH);
             
             usernameValidator = loadClass(uV);
             samlValidator = loadClass(sV);
             timestampValidator = loadClass(tV);
             certificateValidator = loadClass(cV);

             String mcs = properties.getProperty(MAX_CLOCK_SKEW_PROPERTY);
             String tfl = properties.getProperty(TIMESTAMP_FRESHNESS_LIMIT_PROPERTY);
             String mna = properties.getProperty(MAX_NONCE_AGE_PROPERTY);

             maxClockSkewG =  toLong(mcs);
             timestampFreshnessLimitG = toLong(tfl);
             maxNonceAge = toLong(mna);

             initTrustStore();
             initKeyStore();
             initNewInstances();

             defaultCertValidator = new X509CertificateValidatorImpl();
             defaultTSValidator = new  DefaultTimestampValidator();
    }

    public DefaultCallbackHandler(
            String clientOrServer, Properties assertions, RealmAuthenticationAdapter adapter) throws Exception {
        this(clientOrServer, assertions);
        usernameAuthenticator = adapter;
        if (adapter == null) {
            defRealmAuthenticator = RealmAuthenticationAdapter.newInstance(null);
        }
    }
     
    private void handleUsernameCallback(UsernameCallback cb) throws IOException, UnsupportedCallbackException {
        if (myUsername != null) {
            cb.setUsername(myUsername);
        } else if (usernameHandler != null) {
            javax.security.auth.callback.NameCallback nc = new javax.security.auth.callback.NameCallback("Username="); 
            Callback[] cbs = new Callback[] {nc};
            usernameHandler.handle(cbs); 
            cb.setUsername(((javax.security.auth.callback.NameCallback)cbs[0]).getName());
        } else {
            log.log(Level.SEVERE, "WSS1500.invalid.usernameHandler");
            throw new UnsupportedCallbackException(null, "Username Handler Not Configured");
        }
    }

    private void handlePasswordCallback(PasswordCallback cb) throws IOException, UnsupportedCallbackException {
        if (myPassword != null) {
            cb.setPassword(myPassword);
        } else if (passwordHandler != null) {
            javax.security.auth.callback.PasswordCallback pc = new javax.security.auth.callback.PasswordCallback("Password=", false); 
            Callback[] cbs = new Callback[] {pc};
            passwordHandler.handle(cbs); 
            char[] pass = ((javax.security.auth.callback.PasswordCallback)cbs[0]).getPassword();
            cb.setPassword(new String(pass));
        } else {
            log.log(Level.SEVERE, "WSS1525.invalid.passwordHandler");
            throw new UnsupportedCallbackException(null, "Password Handler Not Configured");
        }

    }

    private void handlePasswordValidation(PasswordValidationCallback cb) throws IOException, UnsupportedCallbackException {
        if (cb.getRequest() instanceof PasswordValidationCallback.PlainTextPasswordRequest) {
            if (pwValidator != null) {
                cb.setValidator(pwValidator);
            } else {
                if (usernameAuthenticator != null) {
                    cb.setRealmAuthentcationAdapter(usernameAuthenticator);   
                } else {                    
                    cb.setRealmAuthentcationAdapter(defRealmAuthenticator);
                }
            }
        } else if (cb.getRequest() instanceof PasswordValidationCallback.DigestPasswordRequest) {
            log.log(Level.SEVERE, "WSS1502.unsupported.digestAuth");
            throw new UnsupportedCallbackException(null, "Digest Authentication for Passwords Not Supported");
        } else {
            log.log(Level.SEVERE, "WSS1503.unsupported.requesttype");
            throw new UnsupportedCallbackException(null, "Unsupported Request Type for Password Validation");
        }
    }

   private void handleTimestampValidation(TimestampValidationCallback cb) throws IOException, UnsupportedCallbackException {
        if (tsValidator != null) {
            cb.setValidator(tsValidator);
        } else {
            // this is for BC reasons, but will be enabled later
            cb.setValidator(defaultTSValidator);
        }
   }

   public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
        
        for (int i=0; i < callbacks.length; i++) {
            
          if (callbacks[i] instanceof UsernameCallback) {
                UsernameCallback cb = (UsernameCallback)callbacks[i];
                handleUsernameCallback(cb);
 
            } else if (callbacks[i] instanceof PasswordCallback) {
                PasswordCallback cb = (PasswordCallback)callbacks[i];
                handlePasswordCallback(cb);

            } else if (callbacks[i] instanceof PasswordValidationCallback) {
                PasswordValidationCallback cb = (PasswordValidationCallback) callbacks[i];
                handlePasswordValidation(cb);
                
            } else if (callbacks[i] instanceof TimestampValidationCallback) {
                TimestampValidationCallback cb = (TimestampValidationCallback) callbacks[i];
                handleTimestampValidation(cb);
                                                                             
            } else if (callbacks[i] instanceof SignatureVerificationKeyCallback) {

                SignatureVerificationKeyCallback cb = (SignatureVerificationKeyCallback)callbacks[i];
                
                if (cb.getRequest() instanceof SignatureVerificationKeyCallback.X509SubjectKeyIdentifierBasedRequest) {
                    // subject keyid request
                    SignatureVerificationKeyCallback.X509SubjectKeyIdentifierBasedRequest request =
                    (SignatureVerificationKeyCallback.X509SubjectKeyIdentifierBasedRequest) cb.getRequest();
                    X509Certificate cert =
                    getCertificateFromTrustStore(
                    request.getSubjectKeyIdentifier());
                    request.setX509Certificate(cert);
                    
                } else if (cb.getRequest() instanceof SignatureVerificationKeyCallback.X509IssuerSerialBasedRequest) {
                    // issuer serial request
                    SignatureVerificationKeyCallback.X509IssuerSerialBasedRequest request =
                    (SignatureVerificationKeyCallback.X509IssuerSerialBasedRequest) cb.getRequest();
                    X509Certificate cert =
                    getCertificateFromTrustStore(
                    request.getIssuerName(),
                    request.getSerialNumber());
                    request.setX509Certificate(cert);
                    
                } else if (cb.getRequest() instanceof SignatureVerificationKeyCallback.ThumbprintBasedRequest) {
                    SignatureVerificationKeyCallback.ThumbprintBasedRequest request =
                    (SignatureVerificationKeyCallback.ThumbprintBasedRequest) cb.getRequest();
                    X509Certificate cert =
                    getCertificateFromTrustStoreForThumbprint(
                    request.getThumbprintIdentifier());
                    request.setX509Certificate(cert);

                } else  {
                    log.log(Level.SEVERE, "WSS1504.unsupported.callbackType");
                    throw unsupported;
                }
                
            } else if (callbacks[i] instanceof SignatureKeyCallback) {
                SignatureKeyCallback cb = (SignatureKeyCallback)callbacks[i];
                
                if (cb.getRequest() instanceof SignatureKeyCallback.DefaultPrivKeyCertRequest) {
                    // default priv key cert req
                    SignatureKeyCallback.DefaultPrivKeyCertRequest request =
                    (SignatureKeyCallback.DefaultPrivKeyCertRequest) cb.getRequest();
                    getDefaultPrivKeyCert(request);
                    
                } else if (cb.getRequest() instanceof SignatureKeyCallback.AliasPrivKeyCertRequest) {
                    SignatureKeyCallback.AliasPrivKeyCertRequest request =
                    (SignatureKeyCallback.AliasPrivKeyCertRequest) cb.getRequest();
                    String alias = request.getAlias();
                    try {
                        X509Certificate cert =
                        (X509Certificate) keyStore.getCertificate(alias);
                        request.setX509Certificate(cert);
                        // Assuming key passwords same as the keystore password
                        PrivateKey privKey =
                        (PrivateKey) keyStore.getKey(alias, this.keyPassword);
                        request.setPrivateKey(privKey);
                    } catch (Exception e) {
                        log.log(Level.SEVERE, "WSS1505.failedto.getkey", e);
                        throw new IOException(e.getMessage());
                    }
                    
                } else {
                    log.log(Level.SEVERE, "WSS1504.unsupported.callbackType");
                    throw unsupported;
                }
                
            } else if (callbacks[i] instanceof DecryptionKeyCallback) {
                DecryptionKeyCallback cb = (DecryptionKeyCallback)callbacks[i];
                
                if (cb.getRequest() instanceof  DecryptionKeyCallback.X509SubjectKeyIdentifierBasedRequest) {
                    DecryptionKeyCallback.X509SubjectKeyIdentifierBasedRequest request =
                    (DecryptionKeyCallback.X509SubjectKeyIdentifierBasedRequest) cb.getRequest();
                    byte[] ski = request.getSubjectKeyIdentifier();
                    PrivateKey privKey = getPrivateKey(ski);
                    request.setPrivateKey(privKey);
                    
                } else if (cb.getRequest() instanceof DecryptionKeyCallback.X509IssuerSerialBasedRequest) {
                    DecryptionKeyCallback.X509IssuerSerialBasedRequest request =
                    (DecryptionKeyCallback.X509IssuerSerialBasedRequest) cb.getRequest();
                    String issuerName = request.getIssuerName();
                    BigInteger serialNumber = request.getSerialNumber();
                    PrivateKey privKey = getPrivateKey(issuerName, serialNumber);
                    request.setPrivateKey(privKey);
                    
                } else if (cb.getRequest() instanceof DecryptionKeyCallback.X509CertificateBasedRequest) {
                    DecryptionKeyCallback.X509CertificateBasedRequest request =
                    (DecryptionKeyCallback.X509CertificateBasedRequest) cb.getRequest();
                    X509Certificate cert = request.getX509Certificate();
                    PrivateKey privKey = getPrivateKey(cert);
                    request.setPrivateKey(privKey);
                    
                } else if (cb.getRequest() instanceof  DecryptionKeyCallback.ThumbprintBasedRequest) {
                    DecryptionKeyCallback.ThumbprintBasedRequest request =
                    (DecryptionKeyCallback.ThumbprintBasedRequest) cb.getRequest();
                    byte[] ski = request.getThumbprintIdentifier();
                    PrivateKey privKey = getPrivateKeyForThumbprint(ski);
                    request.setPrivateKey(privKey);
                } else if (cb.getRequest() instanceof  DecryptionKeyCallback.PublicKeyBasedPrivKeyRequest) {
                    DecryptionKeyCallback.PublicKeyBasedPrivKeyRequest request =
                    (DecryptionKeyCallback.PublicKeyBasedPrivKeyRequest) cb.getRequest();
                                        
                    PrivateKey privKey = getPrivateKeyFromKeyStore(request.getPublicKey());
                    request.setPrivateKey(privKey);
                }else  {
                    log.log(Level.SEVERE, "WSS1504.unsupported.callbackType");
                    throw unsupported;
                }
                
            } else if (callbacks[i] instanceof EncryptionKeyCallback) {
                EncryptionKeyCallback cb = (EncryptionKeyCallback)callbacks[i];
                
                if (cb.getRequest() instanceof EncryptionKeyCallback.AliasX509CertificateRequest) {
                    EncryptionKeyCallback.AliasX509CertificateRequest request =
                    (EncryptionKeyCallback.AliasX509CertificateRequest) cb.getRequest();
                    
                    //maintain this for Backward Compat of Old Configs for sometime
                    
//                    Map runtimeProperties = cb.getRuntimeProperties();
//                    if(isTrustMessage(runtimeProperties)){
//                        getSTSCertificateFromTrustStore(request);
//                        if (request.getX509Certificate() != null){
//                            return;
//                        }
//                    }

                    String alias = request.getAlias();
                    if ("".equals(alias) || (alias == null)) {
                        getDefaultCertificateFromTrustStore(cb.getRuntimeProperties(), request);
                    } else {
                        try {
                            X509Certificate cert =
                            (X509Certificate) trustStore.getCertificate(alias);
                            request.setX509Certificate(cert);
                        } catch (Exception e) {
                            log.log(Level.SEVERE, "WSS1526.failedto.getcertificate", e);
                            throw new IOException(e.getMessage());
                        }
                    }
                    
                }else if (cb.getRequest() instanceof EncryptionKeyCallback.PublicKeyBasedRequest) {
                    EncryptionKeyCallback.PublicKeyBasedRequest request =
                    (EncryptionKeyCallback.PublicKeyBasedRequest) cb.getRequest();
                    try {
                        X509Certificate cert = 
                                getCertificateFromTrustStoreForSAML(request.getPublicKey());                        
                        request.setX509Certificate(cert);
                    }catch(Exception e) {
                        log.log(Level.SEVERE, "WSS1526.failedto.getcertificate", e);
                        throw new IOException(e.getMessage());
                    }                    
                } else if (cb.getRequest() instanceof EncryptionKeyCallback.AliasSymmetricKeyRequest) {
                    log.log(Level.SEVERE, "WSS1504.unsupported.callbackType");
                    throw unsupported;
                }
                
            } else if (callbacks[i] instanceof CertificateValidationCallback) {
                CertificateValidationCallback cb = (CertificateValidationCallback)callbacks[i];
                if (certValidator != null) {
                    cb.setValidator(certValidator);
                } else {
                    cb.setValidator(defaultCertValidator);
                }
            } else  if (callbacks[i] instanceof DynamicPolicyCallback) {
               DynamicPolicyCallback dp = (DynamicPolicyCallback)callbacks[i];
               SecurityPolicy policy = dp.getSecurityPolicy();
               if (policy instanceof AuthenticationTokenPolicy.SAMLAssertionBinding) {
                   AuthenticationTokenPolicy.SAMLAssertionBinding samlBinding =
                   (AuthenticationTokenPolicy.SAMLAssertionBinding)
                   ((AuthenticationTokenPolicy.SAMLAssertionBinding)policy).clone();

                   if ((samlBinding.getAssertion() == null) && (samlBinding.getAuthorityBinding() == null)) {
                       populateAssertion(samlBinding, dp);
                   } else if (samlBinding.getAssertion() != null) {
                       validateSAMLAssertion(samlBinding);
                   } else if ((samlBinding.getAuthorityBinding() != null) && (samlBinding.getAssertionId() != null)) {                       
                       locateSAMLAssertion(samlBinding);
                   } else {
                       log.log(Level.SEVERE, "WSS1506.invalid.SAMLPolicy");
                       throw new UnsupportedCallbackException(null, "SAML Assertion not present in the Policy");
                   }
               }
            } else {
                log.log(Level.SEVERE, "WSS1504.unsupported.callbackType");
                throw unsupported;
            }
        }
    }

    private void populateAssertion(AuthenticationTokenPolicy.SAMLAssertionBinding samlBinding, DynamicPolicyCallback dp) 
         throws IOException, UnsupportedCallbackException {
        
        if (samlBinding.getAssertionType() == AuthenticationTokenPolicy.SAMLAssertionBinding.SV_ASSERTION) {
            
            if (samlHandler != null) {
                
                SAMLCallback sc = new SAMLCallback();
                sc.setConfirmationMethod(sc.SV_ASSERTION_TYPE);
                sc.setSAMLVersion(samlBinding.getSAMLVersion());
                Callback[] cbs = new Callback[] {sc};
                samlHandler.handle(cbs);
                samlBinding.setAssertion(sc.getAssertionElement());
                samlBinding.setAuthorityBinding(sc.getAuthorityBindingElement());
                dp.setSecurityPolicy(samlBinding);
                
            }else {
                log.log(Level.SEVERE, "WSS1507.no.SAMLCallbackHandler");
                throw new UnsupportedCallbackException(null, "A Required SAML Callback Handler was not specified in configuration : Cannot Populate SAML Assertion");
            }
            
        } else {

            if (samlHandler != null) {
                
                SAMLCallback sc = new SAMLCallback();
                sc.setConfirmationMethod(sc.HOK_ASSERTION_TYPE);
                sc.setSAMLVersion(samlBinding.getSAMLVersion());
                Callback[] cbs = new Callback[] {sc};
                samlHandler.handle(cbs);
                samlBinding.setAssertion(sc.getAssertionElement());
                samlBinding.setAuthorityBinding(sc.getAuthorityBindingElement());
                dp.setSecurityPolicy(samlBinding);
                PrivateKeyBinding pkBinding = (PrivateKeyBinding) samlBinding.newPrivateKeyBinding();
                
                SignatureKeyCallback.DefaultPrivKeyCertRequest request =
                        new SignatureKeyCallback.DefaultPrivKeyCertRequest();
                getDefaultPrivKeyCert(request);
                pkBinding.setPrivateKey(request.getPrivateKey());
                
            } else {
                log.log(Level.SEVERE, "WSS1507.no.SAMLCallbackHandler");
                throw new UnsupportedCallbackException(null, "A Required SAML Callback Handler was not specified in configuration : Cannot Populate SAML Assertion");
            } 
        }
    }

    private void validateSAMLAssertion(AuthenticationTokenPolicy.SAMLAssertionBinding samlBinding) 
         throws IOException, UnsupportedCallbackException {
        if (sValidator != null) {
            try {
                sValidator.validate(samlBinding.getAssertion());
            } catch (SAMLAssertionValidator.SAMLValidationException e) {
                log.log(Level.SEVERE, "WSS1508.failed.validateSAMLAssertion", e);
                throw new RuntimeException(e);
            }
        }
    }

    private void locateSAMLAssertion(AuthenticationTokenPolicy.SAMLAssertionBinding samlBinding) 
         throws IOException, UnsupportedCallbackException {
         
         Element binding = samlBinding.getAuthorityBinding();
         String assertionId = samlBinding.getAssertionId();
        // use the above information to locate the assertion
        // this simple impl will just set the assertion
        if (samlBinding.getAssertionType() == AuthenticationTokenPolicy.SAMLAssertionBinding.SV_ASSERTION) {
             if (samlHandler != null) {    
                SAMLCallback sc = new SAMLCallback();
                sc.setConfirmationMethod(sc.SV_ASSERTION_TYPE);
                sc.setSAMLVersion(samlBinding.getSAMLVersion());
                sc.setAssertionId(assertionId);
                sc.setAuthorityBindingElement(binding);
                Callback[] cbs = new Callback[] {sc};
                samlHandler.handle(cbs);
                samlBinding.setAssertion(sc.getAssertionElement());
             } else {
               log.log(Level.SEVERE, "WSS1507.no.SAMLCallbackHandler");
               throw new UnsupportedCallbackException(null, "A Required SAML Callback Handler was not specified in configuration : Cannot Populate SAML Assertion");  
             }
             
        } else {
            
             if (samlHandler != null) {   
                 SAMLCallback sc = new SAMLCallback();
                 sc.setConfirmationMethod(sc.HOK_ASSERTION_TYPE);
                 sc.setSAMLVersion(samlBinding.getSAMLVersion());
                 sc.setAssertionId(assertionId);
                 sc.setAuthorityBindingElement(binding);
                 Callback[] cbs = new Callback[] {sc};
                 samlHandler.handle(cbs);
                 samlBinding.setAssertion(sc.getAssertionElement());
                 PrivateKeyBinding pkBinding = (PrivateKeyBinding)samlBinding.newPrivateKeyBinding();
                 
                 SignatureKeyCallback.DefaultPrivKeyCertRequest request =
                         new SignatureKeyCallback.DefaultPrivKeyCertRequest();
                 getDefaultPrivKeyCert(request);
                 pkBinding.setPrivateKey(request.getPrivateKey());
                
            } else {
                log.log(Level.SEVERE, "WSS1507.no.SAMLCallbackHandler");
                throw new UnsupportedCallbackException(null, "A Required SAML Callback Handler was not specified in configuration : Cannot Populate SAML Assertion");
            }    
        }
    }

    private void initTrustStore() throws IOException {
        try {
            
            if (trustStoreURL == null) {
                if (log.isLoggable(Level.FINE)) {
                    log.log(Level.FINE,"Got NULL for TrustStore URL");
                }
                return;
            }
            if (this.trustStorePassword == null) {
                if (log.isLoggable(Level.FINE)) {
                    log.log(Level.FINE,"Got NULL for TrustStore Password");
                }
            }
            
            char[]  trustStorePasswordChars = null;
            //check here if trustStorePassword is a CBH className
            Class cbh = this.loadClassSilent(trustStorePassword);
            if (cbh != null) {
                CallbackHandler hdlr = (CallbackHandler)cbh.newInstance();
                 javax.security.auth.callback.PasswordCallback pc = 
                         new javax.security.auth.callback.PasswordCallback("TrustStorePassword", false); 
                 Callback[] cbs = new Callback[] {pc};
                 hdlr.handle(cbs); 
                 trustStorePasswordChars = (
                         (javax.security.auth.callback.PasswordCallback)cbs[0]).getPassword();
            } else {
                //the user supplied value is a Password for the truststore
                trustStorePasswordChars = trustStorePassword.toCharArray();
            }
                
            trustStore = KeyStore.getInstance(trustStoreType);
            trustStore.load(new FileInputStream(trustStoreURL), trustStorePasswordChars);
        } catch (Exception e) {
            log.log(Level.SEVERE, "WSS1509.failed.init.truststore", e);
            throw new IOException(e.getMessage());
        }
    }

    private void initKeyStore() throws IOException {
        try {
            if (keyStoreURL == null) {
                if (log.isLoggable(Level.FINE)) {
                    log.log(Level.FINE,"Got NULL for KeyStore URL");
                }
                return;
            }
            
            if (keyStorePassword == null) {
                if (log.isLoggable(Level.FINE)) {
                    log.log(Level.FINE,"Got NULL for KeyStore PASSWORD");
                }
                return;
            }
            
            char[]  keyStorePasswordChars = null;
            //check here if keyStorePassword is a CBH className
            Class cbh = this.loadClassSilent(keyStorePassword);
            if (cbh != null) {
                CallbackHandler hdlr = (CallbackHandler)cbh.newInstance();
                 javax.security.auth.callback.PasswordCallback pc = 
                         new javax.security.auth.callback.PasswordCallback("KeyStorePassword", false); 
                 Callback[] cbs = new Callback[] {pc};
                 hdlr.handle(cbs); 
                 keyStorePasswordChars = (
                         (javax.security.auth.callback.PasswordCallback)cbs[0]).getPassword();
            } else {
                //the user supplied value is a Password for the keystore
                keyStorePasswordChars = keyStorePassword.toCharArray();
            }
            
            //now initialize KeyPassword if any ?
            if (this.keyPwd == null) {
                this.keyPassword = keyStorePasswordChars;
            } else {
                initKeyPassword();
            }
            
            keyStore = KeyStore.getInstance(keyStoreType);
            keyStore.load(new FileInputStream(keyStoreURL), keyStorePasswordChars);
        } catch (Exception e) {
            log.log(Level.SEVERE, "WSS1510.failed.init.keystore", e);
            throw new IOException(e.getMessage());
        }
    }


    private X509Certificate getCertificateFromTrustStore(byte[] ski)
        throws IOException {

        try {
            if (trustStore == null) return null;
            Enumeration aliases = trustStore.aliases();
            while (aliases.hasMoreElements()) {
                String alias = (String) aliases.nextElement();
                Certificate cert = trustStore.getCertificate(alias);
                if (cert == null || !"X.509".equals(cert.getType())) {
                    continue;
                }
                X509Certificate x509Cert = (X509Certificate) cert;
                byte[] keyId = getSubjectKeyIdentifier(x509Cert);
                if (keyId == null) {
                    // Cert does not contain a key identifier
                    continue;
                }
                if (Arrays.equals(ski, keyId)) {
                    return x509Cert;
                }
            }
        } catch (Exception e) {
            log.log(Level.SEVERE, "WSS1526.failedto.getcertificate", e);
            throw new IOException(e.getMessage());
        }
        return null;
    }

    private X509Certificate getCertificateFromTrustStore(
        String issuerName,
        BigInteger serialNumber)
        throws IOException {

        try {
            if (trustStore == null) return null;
            Enumeration aliases = trustStore.aliases();
            while (aliases.hasMoreElements()) {
                String alias = (String) aliases.nextElement();
                Certificate cert = trustStore.getCertificate(alias);
                if (cert == null || !"X.509".equals(cert.getType())) {
                    continue;
                }
                X509Certificate x509Cert = (X509Certificate) cert;
                String thisIssuerName =
                    RFC2253Parser.normalize(x509Cert.getIssuerDN().getName());
                BigInteger thisSerialNumber = x509Cert.getSerialNumber();
                if (thisIssuerName.equals(issuerName) &&
                    thisSerialNumber.equals(serialNumber)) {
                    return x509Cert;
                }
            }
        } catch (Exception e) {
            log.log(Level.SEVERE, "WSS1526.failedto.getcertificate", e);
            throw new IOException(e.getMessage());
        }
        return null;
    }

    public PrivateKey getPrivateKey(byte[] ski) throws IOException {

        try {
            if (keyStore == null) return null;
            Enumeration aliases = keyStore.aliases();
            while (aliases.hasMoreElements()) {
                String alias = (String) aliases.nextElement();
                if (!keyStore.isKeyEntry(alias))
                    continue;
                Certificate cert = keyStore.getCertificate(alias);
                if (cert == null || !"X.509".equals(cert.getType())) {
                    continue;
                }
                X509Certificate x509Cert = (X509Certificate) cert;
                byte[] keyId = getSubjectKeyIdentifier(x509Cert);
                if (keyId == null) {
                    // Cert does not contain a key identifier
                    continue;
                }
                if (Arrays.equals(ski, keyId)) {
                    // Asuumed key password same as the keystore password
                    return (PrivateKey) keyStore.getKey(alias, this.keyPassword);
                }
            }
        } catch (Exception e) {
            log.log(Level.SEVERE, "WSS1505.failedto.getkey", e);
            throw new IOException(e.getMessage());
        }
        return null;
    }

    public PrivateKey getPrivateKey(
        String issuerName,
        BigInteger serialNumber)
        throws IOException {

        try {
            if (keyStore == null) return null;
            Enumeration aliases = keyStore.aliases();
            while (aliases.hasMoreElements()) {
                String alias = (String) aliases.nextElement();
                if (!keyStore.isKeyEntry(alias))
                    continue;
                Certificate cert = keyStore.getCertificate(alias);
                if (cert == null || !"X.509".equals(cert.getType())) {
                    continue;
                }
                X509Certificate x509Cert = (X509Certificate) cert;
                String thisIssuerName =
                    RFC2253Parser.normalize(x509Cert.getIssuerDN().getName());
                BigInteger thisSerialNumber = x509Cert.getSerialNumber();
                if (thisIssuerName.equals(issuerName) &&
                    thisSerialNumber.equals(serialNumber)) {
                    return (PrivateKey) keyStore.getKey(alias, this.keyPassword);
                }
            }
        } catch (Exception e) {
            log.log(Level.SEVERE, "WSS1505.failedto.getkey", e);
            throw new IOException(e.getMessage());
        }
        return null;
    }

    public PrivateKey getPrivateKey(X509Certificate certificate)
        throws IOException {

        try {
            if (keyStore == null) return null;
            Enumeration aliases = keyStore.aliases();
            while (aliases.hasMoreElements()) {
                String alias = (String) aliases.nextElement();
                if (!keyStore.isKeyEntry(alias))
                    continue;
                Certificate cert = keyStore.getCertificate(alias);
                if (cert != null && cert.equals(certificate))
                    return (PrivateKey) keyStore.getKey(alias, this.keyPassword);
            }
        } catch (Exception e) {
            log.log(Level.SEVERE, "WSS1505.failedto.getkey", e);
            throw new IOException(e.getMessage());
        }
        return null;
    }


    private void getDefaultCertificateFromTrustStore(Map context,
        EncryptionKeyCallback.AliasX509CertificateRequest req) throws IOException {
           
            try {
                if (trustStore == null) return;
                String currentAlias = null;
                if (peerEntityAlias != null) {
                    currentAlias = peerEntityAlias;
                } else {
                
                    X509Certificate cert = 
                            getDynamicCertificate(context, trustStore);
                    if (cert != null) {
                        req.setX509Certificate(cert);
                        return;
                    }
                    //TODO: remove this code below, this code is not correct anyway
                    Enumeration aliases = trustStore.aliases();
	            while (aliases.hasMoreElements()) {
                        currentAlias = (String) aliases.nextElement();
                        if (!"certificate-authority".equals(currentAlias) && !"root".equals(currentAlias)) {
                            break;
                        } else {
                            currentAlias = null;
                        }
                    }
                }
                if (currentAlias != null) {
                    //System.out.println("Encryption Key Alias=" + currentAlias);
                     X509Certificate thisCertificate = (X509Certificate)
                            trustStore.getCertificate(currentAlias);
                     req.setX509Certificate(thisCertificate);
                     return;
                } else {
                    log.log(Level.SEVERE, "WSS1511.failed.locate.peerCertificate");
                    throw new RuntimeException("An Error occurred while locating PEER Entity certificate in TrustStore");
                }
            } catch (Exception e) {
                log.log(Level.SEVERE, "WSS1526.failedto.getcertificate", e);
                throw new RuntimeException(e);
            }
    }    

    private void getDefaultPrivKeyCert(
        SignatureKeyCallback.DefaultPrivKeyCertRequest request)
        throws IOException {

        if (keyStore == null) return;
        String uniqueAlias = null;
        try {
            if (myAlias != null) {
                uniqueAlias = myAlias;
            } else {
                Enumeration aliases = keyStore.aliases();
                while (aliases.hasMoreElements()) {
                    String currentAlias = (String) aliases.nextElement();
                    if (keyStore.isKeyEntry(currentAlias)) {
                        Certificate thisCertificate = keyStore.getCertificate(currentAlias);
                        if (thisCertificate != null) {
                            if (thisCertificate instanceof X509Certificate) {
                                if (uniqueAlias == null) {
                                    uniqueAlias = currentAlias;
                                } else {
                                    // Not unique!
                                    uniqueAlias = null;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            if (uniqueAlias != null) {
                //System.out.println("Signing Key Alias=" + uniqueAlias);
                request.setX509Certificate(
                    (X509Certificate) keyStore.getCertificate(uniqueAlias));
                request.setPrivateKey(
                    (PrivateKey) keyStore.getKey(uniqueAlias, this.keyPassword));
            } else {
                log.log(Level.SEVERE, "WSS1512.failed.locate.certificate.privatekey");
                throw new RuntimeException("An Error occurred while locating default certificate and privateKey in KeyStore");
            }
        } catch (Exception e) {
            log.log(Level.SEVERE, "WSS1505.failedto.getkey", e);
            throw new IOException(e.getMessage());
        }
    }

    private static byte[] getSubjectKeyIdentifier(X509Certificate cert) {
        String SUBJECT_KEY_IDENTIFIER_OID = "2.5.29.14";
        byte[] subjectKeyIdentifier =
            cert.getExtensionValue(SUBJECT_KEY_IDENTIFIER_OID);
        if (subjectKeyIdentifier == null)
            return null;
         
        try {
            sun.security.x509.KeyIdentifier keyId = null; 
         
            sun.security.util.DerValue derVal = new sun.security.util.DerValue(
                 new sun.security.util.DerInputStream(subjectKeyIdentifier).getOctetString());
         
            keyId = new sun.security.x509.KeyIdentifier(derVal.getOctetString());
            return keyId.getIdentifier();
        } catch (NoClassDefFoundError ncde) {
            
            byte[] dest = new byte[subjectKeyIdentifier.length - 4];
            System.arraycopy(
                subjectKeyIdentifier, 4, dest, 0, subjectKeyIdentifier.length - 4);
            return dest;
        } catch ( java.io.IOException ex) {
            //ignore
            return null;
        }
    }


    private class DefaultTimestampValidator implements TimestampValidationCallback.TimestampValidator {

        public void validate(TimestampValidationCallback.Request request)
            throws TimestampValidationCallback.TimestampValidationException {


            // validate timestamp creation and expiration time.
            TimestampValidationCallback.UTCTimestampRequest utcTimestampRequest =
                (TimestampValidationCallback.UTCTimestampRequest) request;


            SimpleDateFormat calendarFormatter1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
            SimpleDateFormat calendarFormatter2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'.'SSS'Z'");
            Date created = null;
            Date expired = null;
 
            
                try {
                    created = calendarFormatter1.parse(utcTimestampRequest.getCreated());
                    if ( utcTimestampRequest.getExpired() != null ) 
                        expired = calendarFormatter1.parse(utcTimestampRequest.getExpired());
                } catch (java.text.ParseException pe) {
                    try{
                        created = calendarFormatter2.parse(utcTimestampRequest.getCreated());
                        if ( utcTimestampRequest.getExpired() != null ) 
                            expired = calendarFormatter2.parse(utcTimestampRequest.getExpired());
                        } 
                    catch ( java.text.ParseException ipe ) {
                        log.log(Level.SEVERE, "WSS1513.exception.validate.timestamp");
                        throw new TimestampValidationCallback.TimestampValidationException(ipe.getMessage());
                    }
                } 

            long maxClockSkewLocal = utcTimestampRequest.getMaxClockSkew();
            if (maxClockSkewG > 0) {
                maxClockSkewLocal = maxClockSkewG;
            }
            long tsfLocal = utcTimestampRequest.getTimestampFreshnessLimit();
            if (timestampFreshnessLimitG > 0) {
                tsfLocal = timestampFreshnessLimitG;
            }

            // validate creation time
            validateCreationTime(created, maxClockSkewLocal, tsfLocal);
             
            // validate expiration time
            if ( expired != null )
                validateExpirationTime(expired, maxClockSkewLocal, tsfLocal);
        }
    }

    public void validateExpirationTime(
        Date expires, long maxClockSkew, long timestampFreshnessLimit)
        throws TimestampValidationCallback.TimestampValidationException {
                
        //System.out.println("Validate Expiration time called");
        Date currentTime =
            getGMTDateWithSkewAdjusted(new GregorianCalendar(), maxClockSkew, false);
        if (expires.before(currentTime)) {
            log.log(Level.SEVERE, "WSS1514.error.aheadCurrentTime");
            throw new TimestampValidationCallback.TimestampValidationException(
                "The current time is ahead of the expiration time in Timestamp");
        }
    }

    public void validateCreationTime(
        Date created,
        long maxClockSkew,
        long timestampFreshnessLimit)
        throws TimestampValidationCallback.TimestampValidationException {

        //System.out.println("Validate Creation time called");
        Date current = getFreshnessAndSkewAdjustedDate(maxClockSkew, timestampFreshnessLimit);
            
        if (created.before(current)) {
            log.log(Level.SEVERE, "WSS1515.error.currentTime");
            throw new TimestampValidationCallback.TimestampValidationException(
                "The creation time is older than " +
                " currenttime - timestamp-freshness-limit - max-clock-skew");
        }
            
        Date currentTime =
            getGMTDateWithSkewAdjusted(new GregorianCalendar(), maxClockSkew, true);
        if (currentTime.before(created)) {
            log.log(Level.SEVERE, "WSS1516.error.creationAheadCurrent.time");
            throw new TimestampValidationCallback.TimestampValidationException(
                "The creation time is ahead of the current time.");
        }
    }

    private static Date getFreshnessAndSkewAdjustedDate(
    long maxClockSkew, long timestampFreshnessLimit) {
        Calendar c = new GregorianCalendar();
        long offset = c.get(Calendar.ZONE_OFFSET);
        if (c.getTimeZone().inDaylightTime(c.getTime())) {
            offset += c.getTimeZone().getDSTSavings();
        }
        long beforeTime = c.getTimeInMillis();
        long currentTime = beforeTime - offset;
        
        long adjustedTime = currentTime - maxClockSkew - timestampFreshnessLimit;
        c.setTimeInMillis(adjustedTime);
        
        return c.getTime();
    }


    private static Date getGMTDateWithSkewAdjusted(
    Calendar c, long maxClockSkew, boolean addSkew) {
        long offset = c.get(Calendar.ZONE_OFFSET);
        if (c.getTimeZone().inDaylightTime(c.getTime())) {
            offset += c.getTimeZone().getDSTSavings();
        }
        long beforeTime = c.getTimeInMillis();
        long currentTime = beforeTime - offset;
        
        if (addSkew)
            currentTime = currentTime + maxClockSkew;
        else
            currentTime = currentTime - maxClockSkew;
        
        c.setTimeInMillis(currentTime);
        return c.getTime();
    }
    
    private class X509CertificateValidatorImpl implements CertificateValidationCallback.CertificateValidator {

        public boolean validate(X509Certificate certificate)
            throws CertificateValidationCallback.CertificateValidationException {

            if (isSelfCert(certificate)) {
                return true;
            }
                                                                                
            try {
                certificate.checkValidity();
            } catch (CertificateExpiredException e) {                
                log.log(Level.SEVERE, "WSS1517.X509.expired", e);
                throw new CertificateValidationCallback.CertificateValidationException("X509Certificate Expired", e);
            } catch (CertificateNotYetValidException e) {                
                log.log(Level.SEVERE, "WSS1527.X509.notValid", e);
                throw new CertificateValidationCallback.CertificateValidationException("X509Certificate's Validity Failed", e);
            }
                                                                                
            X509CertSelector certSelector = new X509CertSelector();
            certSelector.setCertificate(certificate);
                                                                                
            PKIXBuilderParameters parameters;
            CertPathBuilder builder;
            try {
                parameters = new PKIXBuilderParameters(trustStore, certSelector);
                parameters.setRevocationEnabled(false);
                builder = CertPathBuilder.getInstance("PKIX");
            } catch (Exception e) {                
                log.log(Level.SEVERE, "WSS1518.failedto.validate.certificate", e);
                throw new CertificateValidationCallback.CertificateValidationException(e.getMessage(), e);
            }
                                                                                
            try {
                PKIXCertPathBuilderResult result =
                    (PKIXCertPathBuilderResult) builder.build(parameters);
            } catch (Exception e) {                
                return false;
            }
            return true;
        }

        private boolean isSelfCert(X509Certificate cert)
            throws CertificateValidationCallback.CertificateValidationException {
            try {
                Enumeration aliases = keyStore.aliases();
                while (aliases.hasMoreElements()) {
                    String alias = (String) aliases.nextElement();
                    if (keyStore.isKeyEntry(alias)) {
                        X509Certificate x509Cert =
                            (X509Certificate) keyStore.getCertificate(alias);
                        if (x509Cert != null) {
                            if (x509Cert.equals(cert))
                                return true;
                        }
                    }
                }
                return false;
            } catch (Exception e) {                
                log.log(Level.SEVERE, "WSS1518.failedto.validate.certificate", e);
                throw new CertificateValidationCallback.CertificateValidationException(e.getMessage(), e);
            }
        }
    }

   
     private X509Certificate getCertificateFromTrustStoreForThumbprint(byte[] ski) throws IOException {
                                                                                                                                         
        try {
            if (trustStore == null) return null;
            Enumeration aliases = trustStore.aliases();
            while (aliases.hasMoreElements()) {
                String alias = (String) aliases.nextElement();
                Certificate cert = trustStore.getCertificate(alias);
                if (cert == null || !"X.509".equals(cert.getType())) {
                    continue;
                }
                X509Certificate x509Cert = (X509Certificate) cert;
                byte[] keyId = getThumbprintIdentifier(x509Cert);
                if (keyId == null) {
                    // Cert does not contain a key identifier
                    continue;
                }
                if (Arrays.equals(ski, keyId)) {
                    return x509Cert;
                }
            }
        } catch (Exception e) {
            log.log(Level.SEVERE, "WSS1526.failedto.getcertificate", e);
            throw new IOException(e.getMessage());
        }
        return null;
    }

     public static byte[] getThumbprintIdentifier(X509Certificate cert)
       throws XWSSecurityException {
        byte[] thumbPrintIdentifier = null;
                                                                                                                      
        try {
            thumbPrintIdentifier = MessageDigest.getInstance("SHA-1").digest(cert.getEncoded());
        } catch ( NoSuchAlgorithmException ex ) {
            log.log(Level.SEVERE, "WSS1519.no.digest.algorithm");
            throw new XWSSecurityException("Digest algorithm SHA-1 not found");
        } catch ( CertificateEncodingException ex) {
            log.log(Level.SEVERE, "WSS1520.error.getting.rawContent");
            throw new XWSSecurityException("Error while getting certificate's raw content");
        }
        return thumbPrintIdentifier;
    }
   
    
    public PrivateKey getPrivateKeyForThumbprint(byte[] ski) throws IOException {
                                                                                                                                         
        try {
            if (keyStore == null) return null;
            Enumeration aliases = keyStore.aliases();
            while (aliases.hasMoreElements()) {
                String alias = (String) aliases.nextElement();
                if (!keyStore.isKeyEntry(alias))
                    continue;
                Certificate cert = keyStore.getCertificate(alias);
                if (cert == null || !"X.509".equals(cert.getType())) {
                    continue;
                }
                X509Certificate x509Cert = (X509Certificate) cert;
                byte[] keyId = getThumbprintIdentifier(x509Cert);
                if (keyId == null) {
                    // Cert does not contain a key identifier
                    continue;
                }
                if (Arrays.equals(ski, keyId)) {
                    // Asuumed key password same as the keystore password
                    return (PrivateKey) keyStore.getKey(alias, this.keyPassword);
                }
            }
        } catch (Exception e) {
            log.log(Level.SEVERE, "WSS1505.failedto.getkey", e);
            throw new IOException(e.getMessage());
        }
        return null;
    }

    //TODO: add RENEW/CANCEL etc out here
    protected boolean isTrustMessage(Map map){
        
        String s = (String)map.get("isTrustMessage");
        if (s != null) {
            return s.equals("true");
        }
        /*
        } else {
            AddressingProperties ap = (AddressingProperties)map.get("javax.xml.ws.addressing.context");
            if (ap != null) {
                AttributedURI uri = ap.getAction();
                if (uri != null && ISSUE_REQUEST_URI.equals(ap.getAction().getURI())) {
                    return true;
                }
            }
        }*/
        return false;
    }

    private Class loadClassSilent(String classname)  {
        if (classname == null) {
            return null;
        }
        Class ret = null;
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        if (loader != null) {
            try {
                ret = loader.loadClass(classname);
                return ret;
            } catch (ClassNotFoundException e) {
                // ignore
            }
        }
        // if context classloader didnt work, try this
        loader = this.getClass().getClassLoader();
        try {
            ret = loader.loadClass(classname);
            return ret;
        } catch (ClassNotFoundException e) {
                // ignore
        }
        return null;
    }
    
    private Class loadClass(String classname) throws XWSSecurityException {
        if (classname == null) {
            return null;
        }
        Class ret = null;
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        if (loader != null) {
            try {
                ret = loader.loadClass(classname);
                return ret;
            } catch (ClassNotFoundException e) {
                // ignore
            }
        }
        // if context classloader didnt work, try this
        loader = this.getClass().getClassLoader();
        try {
            ret = loader.loadClass(classname);
            return ret;
        } catch (ClassNotFoundException e) {
                // ignore
        }
        log.log(Level.SEVERE, "WSS1521.error.getting.userClass");
        throw new XWSSecurityException("Could not find User Class " + classname);
    }

    private long toLong(String lng) throws Exception {
        if (lng == null) {
            return 0;
        }
        Long ret = 0L;
        try {
            ret = Long.valueOf(lng);
        }catch (Exception e) {
            log.log(Level.SEVERE, "WSS1522.error.getting.longValue");
            throw new XWSSecurityException(e);
        }
        return ret; 
    }

    private void initNewInstances() throws XWSSecurityException {
     
        try {

            if (usernameCbHandler != null) {
                usernameHandler = (CallbackHandler)usernameCbHandler.newInstance();
            } else {
                 if (log.isLoggable(Level.FINE)) {
                    log.log(Level.FINE,"Got NULL for Username Callback Handler");
                }
            }
            if (passwordCbHandler != null) {
                passwordHandler = (CallbackHandler)passwordCbHandler.newInstance();
            } else {
                if (log.isLoggable(Level.FINE)) {
                    log.log(Level.FINE,"Got NULL for Password Callback Handler");
                }
            }
            
            if (samlCbHandler != null) {
                samlHandler = (CallbackHandler)samlCbHandler.newInstance();
            }

            if (usernameValidator != null) {
                pwValidator = (PasswordValidationCallback.PasswordValidator)usernameValidator.newInstance();
            }

            if (timestampValidator != null) {
                tsValidator = (TimestampValidationCallback.TimestampValidator)timestampValidator.newInstance();
            }

            if (samlValidator != null) {
                sValidator = (SAMLAssertionValidator)samlValidator.newInstance();
            }

            if (certificateValidator != null) {
                certValidator = (CertificateValidationCallback.CertificateValidator)certificateValidator.newInstance();
            }
        } catch (Exception e) {
            log.log(Level.SEVERE, "WSS1523.error.getting.newInstance.CallbackHandler" ,e);
            throw new XWSSecurityException(e);
        }
    }
    
    private X509Certificate getCertificateFromTrustStoreForSAML(PublicKey pk)
        throws IOException {
        try {
            Enumeration aliases = trustStore.aliases();
            while (aliases.hasMoreElements()) {
                String alias = (String) aliases.nextElement();
                Certificate cert = trustStore.getCertificate(alias);
                if (cert == null || !"X.509".equals(cert.getType())) {
                    continue;
                }
                X509Certificate x509Cert = (X509Certificate) cert;
                if (x509Cert.getPublicKey().equals(pk)) {
                    return x509Cert;
                }
            }
        } catch (Exception e) {
            log.log(Level.SEVERE, "WSS1526.failedto.getcertificate", e);
            throw new IOException(e.getMessage());
        }
        return null;
    }

    private PrivateKey getPrivateKeyFromKeyStore(PublicKey pk)
        throws IOException {
        try {
            Enumeration aliases = keyStore.aliases();
            while (aliases.hasMoreElements()) {
                String alias = (String) aliases.nextElement();
                if (!keyStore.isKeyEntry(alias)) {
                    continue;
                } else {
                // Just returning the first one here
                PrivateKey key =(PrivateKey)keyStore.getKey(alias, this.keyPassword);
                return key;
                }
            }
        } catch (Exception e) {
            log.log(Level.SEVERE, "WSS1505.failedto.getkey", e);
            throw new IOException(e.getMessage());
        }
        return null;
    }
    
   
   private String resolveHome(String url) {
       if (url == null) {
           return null;
       }
       if (url.startsWith("$WSIT_HOME")) {
           String wsitHome = System.getProperty("WSIT_HOME");
           if (wsitHome != null) {
               String ret= url.replace("$WSIT_HOME", wsitHome);
               return ret;
           } else {
               log.log(Level.SEVERE, "WSS1524.unableto.resolve.URI.WSIT_HOME.notset");
               throw new RuntimeException("The following config URL: " + url + " in the WSDL could not be resolved because System Property WSIT_HOME was not set");
           }
       } else {
           return url;
       }
   }

   private void initKeyPassword() {
       //NOTE: this is called only when this.keyPwd is non-null
       // check if this.keyPwd is a CBH
       try {
           Class cbh = this.loadClassSilent(this.keyPwd);
           if (cbh != null) {
               CallbackHandler hdlr = (CallbackHandler)cbh.newInstance();
               javax.security.auth.callback.PasswordCallback pc =
                       new javax.security.auth.callback.PasswordCallback("KeyPassword", false);
               Callback[] cbs = new Callback[] {pc};
               hdlr.handle(cbs);
               this.keyPassword = (
                       (javax.security.auth.callback.PasswordCallback)cbs[0]).getPassword();
           } else {
               //the user supplied value is a Password for the key alias
               this.keyPassword = this.keyPwd.toCharArray();
           }
       } catch (java.lang.InstantiationException ex) {
           log.log(Level.SEVERE, "WSS1528.failed.initialize.key.password", ex);
           throw new RuntimeException(ex);
       } catch (java.io.IOException e) {
           log.log(Level.SEVERE, "WSS1528.failed.initialize.key.password", e);
           throw new RuntimeException(e);
       } catch (java.lang.IllegalAccessException ie) {
           log.log(Level.SEVERE, "WSS1528.failed.initialize.key.password", ie);
           throw new RuntimeException(ie);
       } catch (javax.security.auth.callback.UnsupportedCallbackException ue) {
           log.log(Level.SEVERE, "WSS1528.failed.initialize.key.password", ue);
           throw new RuntimeException(ue);
       }
   }

   private X509Certificate getDynamicCertificate(Map context, KeyStore trustStore) {

        X509Certificate cert = null;

        Subject requesterSubject = getRequesterSubject(context);
        if (requesterSubject != null) {
            Set publicCredentials = requesterSubject.getPublicCredentials();
            for (Iterator it = publicCredentials.iterator(); it.hasNext();) {
                Object cred = it.next();
                if(cred instanceof java.security.cert.X509Certificate){
                    cert = (java.security.cert.X509Certificate)cred;
                }
            }
            if (cert != null) {
                return cert;
            }
        } 
        /*
        String keyId = (String)context.get(MessageConstants.REQUESTER_KEYID);
        String issuerName = (String)context.get(MessageConstants.REQUESTER_ISSUERNAME);
        BigInteger issuerSerial = (BigInteger)context.get(MessageConstants.REQUESTER_SERIAL);

        if (keyId != null) {
            try {
                cert = getMatchingCertificate(keyId.getBytes(), trustStore);
                if (cert != null) 
                    return cert;
            } catch (XWSSecurityException e) {}
        } else if ((issuerName != null) && (issuerSerial != null)) {
            try {
                cert = getMatchingCertificate(issuerSerial, issuerName, trustStore);
                if (cert != null) 
                    return cert;
            } catch (XWSSecurityException e) {}
        } */
        return null;
    }
    
   public Subject getRequesterSubject(final Map context) {
       //return (Subject)context.get(MessageConstants.AUTH_SUBJECT);
       Subject otherPartySubject = (Subject)context.get(MessageConstants.AUTH_SUBJECT);
       if (otherPartySubject != null) {
           return otherPartySubject;
       }
       otherPartySubject = (Subject) AccessController.doPrivileged(
               new PrivilegedAction() {
           public Object run() {
               Subject otherPartySubj = new Subject();
               context.put(MessageConstants.AUTH_SUBJECT,otherPartySubj);
               return otherPartySubj;
           }
       }
       );
       return otherPartySubject;
   }

}
