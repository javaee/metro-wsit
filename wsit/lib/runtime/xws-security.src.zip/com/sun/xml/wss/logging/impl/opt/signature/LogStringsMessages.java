
package com.sun.xml.wss.logging.impl.opt.signature;

import com.sun.xml.ws.util.localization.Localizable;
import com.sun.xml.ws.util.localization.LocalizableMessageFactory;
import com.sun.xml.ws.util.localization.Localizer;


/**
 * Defines string formatting method for each constant in the resource file
 * 
 */
public final class LogStringsMessages {

    private final static LocalizableMessageFactory messageFactory = new LocalizableMessageFactory("com.sun.xml.wss.logging.impl.opt.signature.LogStrings");
    private final static Localizer localizer = new Localizer();

    public static Localizable localizableWSS_1754_TRANSFORM_ALGORITHM(Object arg0) {
        return messageFactory.getMessage("WSS1754.transform.algorithm", arg0);
    }

    /**
     * WSS1754: Transform algorithm used is: {0}
     * 
     */
    public static String WSS_1754_TRANSFORM_ALGORITHM(Object arg0) {
        return localizer.localize(localizableWSS_1754_TRANSFORM_ALGORITHM(arg0));
    }

    public static Localizable localizableWSS_1703_UNSUPPORTED_KEYBINDING_SIGNATUREPOLICY(Object arg0) {
        return messageFactory.getMessage("WSS1703.unsupported.keybinding.signaturepolicy", arg0);
    }

    /**
     * WSS1703: Unsupported Key Binding for SignaturePolicy: {0}
     * 
     */
    public static String WSS_1703_UNSUPPORTED_KEYBINDING_SIGNATUREPOLICY(Object arg0) {
        return localizer.localize(localizableWSS_1703_UNSUPPORTED_KEYBINDING_SIGNATUREPOLICY(arg0));
    }

    public static Localizable localizableWSS_1710_SIGNATURE_VERFICATION_FAILED(Object arg0) {
        return messageFactory.getMessage("WSS1710.signature.verfication.failed", arg0);
    }

    /**
     * WSS1710: Signature Verification for Signature with ID {0} failed
     * 
     */
    public static String WSS_1710_SIGNATURE_VERFICATION_FAILED(Object arg0) {
        return localizer.localize(localizableWSS_1710_SIGNATURE_VERFICATION_FAILED(arg0));
    }

    public static Localizable localizableWSS_1705_INVALID_DIGEST_ALGORITHM(Object arg0) {
        return messageFactory.getMessage("WSS1705.invalid.digest.algorithm", arg0);
    }

    /**
     * WSS1705: Invalid digest algorithm {0} specified
     * 
     */
    public static String WSS_1705_INVALID_DIGEST_ALGORITHM(Object arg0) {
        return localizer.localize(localizableWSS_1705_INVALID_DIGEST_ALGORITHM(arg0));
    }

    public static Localizable localizableWSS_1750_URI_TOBE_DEREFERENCED(Object arg0) {
        return messageFactory.getMessage("WSS1750.uri.tobe.dereferenced", arg0);
    }

    /**
     * WSS1750: URI to be dereferenced:{0}
     * 
     */
    public static String WSS_1750_URI_TOBE_DEREFERENCED(Object arg0) {
        return localizer.localize(localizableWSS_1750_URI_TOBE_DEREFERENCED(arg0));
    }

    public static Localizable localizableWSS_1757_CANONICALIZED_TARGET_VALUE(Object arg0) {
        return messageFactory.getMessage("WSS1757.canonicalized.target.value", arg0);
    }

    /**
     * WSS1757: Canonicalized target value: {0}
     * 
     */
    public static String WSS_1757_CANONICALIZED_TARGET_VALUE(Object arg0) {
        return localizer.localize(localizableWSS_1757_CANONICALIZED_TARGET_VALUE(arg0));
    }

    public static Localizable localizableWSS_1715_ERROR_CANONICALIZING_BODY() {
        return messageFactory.getMessage("WSS1715.error.canonicalizing.body");
    }

    /**
     * WSS1715: Error occurred while canonicalizing BodyTag
     * 
     */
    public static String WSS_1715_ERROR_CANONICALIZING_BODY() {
        return localizer.localize(localizableWSS_1715_ERROR_CANONICALIZING_BODY());
    }

    public static Localizable localizableWSS_1714_UNSUPPORTED_TRANSFORM_ERROR() {
        return messageFactory.getMessage("WSS1714.unsupported.transform.error");
    }

    /**
     * WSS1714: Only EXC14n Transform is supported
     * 
     */
    public static String WSS_1714_UNSUPPORTED_TRANSFORM_ERROR() {
        return localizer.localize(localizableWSS_1714_UNSUPPORTED_TRANSFORM_ERROR());
    }

    public static Localizable localizableWSS_1702_UNSUPPORTED_USERNAMETOKEN_KEYBINDING() {
        return messageFactory.getMessage("WSS1702.unsupported.usernametoken.keybinding");
    }

    /**
     * WSS1702: UsernameToken as KeyBinding for SignaturePolicy is Not Yet Supported
     * 
     */
    public static String WSS_1702_UNSUPPORTED_USERNAMETOKEN_KEYBINDING() {
        return localizer.localize(localizableWSS_1702_UNSUPPORTED_USERNAMETOKEN_KEYBINDING());
    }

    public static Localizable localizableWSS_1755_MISSINGID_INCOMING_SIGNATURE(Object arg0) {
        return messageFactory.getMessage("WSS1755.missingid.incoming.signature", arg0);
    }

    /**
     * WSS1755: Id not present for Incoming signature. Generated Id: {0} for policy verification
     * 
     */
    public static String WSS_1755_MISSINGID_INCOMING_SIGNATURE(Object arg0) {
        return localizer.localize(localizableWSS_1755_MISSINGID_INCOMING_SIGNATURE(arg0));
    }

    public static Localizable localizableWSS_1753_TARGET_DIGEST_ALGORITHM(Object arg0) {
        return messageFactory.getMessage("WSS1753.target.digest.algorithm", arg0);
    }

    /**
     * WSS1753: Digest algorithm used: {0}
     * 
     */
    public static String WSS_1753_TARGET_DIGEST_ALGORITHM(Object arg0) {
        return localizer.localize(localizableWSS_1753_TARGET_DIGEST_ALGORITHM(arg0));
    }

    public static Localizable localizableWSS_1713_SIGNATURE_VERIFICATION_EXCEPTION(Object arg0) {
        return messageFactory.getMessage("WSS1713.signature.verification.exception", arg0);
    }

    /**
     * WSS1713: Signature verification failed due to: {0}
     * 
     */
    public static String WSS_1713_SIGNATURE_VERIFICATION_EXCEPTION(Object arg0) {
        return localizer.localize(localizableWSS_1713_SIGNATURE_VERIFICATION_EXCEPTION(arg0));
    }

    public static Localizable localizableWSS_1707_ERROR_PROCESSING_SIGNEDINFO(Object arg0) {
        return messageFactory.getMessage("WSS1707.error.processing.signedinfo", arg0);
    }

    /**
     * WSS1707: Elements under Signature are not as per defined schema or error must have occurred while processing SignedInfo for Signature with ID {0}
     * 
     */
    public static String WSS_1707_ERROR_PROCESSING_SIGNEDINFO(Object arg0) {
        return localizer.localize(localizableWSS_1707_ERROR_PROCESSING_SIGNEDINFO(arg0));
    }

    public static Localizable localizableWSS_1751_NUMBER_TARGETS_SIGNATURE(Object arg0) {
        return messageFactory.getMessage("WSS1751.number.targets.signature", arg0);
    }

    /**
     * WSS1751: Number of targets in Signature is: {0}.
     * 
     */
    public static String WSS_1751_NUMBER_TARGETS_SIGNATURE(Object arg0) {
        return localizer.localize(localizableWSS_1751_NUMBER_TARGETS_SIGNATURE(arg0));
    }

    public static Localizable localizableWSS_1701_SIGN_FAILED() {
        return messageFactory.getMessage("WSS1701.sign.failed");
    }

    /**
     * WSS1701: Sign operation failed.
     * 
     */
    public static String WSS_1701_SIGN_FAILED() {
        return localizer.localize(localizableWSS_1701_SIGN_FAILED());
    }

    public static Localizable localizableWSS_1704_ERROR_RESOLVING_ID(Object arg0) {
        return messageFactory.getMessage("WSS1704.error.resolving.id", arg0);
    }

    /**
     * WSS1704: Error occurred while resolving id: {0}. Perhaps it is not present in SOAP message.
     * 
     */
    public static String WSS_1704_ERROR_RESOLVING_ID(Object arg0) {
        return localizer.localize(localizableWSS_1704_ERROR_RESOLVING_ID(arg0));
    }

    public static Localizable localizableWSS_1709_UNRECOGNIZED_SIGNATURE_ELEMENT(Object arg0) {
        return messageFactory.getMessage("WSS1709.unrecognized.signature.element", arg0);
    }

    /**
     * WSS1709: Element name {0} is not recognized under signature.
     * 
     */
    public static String WSS_1709_UNRECOGNIZED_SIGNATURE_ELEMENT(Object arg0) {
        return localizer.localize(localizableWSS_1709_UNRECOGNIZED_SIGNATURE_ELEMENT(arg0));
    }

    public static Localizable localizableWSS_1712_UNBUFFERED_SIGNATURE_ERROR() {
        return messageFactory.getMessage("WSS1712.unbuffered.signature.error");
    }

    /**
     * WSS1712: Signature is not buffered , message not as per configured policy
     * 
     */
    public static String WSS_1712_UNBUFFERED_SIGNATURE_ERROR() {
        return localizer.localize(localizableWSS_1712_UNBUFFERED_SIGNATURE_ERROR());
    }

    public static Localizable localizableWSS_1756_CANONICALIZED_SIGNEDINFO_VALUE(Object arg0) {
        return messageFactory.getMessage("WSS1756.canonicalized.signedinfo.value", arg0);
    }

    /**
     * WSS1756: Canonicalized Signed Info: {0}
     * 
     */
    public static String WSS_1756_CANONICALIZED_SIGNEDINFO_VALUE(Object arg0) {
        return localizer.localize(localizableWSS_1756_CANONICALIZED_SIGNEDINFO_VALUE(arg0));
    }

    public static Localizable localizableWSS_1752_SIGNATURE_TARGET_VALUE(Object arg0) {
        return messageFactory.getMessage("WSS1752.signature.target.value", arg0);
    }

    /**
     * WSS1752: Signature Target Value is {0}
     * 
     */
    public static String WSS_1752_SIGNATURE_TARGET_VALUE(Object arg0) {
        return localizer.localize(localizableWSS_1752_SIGNATURE_TARGET_VALUE(arg0));
    }

    public static Localizable localizableWSS_1708_BASE_64_DECODING_ERROR(Object arg0) {
        return messageFactory.getMessage("WSS1708.base64.decoding.error", arg0);
    }

    /**
     * WSS1708: Error occurred while decoding signatureValue for Signature with ID {0}
     * 
     */
    public static String WSS_1708_BASE_64_DECODING_ERROR(Object arg0) {
        return localizer.localize(localizableWSS_1708_BASE_64_DECODING_ERROR(arg0));
    }

    public static Localizable localizableWSS_1706_ERROR_ENVELOPED_SIGNATURE() {
        return messageFactory.getMessage("WSS1706.error.enveloped.signature");
    }

    /**
     * WSS1706: Error occurred while performing Enveloped Signature
     * 
     */
    public static String WSS_1706_ERROR_ENVELOPED_SIGNATURE() {
        return localizer.localize(localizableWSS_1706_ERROR_ENVELOPED_SIGNATURE());
    }

    public static Localizable localizableWSS_1711_ERROR_VERIFYING_SIGNATURE() {
        return messageFactory.getMessage("WSS1711.error.verifying.signature");
    }

    /**
     * WSS1711: Error occurred while reading signature for verfication
     * 
     */
    public static String WSS_1711_ERROR_VERIFYING_SIGNATURE() {
        return localizer.localize(localizableWSS_1711_ERROR_VERIFYING_SIGNATURE());
    }

}
