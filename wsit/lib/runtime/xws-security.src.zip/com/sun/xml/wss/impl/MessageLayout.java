/*
 * MessageLayout.java
 *
 * Created on September 20, 2006, 4:29 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.sun.xml.wss.impl;

/**
 *
 * @author root
 */
public enum MessageLayout{
    Strict, Lax, LaxTsFirst, LaxTsLast
}

