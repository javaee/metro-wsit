/*
 * SAMLCallback.java
 *
 * Created on October 6, 2006, 2:30 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.sun.xml.wss.impl.callback;

import com.sun.xml.wss.saml.Assertion;
import com.sun.xml.wss.saml.AuthorityBinding;
import javax.security.auth.callback.Callback;
import javax.xml.bind.JAXBElement;
import org.w3c.dom.Element;

/**
 *
 * 
 */
public class SAMLCallback extends XWSSCallback implements Callback {
    
    Element assertion;
    Element authorityBinding;
    //Assertion jaxbAssertion;
    AuthorityBinding authorityInfo;
    
    String confirmation = null;
    String version =null;
    String assertionId = null;
    
    public static final String SV_ASSERTION_TYPE="SV-Assertion";
    public static final String HOK_ASSERTION_TYPE="HOK-Assertion";
    
    public static final String V10_ASSERTION="SAML10Assertion";
    public static final String V11_ASSERTION="SAML11Assertion";
    public static final String V20_ASSERTION="SAML20Assertion";
    
    /** Creates a new instance of SAMLCallback */
    public SAMLCallback() {
    }
    
    public void setAssertionElement(Element samlAssertion) {
        assertion = samlAssertion;
    }
    
    public void setAssertion(JAXBElement samlAssertion) {
        
    }
    public Element getAssertionElement() {
        return assertion;
    }
   
    //public Assertion getAssertion() {
    //    return jaxbAssertion;
    //}
    
    public void setAuthorityBindingElement(Element authority) {
        authorityBinding = authority;
    }
    
    public Element getAuthorityBindingElement() {
        return authorityBinding;
    }
    
    public AuthorityBinding getAuthorityBinding() {
        return authorityInfo;
    }
    
    public void setAuthorityBinding(AuthorityBinding auth) {
        authorityInfo = auth;
    }
    
    public void setConfirmationMethod(String meth) {
        confirmation = meth;
    }
    
    public String getConfirmationMethod() {
        return confirmation;
    }
    
    public String getSAMLVersion() {
        return version;
    }
    
    public void setSAMLVersion(String ver) {
       version = ver;    
    }
    
    public void setAssertionId(String id) {
        assertionId = id;
    }
    
    public String getAssertionId() {
        return assertionId;
    }
}
