/*
 * RealmAuthenticator.java
 *
 * Created on November 11, 2006, 2:11 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.sun.xml.wss;

import com.sun.xml.wss.impl.misc.DefaultRealmAuthenticationAdapter;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.security.auth.Subject;
import javax.servlet.ServletContext;
import javax.xml.soap.SOAPException;

/**
 *
 * @author kumar jayanti
 */
public abstract class RealmAuthenticationAdapter {
    
    public static final String UsernameAuthenticator = "com.sun.xml.xwss.RealmAuthenticator";
    
    /** Creates a new instance of RealmAuthenticator */
    protected RealmAuthenticationAdapter() {
    }
    
    public abstract boolean authenticate(Subject callerSubject, String username, String password) throws XWSSecurityException;
    
    public static RealmAuthenticationAdapter newInstance(Object context) {
        if (context == null) {
            return new DefaultRealmAuthenticationAdapter();
        } else if (context instanceof ServletContext) {
            
            InputStream is = ((ServletContext)context).
                    getResourceAsStream("/META-INF/services/" + UsernameAuthenticator);
            if( is!=null ) {
                try {
                    BufferedReader rd =
                            new BufferedReader(new InputStreamReader(is, "UTF-8"));
                    String factoryClassName = rd.readLine();
                    rd.close();
                    if (factoryClassName != null &&
                            ! "".equals(factoryClassName)) {
                        Object obj = newInstance(factoryClassName, Thread.currentThread().getContextClassLoader());
                        if (!(obj instanceof RealmAuthenticationAdapter)) {
                            throw new Exception("Class :" + factoryClassName + " is not a valid RealmAuthenticationProvider");
                        }
                        return (RealmAuthenticationAdapter)obj;
                    }
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return null;
    }

    
    private static Object newInstance(String className,
            ClassLoader classLoader)
            throws SOAPException {
        try {
            Class spiClass;
            if (classLoader == null) {
                spiClass = Class.forName(className);
            } else {
                spiClass = classLoader.loadClass(className);
            }
            return spiClass.newInstance();
        } catch (ClassNotFoundException x) {
            throw new RuntimeException(
                    "The following RealmAuthenticator: " + className + " specified in META-INF/services of the application archive was not found", x);
        } catch (Exception x) {
            throw new RuntimeException(
                    "The following RealmAuthenticator: " + className + " specified in META-INF/services of the application archive could not be instantiated", x);
        }
    }

}
