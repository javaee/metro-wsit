
/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License).  You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * you own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 */

package com.sun.xml.ws.security.opt.impl.keyinfo;

import com.sun.xml.ws.api.SOAPVersion;
import com.sun.xml.ws.security.opt.api.SecurityElementWriter;
import com.sun.xml.ws.security.opt.api.SecurityHeaderElement;
import com.sun.xml.ws.security.opt.api.reference.DirectReference;
import com.sun.xml.ws.security.opt.impl.util.JAXBUtil;
import com.sun.xml.ws.security.secconv.impl.bindings.DerivedKeyTokenType;
import com.sun.xml.ws.security.secext10.KeyIdentifierType;
import com.sun.xml.ws.security.secext10.SecurityTokenReferenceType;
import com.sun.xml.wss.impl.MessageConstants;
import com.sun.xml.wss.impl.XWSSecurityRuntimeException;

import java.io.OutputStream;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.stream.XMLStreamException;
/**
 *
 * @author K.Venugopal@sun.com
 */
public class DerivedKey implements  com.sun.xml.ws.security.opt.api.keyinfo.DerivedKeyToken,
        SecurityHeaderElement, SecurityElementWriter{
    
    private DerivedKeyTokenType derivedKey = null;
    private SOAPVersion soapVersion = SOAPVersion.SOAP_11;
    private String refId = "";
    /** Creates a new instance of DerivedKey */
    public DerivedKey(DerivedKeyTokenType dkt,SOAPVersion soapVersion) {
        this.derivedKey = dkt;
        this.soapVersion = soapVersion;
    }
    
     public DerivedKey(DerivedKeyTokenType dkt,SOAPVersion soapVersion,String refId) {
        this.derivedKey = dkt;
        this.soapVersion = soapVersion;
        this.refId = refId;
    }
    
    public String getAlgorithm() {
        return derivedKey.getAlgorithm();
    }
    
    public BigInteger getGeneration() {
        return derivedKey.getGeneration();
    }
    
    public String getId() {
        return derivedKey.getId();
    }
    
    public String getLabel() {
        return derivedKey.getLabel();
    }
    
    public BigInteger getLength() {
        return derivedKey.getLength();
    }
    
    public byte[] getNonce() {
        return derivedKey.getNonce();
    }
    
    public BigInteger getOffset() {
        return derivedKey.getOffset();
    }
    
    public SecurityTokenReferenceType getSecurityTokenReference() {
        return derivedKey.getSecurityTokenReference();
    }
    
    public void setAlgorithm(String value) {
        derivedKey.setAlgorithm(value);
    }
    
    public void setGeneration(BigInteger value) {
        derivedKey.setGeneration(value);
    }
    
    public void setId(String value) {
        derivedKey.setId(value);
    }
    
    public void setLabel(String value) {
        derivedKey.setLabel(value);
    }
    
    public void setLength(BigInteger value) {
        derivedKey.setLength(value);
    }
    
    public void setNonce(byte[] value) {
        derivedKey.setNonce(value);
    }
    
    public void setOffset(BigInteger value) {
        derivedKey.setOffset(value);
    }
    
    public void setSecurityTokenReference(SecurityTokenReferenceType value) {
        derivedKey.setSecurityTokenReference(value);
    }
    
    public String getNamespaceURI() {
        return MessageConstants.WSSC_NS;
    }
    
    public String getLocalPart() {
        return MessageConstants.DERIVEDKEY_TOKEN_LNAME;
    }    
   
    public javax.xml.stream.XMLStreamReader readHeader() throws javax.xml.stream.XMLStreamException {
        throw new UnsupportedOperationException();
    }
    
    public void writeTo(OutputStream os) {
        try {
            JAXBElement<DerivedKeyTokenType> dkt =
                    new com.sun.xml.ws.security.secconv.impl.bindings.ObjectFactory().createDerivedKeyToken(derivedKey);
            Marshaller writer = getMarshaller();
            writer.marshal(dkt, os);
        } catch (javax.xml.bind.JAXBException ex) {
            throw new XWSSecurityRuntimeException(ex);
        }
    }
    
    public void writeTo(javax.xml.stream.XMLStreamWriter streamWriter) throws javax.xml.stream.XMLStreamException {
        JAXBElement<DerivedKeyTokenType> dkt =
                new com.sun.xml.ws.security.secconv.impl.bindings.ObjectFactory().createDerivedKeyToken(derivedKey);
        try {
            // If writing to Zephyr, get output stream and use JAXB UTF-8 writer
            Marshaller writer = getMarshaller();
            if (streamWriter instanceof Map) {
                OutputStream os = (OutputStream) ((Map) streamWriter).get("sjsxp-outputstream");
                if (os != null) {
                    streamWriter.writeCharacters("");        // Force completion of open elems
                    
                    writer.marshal(dkt, os);
                    return;
                }
            }
            writer.marshal(dkt, streamWriter);
        } catch (JAXBException e) {
            throw new XMLStreamException(e);
        }
    }
    
    
    private Marshaller getMarshaller() throws JAXBException{
        return JAXBUtil.createMarshaller(soapVersion);
    }
    
    public boolean refersToSecHdrWithId(String id) {
        if(refId != null && refId.length() >0){
            if(refId.equals(id)){
                return true;
            }
        }
        if(this.getSecurityTokenReference() != null){
            SecurityTokenReferenceType ref =  this.getSecurityTokenReference();
            List list = ref.getAny();
            if(list.size() > 0){
                JAXBElement je = (JAXBElement) list.get(0);
                Object obj = je.getValue();
                if(obj instanceof DirectReference ){
                    StringBuffer sb = new StringBuffer();
                    sb.append("#");
                    sb.append(id);
                    return ((DirectReference)obj).getURI().equals(sb.toString());
                }else if(obj instanceof KeyIdentifierType){
                    KeyIdentifierType ki = (KeyIdentifierType)obj;
                    String valueType = ki.getValueType();
                    if(valueType.equals(MessageConstants.WSSE_SAML_KEY_IDENTIFIER_VALUE_TYPE) ||
                            valueType.equals(MessageConstants.WSSE_SAML_v2_0_KEY_IDENTIFIER_VALUE_TYPE)){
                        if(id.equals(ki.getValue())){
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    
    public void writeTo(javax.xml.stream.XMLStreamWriter streamWriter, HashMap props) throws javax.xml.stream.XMLStreamException {
        try{
            Marshaller marshaller = getMarshaller();
            Iterator<String> itr = props.keySet().iterator();
            while(itr.hasNext()){
                String key = itr.next();
                Object value = props.get(key);
                marshaller.setProperty(key,value);
            }
            writeTo(streamWriter);
        }catch(JAXBException jbe){
            throw new XMLStreamException(jbe);
        }
    }
    
}
