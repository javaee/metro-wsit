/*
 * OctectStreamData.java
 *
 * Created on 27 November, 2006, 10:05 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.sun.xml.ws.security.opt.impl.crypto;
import javax.xml.crypto.Data;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
/**
 *
 * @author K.Venugopal@sun.com
 */
public class OctectStreamData implements Data{
    private String data = null;
    /** Creates a new instance of OctectStreamData */
    public OctectStreamData(String data) {
        this.data = data;
    }
    
    public void write(XMLStreamWriter writer) throws XMLStreamException{
        writer.writeCharacters(data);
    }
}
