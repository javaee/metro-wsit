/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License).  You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * you own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 */
package com.sun.xml.ws.security.opt.crypto.dsig;

import com.sun.xml.ws.api.message.Attachment;
import com.sun.xml.ws.security.opt.impl.crypto.AttachmentData;
import com.sun.xml.wss.impl.c14n.Canonicalizer;
import com.sun.xml.wss.impl.c14n.CanonicalizerFactory;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.spec.AlgorithmParameterSpec;
import javax.xml.crypto.Data;
import javax.xml.crypto.MarshalException;
import javax.xml.crypto.OctetStreamData;
import javax.xml.crypto.XMLCryptoContext;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.TransformException;
import javax.xml.crypto.dsig.TransformService;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;

/**
 *
 * @author ashutosh.shahi@sun.com
 */
public class ACOTransform extends TransformService {
    
    /** Creates a new instance of ACOTransform */
    public ACOTransform() {
    }

    @Override
    public void init(TransformParameterSpec params) throws InvalidAlgorithmParameterException {

    }

    @Override
    public void marshalParams(XMLStructure parent, XMLCryptoContext context) throws MarshalException {

    }

    @Override
    public void init(XMLStructure parent, XMLCryptoContext context) throws InvalidAlgorithmParameterException {

    }

    public AlgorithmParameterSpec getParameterSpec() {
        return null;
    }

    public Data transform(Data data, XMLCryptoContext context) throws TransformException {
        if (data instanceof AttachmentData) {
            ByteArrayOutputStream os = null;
            return canonicalize((AttachmentData) data, os);
        }
        return null;
    }

    public Data transform(Data data, XMLCryptoContext context, OutputStream os) throws TransformException {
        if (data instanceof AttachmentData) {
            return canonicalize((AttachmentData) data, os);
        }
        return null;
    }

    public boolean isFeatureSupported(String feature) {
        return false;
    }

    private Data canonicalize(AttachmentData attachmentData, OutputStream os) throws TransformException {
        try{
        Attachment attachment = attachmentData.getAttachment();
        InputStream is = attachment.asInputStream();
        OutputStream byteStream = null;
        if (os == null) {
            byteStream = new ByteArrayOutputStream();
        } else {
            byteStream = os;
        }
        Canonicalizer canonicalizer =  CanonicalizerFactory.getCanonicalizer(attachment.getContentType());
        InputStream resultIs = canonicalizer.canonicalize(is,byteStream);
        if(resultIs!= null) return new OctetStreamData(resultIs);
        return null;
        }catch(Exception ex){
            throw new TransformException(ex.getMessage());
        }
    }
}
