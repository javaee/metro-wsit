/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License).  You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * you own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 */

package com.sun.xml.ws.security.opt.impl.message;

import com.sun.xml.security.core.xenc.ReferenceList;
import com.sun.xml.security.core.xenc.ReferenceType;
import com.sun.xml.ws.security.opt.api.SecurityElementWriter;
import com.sun.xml.ws.security.opt.api.SecurityHeaderElement;
import com.sun.xml.ws.security.opt.impl.util.DOMUtil;
import com.sun.xml.ws.security.opt.impl.util.JAXBUtil;
import com.sun.xml.wss.impl.MessageConstants;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

import com.sun.xml.ws.api.SOAPVersion;

/**
 *
 * @author K.Venugopal@sun.com
 */
public class GSHeaderElement implements SecurityHeaderElement, SecurityElementWriter{
    private List<String> refHeaderElements = new ArrayList<String>(2);
    JAXBElement element = null;
    Object obj = null;
    private String id="";
    private SOAPVersion soapVersion = SOAPVersion.SOAP_11;
    private Element domElement = null;
    public GSHeaderElement(JAXBElement el, SOAPVersion sv ){
        this.element = el;
        this.soapVersion = sv;
    }
    
    public GSHeaderElement(Object obj, SOAPVersion sv ){
        this.obj = obj;
        this.soapVersion = sv;
    }
    
    public GSHeaderElement(Element obj, SOAPVersion sv ){
        this.domElement = obj;
        this.soapVersion = sv;
        if(domElement.getLocalName() == MessageConstants.SAML_ASSERTION_LNAME ){
            id = domElement.getAttribute(MessageConstants.SAML_ASSERTIONID_LNAME);
            if(id == null || id.equals(""))
                id = domElement.getAttribute("ID");
        }
    }
    
    public GSHeaderElement(Element obj){
        this.domElement = obj;
        if(domElement.getLocalName() == MessageConstants.SAML_ASSERTION_LNAME ){
            id = domElement.getAttribute(MessageConstants.SAML_ASSERTIONID_LNAME);
            if(id == null || id.equals(""))
                id = domElement.getAttribute("ID");
        }
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    
    public String getNamespaceURI() {
        if(element != null){
            return element.getName().getNamespaceURI();
        }
        if(domElement != null){
            return domElement.getNamespaceURI();
        }
       
        return "";
    }
    
    
    public String getLocalPart() {
        if(element != null){
            return element.getName().getLocalPart();
        }
        
        if(domElement != null){
            return domElement.getLocalName();
        }
        
         if(obj != null){
            if(obj instanceof ReferenceList){
                ReferenceList rl =  (ReferenceList)obj;
                return MessageConstants.XENC_REFERENCE_LIST_LNAME;
            }
        }
        return "";
    }
    
    
    
    public javax.xml.stream.XMLStreamReader readHeader() throws javax.xml.stream.XMLStreamException {
        throw new UnsupportedOperationException();
    }
    
    
    
    public void writeTo(javax.xml.stream.XMLStreamWriter streamWriter) throws javax.xml.stream.XMLStreamException {
        try{
            Marshaller writer =  getMarshaller();
            if(element != null){
                writer.marshal(element,streamWriter);
            }else if(domElement != null){
                DOMUtil.serializeNode(domElement,streamWriter);
            }else{
                writer.marshal(obj,streamWriter);
            }
        } catch (javax.xml.bind.JAXBException ex) {
            ex.printStackTrace();
        }
    }
    
    public void writeTo(javax.xml.soap.SOAPMessage saaj) throws javax.xml.soap.SOAPException {
        throw new UnsupportedOperationException();
    }
    
    
    public byte[] canonicalize(String algorithm, List<com.sun.xml.wss.impl.c14n.AttributeNS> namespaceDecls) {
        throw new UnsupportedOperationException();
    }
    
    public boolean isCanonicalized() {
        throw new UnsupportedOperationException();
    }
    
    public void writeTo(OutputStream os) {
        try{
            Marshaller writer =  getMarshaller();
            if(element != null){
                writer.marshal(element,os);
            }else{
                writer.marshal(obj,os);
            }
        } catch (javax.xml.bind.JAXBException ex) {
            ex.printStackTrace();
        }
    }
    
    public String getAttribute(String nsUri, String localName) {
        throw new UnsupportedOperationException();
    }
    
    public String getAttribute(QName name) {
        throw new UnsupportedOperationException();
    }
    
    public boolean refersToSecHdrWithId(String id) {
        String tmpId = "#"+id;
        if(element != null){
            if(element.getName().getLocalPart() == MessageConstants.XENC_REFERENCE_LIST_LNAME){
                ReferenceList list = (ReferenceList)element.getValue();
                List<JAXBElement<ReferenceType>> listElems= list.getDataReferenceOrKeyReference();
                for (int i=0;i<listElems.size();i++){
                    JAXBElement<ReferenceType> ref =listElems.get(i);
                    ReferenceType rt = ref.getValue();
                    if(rt.getURI().equals(tmpId)){
                        return true;
                    }
                }
            }
        }
        if(obj != null){
            if(obj instanceof ReferenceList){
                ReferenceList rl =  (ReferenceList)obj;
                List<JAXBElement<ReferenceType>> listElems= rl.getDataReferenceOrKeyReference();
                for (int i=0;i<listElems.size();i++){
                    JAXBElement<ReferenceType> ref =listElems.get(i);
                    ReferenceType rt = ref.getValue();
                    if(rt.getURI().equals(tmpId)){
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public void writeTo(javax.xml.stream.XMLStreamWriter streamWriter, HashMap props) throws javax.xml.stream.XMLStreamException {
        writeTo(streamWriter);
    }
    
    private Marshaller getMarshaller() throws javax.xml.bind.JAXBException{
        return JAXBUtil.createMarshaller(soapVersion);
    }
}
