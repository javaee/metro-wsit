/*
 * KeyIdentifier.java
 *
 * Created on August 7, 2006, 1:48 PM
 *
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License).  You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * you own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 */

package com.sun.xml.ws.security.opt.impl.reference;

import com.sun.istack.NotNull;
import com.sun.xml.ws.security.opt.api.SecurityElementWriter;
import com.sun.xml.ws.security.opt.api.SecurityHeaderElement;
import com.sun.xml.wss.XWSSecurityException;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Iterator;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.sun.xml.ws.security.secext10.KeyIdentifierType;
import com.sun.xml.ws.security.secext10.ObjectFactory;
import com.sun.xml.wss.impl.MessageConstants;
import com.sun.xml.stream.buffer.XMLStreamBufferResult;
import com.sun.xml.ws.security.opt.impl.util.JAXBUtil;
import com.sun.xml.wss.impl.misc.Base64;

import java.util.Map;
import java.io.OutputStream;
import com.sun.xml.ws.api.SOAPVersion;

/**
 *
 * @author Ashutosh.Shahi@sun.com
 */
public class KeyIdentifier extends KeyIdentifierType
        implements com.sun.xml.ws.security.opt.api.reference.KeyIdentifier,
        SecurityHeaderElement, SecurityElementWriter {

    private SOAPVersion soapVersion = SOAPVersion.SOAP_11;
    
    /** Creates a new instance of KeyIdentifier */
    public KeyIdentifier(SOAPVersion sv) {
        this.soapVersion = sv;
    }
    
    /**
     * 
     * @return the valueType attribute for KeyIdentifier
     */
    public String getValueType() {
        return super.getValueType();
    }
    
    /**
     * 
     * @param valueType the valueType attribute for KeyIdentifier
     */
    public void setValueType(final String valueType) {
        super.setValueType(valueType);
    }
    
    /**
     * 
     * @return the encodingType attribute
     */
    public String getEncodingType() {
        return super.getEncodingType();
    }
    
    /**
     * 
     * @param value the encodingType attribute
     */
    public void setEncodingType(final String value) {
        super.setEncodingType(value);
    }
    
    /**
     * 
     * @return the referenced value by this key identifier
     */
    public String getReferenceValue() {
        return super.getValue();
    }
    
    /**
     * 
     * @param referenceValue the referenced value by this keyIdentifier
     */
    public void setReferenceValue(final String referenceValue) {
        super.setValue(referenceValue);
    }
    
    /**
     * 
     * @return the reference type used
     */
    public String getType() {
        return MessageConstants.KEY_INDETIFIER_TYPE;
    }
    
    /**
     * 
     * @return id attribute
     */
    public String getId() {
        QName qname = new QName(MessageConstants.WSU_NS, "Id", MessageConstants.WSU_PREFIX);
        Map<QName, String> otherAttributes = this.getOtherAttributes();
        return otherAttributes.get(qname);
    }
    
    /**
     * 
     * @param id 
     */
    public void setId(String id) {
        QName qname = new QName(MessageConstants.WSU_NS, "Id", MessageConstants.WSU_PREFIX);
        Map<QName, String> otherAttributes = this.getOtherAttributes();
        otherAttributes.put(qname, id);
    }
    
    /**
     * 
     * @return namespace uri of Keyidentifier.
     */
    public String getNamespaceURI() {
        return MessageConstants.WSSE_NS;
    }
    
    /**
     * Gets the local name of this header element.
     *
     * @return
     *      this string must be interned.
     */
    public String getLocalPart() {
        return "KeyIdentifier".intern();
    }
    
    
    public String getAttribute(@NotNull String nsUri, @NotNull String localName) {
        QName qname = new QName(nsUri, localName);
        Map<QName, String> otherAttributes = this.getOtherAttributes();
        return otherAttributes.get(qname);
    }
    
    
    public String getAttribute(@NotNull QName name) {
        Map<QName, String> otherAttributes = this.getOtherAttributes();
        return otherAttributes.get(name);
    }
    
    public XMLStreamReader readHeader() throws XMLStreamException {
        XMLStreamBufferResult xbr = new XMLStreamBufferResult();
        JAXBElement<KeyIdentifierType> keyIdentifierElem = new ObjectFactory().createKeyIdentifier(this);
        try{
            getMarshaller().marshal(keyIdentifierElem, xbr);
            
        } catch(JAXBException je){
            throw new XMLStreamException(je);
        }
        return xbr.getXMLStreamBuffer().readAsXMLStreamReader();
    }
    
    /**
     * Writes out the header.
     *
     * @throws XMLStreamException
     *      if the operation fails for some reason. This leaves the
     *      writer to an undefined state.
     */
    public void writeTo(XMLStreamWriter streamWriter) throws XMLStreamException {
        JAXBElement<KeyIdentifierType> keyIdentifierElem = new ObjectFactory().createKeyIdentifier(this);
        try {
            // If writing to Zephyr, get output stream and use JAXB UTF-8 writer
            if (streamWriter instanceof Map) {
                OutputStream os = (OutputStream) ((Map) streamWriter).get("sjsxp-outputstream");
                if (os != null) {
                    streamWriter.writeCharacters("");        // Force completion of open elems
                    getMarshaller().marshal(keyIdentifierElem, os);
                    return;
                }
            }
            
            getMarshaller().marshal(keyIdentifierElem,streamWriter);
        } catch (JAXBException e) {
            throw new XMLStreamException(e);
        }
    }
    
    /**
     * 
     * @param streamWriter 
     * @param props 
     * @throws javax.xml.stream.XMLStreamException 
     */
    public void writeTo(javax.xml.stream.XMLStreamWriter streamWriter, HashMap props) throws javax.xml.stream.XMLStreamException {
        try{
            Marshaller marshaller = getMarshaller();
            Iterator<String> itr = props.keySet().iterator();
            while(itr.hasNext()){
                String key = itr.next();
                Object value = props.get(key);
                marshaller.setProperty(key,value);
            }
            writeTo(streamWriter);
        }catch(JAXBException jbe){
            throw new XMLStreamException(jbe);
        }
    }
    
    private Marshaller getMarshaller() throws JAXBException{
        return JAXBUtil.createMarshaller(soapVersion);
    }
    
    /**
     * 
     * @param os 
     */
    public void writeTo(OutputStream os) {
    }
    
    
    public void updateReferenceValue(X509Certificate cert) throws XWSSecurityException{
        if(getValueType() == MessageConstants.ThumbPrintIdentifier_NS){
            try {
                setReferenceValue(Base64.encode(MessageDigest.getInstance("SHA-1").digest(cert.getEncoded())));
            } catch ( NoSuchAlgorithmException ex ) {
                throw new XWSSecurityException("Digest algorithm SHA-1 not found");
            } catch ( CertificateEncodingException ex) {
                throw new XWSSecurityException("Error while getting certificate's raw content");
            }
        }else if(getValueType() ==MessageConstants.X509SubjectKeyIdentifier_NS) {
            byte[] subjectKeyIdentifier =
                    cert.getExtensionValue(MessageConstants.SUBJECT_KEY_IDENTIFIER_OID);
            if (subjectKeyIdentifier == null)
                return;
            
            try {
                sun.security.x509.KeyIdentifier keyId = null;
                
                sun.security.util.DerValue derVal = new sun.security.util.DerValue(
                        new sun.security.util.DerInputStream(subjectKeyIdentifier).getOctetString());
                
                keyId = new sun.security.x509.KeyIdentifier(derVal.getOctetString());
                setReferenceValue(Base64.encode(keyId.getIdentifier()));
            } catch (NoClassDefFoundError ncde) {
                // TODO X509 Token profile states that only the contents of the
                // OCTET STRING should be returned, excluding the "prefix"
                byte[] dest = new byte[subjectKeyIdentifier.length-4];
                System.arraycopy(
                        subjectKeyIdentifier, 4, dest, 0, subjectKeyIdentifier.length-4);
                setReferenceValue(Base64.encode(dest));
                
            } catch (IOException e) {
                //log exception
                throw new XWSSecurityException("Error in extracting keyIdentifier" + e.getMessage());
            }
        }
    }
    
    /**
     * 
     * @param id 
     * @return 
     */
    public boolean refersToSecHdrWithId(String id) {        
        String valueType =this.getValueType();
        if(valueType.equals(MessageConstants.WSSE_SAML_KEY_IDENTIFIER_VALUE_TYPE) ||
                valueType.equals(MessageConstants.WSSE_SAML_v2_0_KEY_IDENTIFIER_VALUE_TYPE)){
            if(id.equals(this.getValue())){
                return true;
            }
        }
        return false;
    }
}
