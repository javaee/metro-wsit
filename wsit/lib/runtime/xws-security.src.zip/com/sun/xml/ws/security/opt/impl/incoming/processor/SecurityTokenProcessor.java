/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License).  You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * you own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 */

package com.sun.xml.ws.security.opt.impl.incoming.processor;

import com.sun.xml.ws.security.opt.crypto.jaxb.JAXBValidateContext;
import com.sun.xml.ws.security.opt.impl.JAXBFilterProcessingContext;
import com.sun.xml.ws.security.opt.impl.incoming.KeySelectorImpl;
import com.sun.xml.ws.security.opt.impl.incoming.StreamWriterData;
import com.sun.xml.ws.security.opt.impl.incoming.URIResolver;
import com.sun.xml.wss.XWSSecurityException;
import com.sun.xml.wss.impl.MessageConstants;
import java.security.Key;
import javax.xml.crypto.KeySelector.Purpose;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import com.sun.xml.ws.security.opt.impl.util.StreamUtil;
import javax.xml.crypto.KeySelectorException;
import javax.xml.stream.XMLStreamWriter;
import com.sun.xml.stream.buffer.AbstractCreatorProcessor;
import com.sun.xml.stream.buffer.XMLStreamBufferMark;
import org.jvnet.staxex.Base64Data;
import org.jvnet.staxex.XMLStreamReaderEx;

/**
 *
 * @author K.Venugopal@sun.com
 */
public class SecurityTokenProcessor {
    private static String SECURITY_TOKEN_REF = "SecurityTokenReference";
    private static String DIRECT_REFERENCE_ELEMENT = "Reference";
    private static String KEYIDENTIFIER_ELEMENT = "KeyIdentifier";
    private static String THUMBPRINT_ELEMENT = "Thumbprint";
    
    private static final int DIRECT_REFERENCE = 1;
    private static final int KEYIDENTIFIER = 2;
    private static final int THUMBPRINT = 3;
    private static final int KEY_VALUE_ELEMENT = 4;
    private static final String KEY_VALUE = "KeyValue";
    private JAXBFilterProcessingContext pc = null;
    private XMLStreamWriter canonWriter = null;
    private Purpose purpose = null;
    private String id = "";
    
    /** Creates a new instance of SecurityTokenProcessor */
    public SecurityTokenProcessor(JAXBFilterProcessingContext context,Purpose purpose) {
        this.pc = (JAXBFilterProcessingContext) context;
        this.purpose =purpose;
    }
    
    public SecurityTokenProcessor(JAXBFilterProcessingContext context, XMLStreamWriter canonWriter,Purpose purpose) {
        this.pc = (JAXBFilterProcessingContext) context;
        this.canonWriter = canonWriter;
        this.purpose =purpose;
    }
    
    
    public Key resolveReference(XMLStreamReader reader) throws XWSSecurityException{
        
        Key resolvedKey = null;
        try{
            if(canonWriter != null)
                StreamUtil.writeStartElement(reader, canonWriter);
            id = reader.getAttributeValue(MessageConstants.WSU_NS,"Id");
            if(id != null && id.length() >0){
                //cache STR
                if(reader instanceof AbstractCreatorProcessor){
                    XMLStreamBufferMark marker=  new XMLStreamBufferMark(null,(AbstractCreatorProcessor)reader);
                    pc.getElementCache().put(id,new StreamWriterData(marker));
                }
            }
            if(reader.getLocalName() == SECURITY_TOKEN_REF && reader.getNamespaceURI() == MessageConstants.WSSE_NS){
                while(reader.hasNext() && !StreamUtil._break(reader,SECURITY_TOKEN_REF,MessageConstants.WSSE_NS)){
                    reader.next();
                    int refType = getReferenceType(reader);
                    switch(refType){
                        case DIRECT_REFERENCE :{
                            resolvedKey = processDirectReference(reader);
                            break;
                        }
                        case KEYIDENTIFIER :{
                            resolvedKey = processKeyIdentifier(reader);
                            break;
                        }
                        case THUMBPRINT :{
                            break;
                        }
                        case KEY_VALUE_ELEMENT :{
                            if(canonWriter != null){
                                StreamUtil.writeCurrentEvent(reader,canonWriter);
                            }
                            resolvedKey = new KeyValueProcessor(pc,canonWriter).processKeyValue(reader);
                            break;
                        }
                    }
                }
            }
            if(canonWriter != null)
                canonWriter.writeEndElement();
            if(reader.hasNext()){
                reader.next();
            }
        }catch(XMLStreamException xe){
            throw new XWSSecurityException("Error while processing SecurityTokenReference",xe);
        }
        return resolvedKey;
    }
    
    private int getReferenceType(XMLStreamReader reader){
        if(reader.getEventType() == reader.START_ELEMENT){
            if(reader.getLocalName() == DIRECT_REFERENCE_ELEMENT){
                return DIRECT_REFERENCE;
            }else if(reader.getLocalName() == KEYIDENTIFIER_ELEMENT){
                return KEYIDENTIFIER;
            }else if(reader.getLocalName() == THUMBPRINT_ELEMENT){
                return THUMBPRINT;
            }else if(reader.getLocalName() == KEY_VALUE){
                return KEY_VALUE_ELEMENT;
            }
        }
        
        return -1;
        
    }
    
    private boolean moveToNextElement(XMLStreamReader reader) throws XMLStreamException{
        if(reader.hasNext()){
            reader.next();
            return true;
        }
        return false;
    }
    
    private Key processDirectReference(XMLStreamReader reader) throws XWSSecurityException{
        try{
            if(canonWriter != null)
                StreamUtil.writeStartElement(reader, canonWriter);
            String valueType = reader.getAttributeValue(null, "ValueType");
            String uri = reader.getAttributeValue(null, "URI");
            if(canonWriter != null)
                canonWriter.writeEndElement();
            
            //resolve Key
            URIResolver resolver = new URIResolver(pc);
            JAXBValidateContext validateContext = new JAXBValidateContext();
            validateContext.setURIDereferencer(resolver);
            validateContext.put(MessageConstants.WSS_PROCESSING_CONTEXT, pc);
            reader.next();
            reader.next();//move to STR End Element
            return KeySelectorImpl.resolveDirectReference(validateContext, valueType, uri, purpose);
        } catch(KeySelectorException kse){
            throw new XWSSecurityException("Error occurred while resolving Direct Reference", kse);
        } catch(XMLStreamException xse){
            throw new XWSSecurityException("Error occurred while writing DirectReference to canonicalized writer", xse);
        }
    }
    
    private Key processKeyIdentifier(XMLStreamReader reader) throws XWSSecurityException{
        try{
            if(canonWriter != null)
                StreamUtil.writeStartElement(reader, canonWriter);
            String valueType = reader.getAttributeValue(null,"ValueType");
            //String encodingType = reader.getAttributeValue(null,"EncodingType");
            
            String keyIdentifier = null;
            if(reader instanceof XMLStreamReaderEx){
                reader.next();
                if(reader.getEventType() == XMLStreamReader.CHARACTERS){
                    CharSequence charSeq = ((XMLStreamReaderEx)reader).getPCDATA();
                    if(charSeq instanceof Base64Data){
                        Base64Data bd = (Base64Data)charSeq;
                        keyIdentifier = bd.toString();
                    } else{
                        keyIdentifier = StreamUtil.getCV((XMLStreamReaderEx)reader);
                    }
                }
            } else{
                keyIdentifier = StreamUtil.getCV(reader);
            }
            
            if(canonWriter != null){
                // write KeyIdentifier Value
                canonWriter.writeCharacters(keyIdentifier);
                // End Element for KeyIdentifier
                canonWriter.writeEndElement();
            }
            reader.next();
            //resolve Key.
            URIResolver resolver = new URIResolver(pc);
            JAXBValidateContext validateContext = new JAXBValidateContext();
            validateContext.setURIDereferencer(resolver);
            validateContext.put(MessageConstants.WSS_PROCESSING_CONTEXT, pc);
            return KeySelectorImpl.resolveKeyIdentifier(validateContext,valueType,keyIdentifier,id,purpose);
        }catch(KeySelectorException kse){
            throw new XWSSecurityException("Error occurred while resolving KeyIdentifier",kse);
        }catch(XMLStreamException xe){
            throw new XWSSecurityException("Error occurred while proccesing KeyIndentifier",xe);
        }
        
    }
}
