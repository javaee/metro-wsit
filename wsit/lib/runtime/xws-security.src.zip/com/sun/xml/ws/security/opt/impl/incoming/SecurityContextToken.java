/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License).  You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * you own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 */

package com.sun.xml.ws.security.opt.impl.incoming;

import com.sun.xml.stream.buffer.MutableXMLStreamBuffer;
import com.sun.xml.stream.buffer.stax.StreamWriterBufferCreator;
import com.sun.xml.ws.security.opt.api.NamespaceContextInfo;
import com.sun.xml.ws.security.opt.api.SecurityElementWriter;
import com.sun.xml.ws.security.opt.api.SecurityHeaderElement;
import com.sun.xml.ws.security.opt.impl.JAXBFilterProcessingContext;
import com.sun.xml.ws.security.opt.impl.util.StreamUtil;
import com.sun.xml.wss.XWSSecurityException;
import com.sun.xml.wss.impl.MessageConstants;
import java.io.OutputStream;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamException;

/**
 *
 * @author Ashutosh.Shahi@sun.com
 */
public class SecurityContextToken implements SecurityHeaderElement, NamespaceContextInfo,
        SecurityElementWriter, com.sun.xml.ws.security.SecurityContextToken {
    
    private static final String IDENTIFIER = "Identifier".intern();
    private static final String INSTANCE = "Instance".intern();
    
    private static final int IDENTIFIER_ELEMENT = 1;
    private static final int INSTANCE_ELEMENT = 2;
    
    private String id = "";
    private String namespaceURI = "";
    private String localName = "";
    private String identifier = null;
    private String instance = null;
    private List extElements = null;
    private JAXBFilterProcessingContext pc;
    private MutableXMLStreamBuffer buffer = null;
    private HashMap<String,String> nsDecls;
    
    /** Creates a new instance of SecurityContextToken */
    public SecurityContextToken(XMLStreamReader reader,JAXBFilterProcessingContext pc,
            HashMap nsDecls) throws XMLStreamException, XWSSecurityException {
        this.pc = pc;
        this.nsDecls = nsDecls;
        id = reader.getAttributeValue(MessageConstants.WSU_NS,"Id");
        namespaceURI = reader.getNamespaceURI();
        localName = reader.getLocalName();
        buffer = new MutableXMLStreamBuffer();
        buffer.createFromXMLStreamReader(reader);
        XMLStreamReader sct =  buffer.readAsXMLStreamReader();
        sct.next();
        process(sct);
    }
    
    public String getSCId(){
        return identifier;
    }
    
    public URI getIdentifier() {
        try {
            return new URI(identifier);
        }catch(Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public String getInstance() {
        return instance;
    }
    
    public List getExtElements() {
        return extElements;
    }
    
    public boolean refersToSecHdrWithId(final String id) {
        throw new UnsupportedOperationException();
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(final String id) {
        throw new UnsupportedOperationException();
    }
    
    public String getNamespaceURI() {
        return namespaceURI;
    }
    
    public String getLocalPart() {
        return localName;
    }
    
    public javax.xml.stream.XMLStreamReader readHeader() throws javax.xml.stream.XMLStreamException {
        throw new UnsupportedOperationException();
    }
    
    public void writeTo(OutputStream os) {
        throw new UnsupportedOperationException();
    }
    
    public void writeTo(javax.xml.stream.XMLStreamWriter streamWriter) throws javax.xml.stream.XMLStreamException {
        buffer.writeToXMLStreamWriter(streamWriter);
    }
    
    
    public HashMap<String, String> getInscopeNSContext() {
        return nsDecls;
    }
    
    private void process(XMLStreamReader reader) throws XMLStreamException, XWSSecurityException {
        
        
        if(StreamUtil.moveToNextElement(reader)){
            int refElement = getEventType(reader);
            while(reader.getEventType() != reader.END_DOCUMENT){
                switch(refElement){
                    case IDENTIFIER_ELEMENT : {
                        identifier = reader.getElementText();
                        break;
                    }
                    case INSTANCE_ELEMENT:{
                        instance = reader.getElementText();
                        break;
                    }
                    // extension elements?
                    default :{
                        throw new XWSSecurityException("Element name "+reader.getName()+" is not recognized under SecurityContextToken");
                    }
                }
                if(StreamUtil.moveToNextStartOREndElement(reader) &&
                        StreamUtil._break(reader, "SecurityContextToken", MessageConstants.WSSC_NS)){
                    
                    break;
                }else{
                    if(reader.getEventType() != XMLStreamReader.START_ELEMENT){
                        StreamUtil.moveToNextElement(reader);
                    }
                }
                refElement = getEventType(reader);
            }
            
        }
    }
    
    private int getEventType(javax.xml.stream.XMLStreamReader reader) {
        if(reader.getEventType()== XMLStreamReader.START_ELEMENT){
            if(reader.getLocalName() == IDENTIFIER){
                return IDENTIFIER_ELEMENT;
            }
            if(reader.getLocalName() == INSTANCE){
                return INSTANCE_ELEMENT;
            }
        }
        return -1;
    }
    
    public void writeTo(javax.xml.stream.XMLStreamWriter streamWriter, HashMap props) throws javax.xml.stream.XMLStreamException {
        throw new UnsupportedOperationException();
    }
    
    public String getWsuId() {
        return id;
    }
    
    public String getType() {
        return MessageConstants.SECURITY_CONTEXT_TOKEN_NS;
    }
    
    public Object getTokenValue() {
        return this;
    }
    
}
