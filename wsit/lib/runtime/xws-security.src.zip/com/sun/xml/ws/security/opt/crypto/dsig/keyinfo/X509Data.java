/*
 * X509Data.java
 *
 * Created on January 24, 2006, 4:52 PM
 */

/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License).  You may not use this file except in
 * compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * you own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 * 
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 */

package com.sun.xml.ws.security.opt.crypto.dsig.keyinfo;

import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Abhijit Das
 */
@XmlRootElement(name="X509Data", namespace = "http://www.w3.org/2000/09/xmldsig#")
public class X509Data extends com.sun.xml.security.core.dsig.X509DataType implements javax.xml.crypto.dsig.keyinfo.X509Data {
    
    /** Creates a new instance of X509Data */
    public X509Data() {
    }

    public List getContent() {
        return x509IssuerSerialOrX509SKIOrX509SubjectName;
    }
    
    
    public boolean isFeatureSupported(String string) {
        return false;
    }
    
    public void setX509IssuerSerialOrX509SKIOrX509SubjectName(List<Object> x509IssuerSerialOrX509SKIOrX509SubjectName){
        this.x509IssuerSerialOrX509SKIOrX509SubjectName = x509IssuerSerialOrX509SKIOrX509SubjectName;
    }
    
}
