/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License).  You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * you own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 */

package com.sun.xml.ws.security.opt.impl.incoming;

import com.sun.xml.ws.api.message.Header;
import com.sun.xml.ws.api.message.HeaderList;
import com.sun.xml.ws.security.opt.api.NamespaceContextInfo;
import com.sun.xml.ws.security.opt.api.SecurityHeaderElement;
import com.sun.xml.ws.security.opt.impl.JAXBFilterProcessingContext;
import java.util.ArrayList;
import java.util.Iterator;
import javax.xml.crypto.Data;
import javax.xml.crypto.URIDereferencer;
import javax.xml.crypto.URIReference;
import javax.xml.crypto.URIReferenceException;
import javax.xml.crypto.XMLCryptoContext;

/**
 *
 * @author K.Venugopal@sun.com
 */
public class URIResolver implements URIDereferencer{
    private SecurityContext securityContext;
    private JAXBFilterProcessingContext pc = null;
    /** Creates a new instance of resolver */
    public URIResolver(JAXBFilterProcessingContext pc) {
        this.pc = pc;
        this.securityContext = pc.getSecurityContext();
    }
    
    public Data dereference(URIReference uRIReference, XMLCryptoContext xMLCryptoContext) throws URIReferenceException {
        
        HeaderList headers = securityContext.getNonSecurityHeaders();
        String tmpId = uRIReference.getURI();
        String id = "";
        int index = tmpId.indexOf("#");
        if( index >=0){
            id = tmpId.substring(index+1);
        }else{
            id = tmpId;
        }
        if(headers != null && headers.size() >0){
            Iterator<Header> listItr = headers.listIterator();
            boolean found = false;
            while(listItr.hasNext()){
                GenericSecuredHeader header = (GenericSecuredHeader)listItr.next();
                if(header.hasID(id) && !header.hasEncData()){
                    return new StreamWriterData(header,((NamespaceContextInfo)header).getInscopeNSContext());
                }
            }
        }
        
        ArrayList pshList =  securityContext.getProcessedSecurityHeaders();
        for(int j=0; j< pshList.size() ; j++){
            SecurityHeaderElement  header = (SecurityHeaderElement) pshList.get(j);
            if(id.equals(header.getId())){
                if(header instanceof NamespaceContextInfo){
                    return new StreamWriterData(header,((NamespaceContextInfo)header).getInscopeNSContext());
                }else{
                    throw new URIReferenceException("Cannot derefernce this MessagePart and use if for any crypto operation " +
                              "as the message part is not cached");
                }
            }
        }
        
        // looking into buffered headers for - (Should be used only for getting the key)
        // What will happen when encrypting the content but signing the entire element? Can go wrong
        ArrayList bufList =  securityContext.getBufferedSecurityHeaders();
        for(int j=0; j< bufList.size() ; j++){
            SecurityHeaderElement  header = (SecurityHeaderElement) bufList.get(j);
            if(id.equals(header.getId())){
                if(header instanceof NamespaceContextInfo){
                    return new StreamWriterData(header,((NamespaceContextInfo)header).getInscopeNSContext());
                }else{
                    throw new URIReferenceException("Cannot derefernce this MessagePart and use if for any crypto operation " +
                              "as the message part is not cached");
                }
            }
        }
        
        Data data = null;
        data = (Data)pc.getElementCache().get(id);
        return data;
    }
    
}
