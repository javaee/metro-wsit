/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License).  You may not use this file except in
 * compliance with the License.
 * 
 * You can obtain a copy of the license at
 * https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * you own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 * 
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 */

/*
 * JAXBStructure.java
 *
 * Created on February 6, 2006, 5:01 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.sun.xml.ws.security.opt.crypto.jaxb;

import javax.xml.bind.JAXBElement;

/**
 *
 * @author Abhijit Das
 */
public class JAXBStructure implements javax.xml.crypto.XMLStructure {
    
    private final JAXBElement jbElement;
    /** Creates a new instance of JAXBStructure */
    public JAXBStructure(JAXBElement jbElement) {
        if(jbElement == null)
            throw new NullPointerException("JAXBElement cannot be null");
        this.jbElement = jbElement;
    }
    
    /**
     * Returns the JAXBElement contained in this <code>JAXBStructure</code>.
     *
     * @return the JAXBElement
     */
    public JAXBElement getJAXBElement(){
        return jbElement;
    }

    /**
     * @throws NullPointerException {@inheritDoc}
     */
    public boolean isFeatureSupported(String feature) {
        if (feature == null) {
            throw new NullPointerException();
        } else {
            return false;
        }
    }
    
}
