/*
 * SecurityTokenReference.java
 *
 * Created on August 2, 2006, 5:15 PM
 *
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License).  You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the license at
 * https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * you own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 */

package com.sun.xml.ws.security.opt.impl.keyinfo;

import com.sun.istack.NotNull;
import com.sun.xml.ws.api.SOAPVersion;
import com.sun.xml.ws.security.Token;
import com.sun.xml.ws.security.opt.api.SecurityElementWriter;
import com.sun.xml.ws.security.opt.api.reference.Reference;
import com.sun.xml.ws.security.opt.api.SecurityHeaderElement;
import com.sun.xml.wss.impl.c14n.AttributeNS;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import com.sun.xml.ws.security.opt.impl.util.JAXBUtil;
import com.sun.xml.ws.security.secext10.SecurityTokenReferenceType;
import com.sun.xml.stream.buffer.XMLStreamBufferResult;
import com.sun.xml.wss.impl.MessageConstants;
import com.sun.xml.ws.security.opt.impl.reference.DirectReference;
import com.sun.xml.ws.security.opt.impl.reference.KeyIdentifier;
import com.sun.xml.ws.security.secext10.ObjectFactory;

import java.util.Map;
import java.io.OutputStream;


/**
 *
 * @author Ashutosh.Shahi@sun.com
 */

public class SecurityTokenReference extends SecurityTokenReferenceType
          implements com.sun.xml.ws.security.opt.api.keyinfo.SecurityTokenReference, 
        SecurityHeaderElement, SecurityElementWriter, Token {
    
    //private SecurityTokenReferenceType str = null;
    
    private boolean isCanonicalized = false;
    SOAPVersion sv = SOAPVersion.SOAP_11;
    
    /** Creates a new instance of SecurityTokenReference */
    public SecurityTokenReference(SOAPVersion soapVersion) {
        this.sv = soapVersion;
    }
    
    public void setReference(Reference ref) {
        JAXBElement refElem = null;
        String type = ref.getType();
        ObjectFactory objFac = new ObjectFactory();
        if (KEYIDENTIFIER.equals(type)){
            refElem = objFac.createKeyIdentifier((KeyIdentifier)ref);
        } else if (REFERENCE.equals(type)){
            refElem = objFac.createReference((DirectReference)ref);
        }
        
        if(refElem != null){
            List<Object> list = this.getAny();
            list.clear();
            list.add(refElem);
        }
    }
    
    public Reference getReference() {
        List<Object> list = this.getAny();
        JAXBElement obj = (JAXBElement)list.get(0);
        String local = obj.getName().getLocalPart();
        if (REFERENCE.equals(local)) {
            return (DirectReference)obj.getValue();
        } else if(KEYIDENTIFIER.equalsIgnoreCase(local)) {
            return (KeyIdentifier)obj.getValue();
        }
        //anything else??
        return null;
    }
    
    public void setTokenType(String tokenType) {
        QName qname = new QName(MessageConstants.WSSE11_NS,
                  MessageConstants.TOKEN_TYPE_LNAME, MessageConstants.WSSE11_PREFIX);
        Map<QName, String> otherAttributes = this.getOtherAttributes();
        otherAttributes.put(qname, tokenType);
    }
    
    public String getTokenType() {
        QName qname = new QName(MessageConstants.WSSE11_NS,
                  MessageConstants.TOKEN_TYPE_LNAME, MessageConstants.WSSE11_PREFIX);
        Map<QName, String> otherAttributes = this.getOtherAttributes();
        return otherAttributes.get(qname);
    }
    
    public String getNamespaceURI() {
        return MessageConstants.WSSE_NS;
    }
    
    
    public String getLocalPart() {
        return MessageConstants.WSSE_SECURITY_TOKEN_REFERENCE_LNAME;
    }
    
    
    public String getAttribute(@NotNull String nsUri, @NotNull String localName) {
        QName qname = new QName(nsUri, localName);
        Map<QName, String> otherAttributes = this.getOtherAttributes();
        return otherAttributes.get(qname);
    }
    
    
    public String getAttribute(@NotNull QName name) {
        Map<QName, String> otherAttributes = this.getOtherAttributes();
        return otherAttributes.get(name);
    }
    
    public XMLStreamReader readHeader() throws XMLStreamException {
        XMLStreamBufferResult xbr = new XMLStreamBufferResult();
        JAXBElement<SecurityTokenReferenceType> strElem = new ObjectFactory().createSecurityTokenReference(this);
        try{
            getMarshaller().marshal(strElem, xbr);
            
        } catch(JAXBException je){
            throw new XMLStreamException(je);
        }
        return xbr.getXMLStreamBuffer().readAsXMLStreamReader();
    }
    
    
    
    public void writeTo(XMLStreamWriter streamWriter) throws XMLStreamException {
        JAXBElement<SecurityTokenReferenceType> strElem = new ObjectFactory().createSecurityTokenReference(this);
        try {
            // If writing to Zephyr, get output stream and use JAXB UTF-8 writer
            if (streamWriter instanceof Map) {
                OutputStream os = (OutputStream) ((Map) streamWriter).get("sjsxp-outputstream");
                if (os != null) {
                    streamWriter.writeCharacters("");        // Force completion of open elems
                    getMarshaller().marshal(strElem, os);
                    return;
                }
            }
            
            getMarshaller().marshal(strElem,streamWriter);
        } catch (JAXBException e) {
            throw new XMLStreamException(e);
        }
    }
    
    
    public byte[] canonicalize(String algorithm, List<AttributeNS> namespaceDecls) {
        throw new UnsupportedOperationException();
    }
    
    public boolean isCanonicalized() {
        return isCanonicalized;
    }
    
    private Marshaller getMarshaller() throws JAXBException{
        return JAXBUtil.createMarshaller(sv);
    }
    
    public void writeTo(OutputStream os) {
        throw new UnsupportedOperationException();
    }
    
    public boolean refersToSecHdrWithId(String id) {
        List list = super.getAny();
        if(list.size() > 0){
            JAXBElement je = (JAXBElement) list.get(0);
            Object obj = je.getValue();
            if(obj instanceof DirectReference ){
                StringBuffer sb = new StringBuffer();
                sb.append("#");
                sb.append(id);
                return ((DirectReference)obj).getURI().equals(sb.toString());
            }else if(obj instanceof KeyIdentifier){
                return ((KeyIdentifier)obj).refersToSecHdrWithId(id);
            }
        }
        return false;
    }

    public void writeTo(javax.xml.stream.XMLStreamWriter streamWriter, HashMap props) throws javax.xml.stream.XMLStreamException {
        try{
            Marshaller marshaller = getMarshaller();
            Iterator<String> itr = props.keySet().iterator();
            while(itr.hasNext()){
                String key = itr.next();
                Object value = props.get(key);
                marshaller.setProperty(key,value);
            }
            writeTo(streamWriter);
        }catch(JAXBException jbe){
            throw new XMLStreamException(jbe);
        }
    }

    public String getType() {
        return "SecurityTokenReference";
    }

    public Object getTokenValue() {
        return getReference();
    }
    
}
