package javax.jws.soap;

/*
 * @Deprecated
 */
@Deprecated public @interface InitParam {
    String name();
    String value();
}

