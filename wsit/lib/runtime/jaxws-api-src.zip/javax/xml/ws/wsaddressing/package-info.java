/*
 * Copyright 2006 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */


@javax.xml.bind.annotation.XmlSchema(namespace=W3CEndpointReference.NS,
                                     location="http://www.w3.org/2006/03/addressing/ws-addr.xsd")
package javax.xml.ws.wsaddressing;
