package com.sun.xml.bind.v2.schemagen.xmlschema;

/**
 * @author Kohsuke Kawaguchi
 */
public interface Particle extends ContentModelContainer, Occurs {
}
