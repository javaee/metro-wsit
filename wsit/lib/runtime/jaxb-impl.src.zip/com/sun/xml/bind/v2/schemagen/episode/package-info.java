/**
 * TXW interfaces for writing episode file, which is what XJC needs to
 * handle separate compilation.
 */
package com.sun.xml.bind.v2.schemagen.episode;