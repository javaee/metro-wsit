package com.sun.istack;

/**
 *
 * @author Martin Grebac
 */
public interface Builder<T> {
    T build();
}
