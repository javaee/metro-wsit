/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 2003-2007 Sun Microsystems, Inc. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License. You can obtain
 * a copy of the License at https://glassfish.dev.java.net/public/CDDL+GPL.html
 * or glassfish/bootstrap/legal/LICENSE.txt.  See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/bootstrap/legal/LICENSE.txt.
 * Sun designates this particular file as subject to the "Classpath" exception
 * as provided by Sun in the GPL Version 2 section of the License file that
 * accompanied this code.  If applicable, add the following below the License
 * Header, with the fields enclosed by brackets [] replaced by your own
 * identifying information: "Portions Copyrighted [year]
 * [name of copyright owner]"
 *
 * Contributor(s):
 *
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package org.glassfish.gmbal.generic ;

import java.util.Comparator ;

public class PairComparator<S,T> implements Comparator<Pair<S,T>>
{
    private Comparator<? super S> sc ;
    private Comparator<? super T> tc ;

    public PairComparator( Comparator<? super S> sc, Comparator<? super T> tc )
    {
	if ((sc == null) || (tc == null))
	    throw new IllegalArgumentException() ;

	this.sc = sc ;
	this.tc = tc ;
    }

    public int compare( Pair<S,T> o1, Pair<S,T> o2 )
    {
	int res = sc.compare( o1.first(), o2.first() ) ;
	if (res == 0)
	    return tc.compare( o1.second(), o2.second() ) ;
	else
	    return res ;
    }

    public boolean equals( Object obj ) 
    {
	if (!(obj instanceof PairComparator))
	    return false ;

	if (obj == this)
	    return true ;

	PairComparator<S,T> other = (PairComparator<S,T>)obj ;
	return other.sc.equals( sc ) && other.tc.equals( tc ) ;
    }

    public int hashCode() {
	return sc.hashCode() ^ tc.hashCode() ;
    }

    public String toString() {
	return "PairComparator[" + sc + "," + tc + "]" ;
    }
}
