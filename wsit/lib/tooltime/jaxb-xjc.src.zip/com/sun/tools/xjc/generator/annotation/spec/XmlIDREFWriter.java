
package com.sun.tools.xjc.generator.annotation.spec;

import javax.xml.bind.annotation.XmlIDREF;
import com.sun.codemodel.JAnnotationWriter;

public interface XmlIDREFWriter
    extends JAnnotationWriter<XmlIDREF>
{


}
