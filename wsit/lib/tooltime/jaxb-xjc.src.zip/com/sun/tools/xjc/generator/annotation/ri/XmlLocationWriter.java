
package com.sun.tools.xjc.generator.annotation.ri;

import com.sun.codemodel.JAnnotationWriter;
import com.sun.xml.bind.annotation.XmlLocation;

public interface XmlLocationWriter
    extends JAnnotationWriter<XmlLocation>
{


}
