package com.sun.tools.ws.ant;

/**
 * Wrapper task to launch {@link WsGen2}.
 *
 * @author Kohsuke Kawaguchi
 */
public class WsGen extends WrapperTask {}
