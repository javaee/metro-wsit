/*
 * SimpleService.java
 *
 * Created on December 1, 2006, 12:18 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package wstx.sample.service;

import com.sun.xml.ws.api.tx.ATTransaction;
import com.sun.xml.ws.api.tx.TransactionManagerFactory;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateful;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.XASession;
import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.annotation.Resource;
import javax.jws.WebService;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.Transaction;
import javax.transaction.TransactionManager;
import javax.transaction.UserTransaction;

/**
 * A Basic WSIT WS-TX Web Service
 *
 * See "Edit Web Service Attributes" to view/modify the TransactionAttribute for each
 * Web Service Operation of this Transacted SimpleService.
 */
@WebService(serviceName = "SimpleService",
portName = "SimpleServiceBinding",
        targetNamespace = "http://tempuri.org/")
        public class Simple {
    static final Logger logger = Logger.getLogger("SimpleService");
    
    @Resource
    UserTransaction ut;
    
    Connection connection = null;
    
    @Resource(mappedName = "jms/ConnectionFactory")
    private ConnectionFactory connectionFactory;
    
    @Resource(mappedName = "jms/Queue")
    private Queue queue;
    
    // Sufficient amount of time to wait for a message to be delivered to QUEUE before giving up on
    // it.
    final int TIMEOUT_READING_MESSAGE = 10000;
    
    /** Creates a new instance */
    public Simple() {
    }
    
    @WebMethod
    public void init()  {
        clearJMSQueue();
    }
    
    @WebMethod
    public void publishRequired(@WebParam(name = "id") Long id,
            @WebParam(name = "description") String description) {
        final String METHODNAME = "publishRequired";
        logger.info(METHODNAME + " ENTER [id=" + id + " description="+ description + "]");
        publish(id, description);
        logger.info(METHODNAME + " Exit [id=" + id + " description="+ description + "]");
    }
    
    @WebMethod
    public void publishSupports(@WebParam(name = "id") Long id,
            @WebParam(name = "description") String description) {
        final String METHODNAME = "publishSupports";
        logger.info(METHODNAME + "[id=" + id + " description="+ description + "]");
        publish(id, description);
    }
    
    
    @WebMethod
    public boolean verify(@WebParam(name="id") Long id,
            @WebParam(name="description") String description) {
        boolean result = false;
        
        try {
            result = verifyMessage(TIMEOUT_READING_MESSAGE, id, description);
        } catch (JMSException je) {
            je.printStackTrace();
        }
        return result;
    }
    
    static private TransactionManager wsatTm = null;
    
    // Implementation of functionality
    private void publish(Long id, String description) {
        Throwable rethrow = null;
        Session session = null;
        
        try {
            makeConnection();
            session = connection.createSession(false, 0);
            MessageProducer publisher = session.createProducer(queue);
            TextMessage message = session.createTextMessage();
            message.setText("Item " + id + ": " + description);
            logger.info(
                    "PUBLISHER: Setting " + "message text to: "
                    + message.getText());
            publisher.send(message);
        } catch (Throwable t) {
            // JMSException could be thrown
            logger.severe(
                    "PublisherBean.publish: " + "Exception: "
                    + t.toString());
            rethrow = t;
        } finally {
            if (session != null) {
                try {
                    session.close();
                    endConnection();
                } catch (JMSException e) {
                }
            }
        }
    }
    
    private Message getMessage(int timeout) throws JMSException {
        Message result = null;
        Session session = null;
        try {
            makeConnection();
            session = connection.createSession(false, 0);
            MessageConsumer msgConsumer = session.createConsumer(queue);
            Message message = null;
            connection.start();
            result = msgConsumer.receive(timeout);
        } finally {
            if (session != null) {
                try {
                    session.close();
                    endConnection();
                } catch (JMSException e) {
                }
            }
            return result;
        }
    }
    
    private boolean verifyMessage(int timeout, Long id, String description) throws JMSException {
        Message msg = getMessage(timeout);
        if (msg == null) {
            logger.warning("timed out reading message from jms/Queue");
        } else if (msg instanceof TextMessage) {
            TextMessage txtMsg = (TextMessage)msg;
            logger.info("read message from jms/Queue with text=|" + txtMsg.getText());
            final String expectedMsgText = "Item " + id + ": " + description;
            if (txtMsg.getText().equals(expectedMsgText)) {
                return true;
            } else {
                logger.info("verify failed. Expected=" + expectedMsgText +
                        " Received msg txt=" + txtMsg.getText());
            }
        } else {
            logger.warning("unhandled message type in verifyMessage");
        }
        return false;
    }
    /**
     * Creates the connection.
     */
    // @PostConstruct
    public void makeConnection() {
        logger.info("acquiring JMS connection for instance " + this.toString());
        try {
            connection = connectionFactory.createConnection();
        } catch (Throwable t) {
            // JMSException could be thrown
            logger.severe(
                    "Simple.makeConnection:" + "Exception: "
                    + t.toString());
        }
    }
    
    /**
     * Closes the connection.
     */
    //@PreDestroy
    public void endConnection() throws RuntimeException {
        logger.info("release JMS connection for instance " + toString());
        if (connection != null) {
            try {
                connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    private void clearJMSQueue() {
        // clear jms queue
        Session session = null;
        try {
            makeConnection();
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            MessageConsumer msgConsumer = session.createConsumer(queue);
            Message message = null;
            connection.start();
            while (true) {
                Message result = msgConsumer.receive(1000);
                if (result == null) {
                    break;
                } else {
                    System.out.println("WARNING: clear unexpected unread message from queue:" +
                            ((TextMessage)result).getText());
                }
            }
        } catch (JMSException je) {
            je.printStackTrace();
        } finally {
            
            if (session != null) {
                try {
                    session.close();
                    endConnection();
                } catch (JMSException e) {
                }
            }
        }
    }
}
