/*
 * SimpleService.java
 *
 * Created on December 1, 2006, 12:18 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package sb;

import com.sun.xml.ws.api.tx.ATTransaction;
import com.sun.xml.ws.api.tx.TransactionManagerFactory;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateful;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.XASession;
import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.annotation.Resource;
import javax.jws.WebService;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.Transaction;
import javax.transaction.TransactionManager;
import javax.transaction.UserTransaction;
import static javax.ejb.TransactionManagementType.CONTAINER;
import static javax.ejb.TransactionAttributeType.*;

/**
 * A Basic WSIT WS-TX Web Service implemented as 
 * Container Managed Transaction (CMT) Enterprise Java Bean (EJB)
 */
@WebService(serviceName = "SimpleService", 
            portName = "SimpleServiceBinding", 
            targetNamespace = "http://tempuri.org/")
@Stateless
@TransactionManagement(CONTAINER)
@TransactionAttribute(NOT_SUPPORTED)
public class SimpleAsCMTEjb {
     static final Logger logger = Logger.getLogger("SimpleService");

    @Resource(mappedName = "jms/ConnectionFactory")
    private ConnectionFactory connectionFactory;
    
    @Resource(mappedName = "jms/Queue")
    private Queue queue;
    
    private Connection connection = null;
    
    // Sufficient amount of time to wait for a message to be delivered to QUEUE before giving up on 
    // it. In milliseconds, so currently 10 seconds.
    final int TIMEOUT_READING_MESSAGE = 10000;
  
    /** Creates a new instance */
    public SimpleAsCMTEjb() {
    }  
    
    @WebMethod
    public void init()  {
        //Workaround for glassfish issue 2105 "EJB Web Service resource injection occurring after @PostConstruct"
        makeConnection();
        clearJMSQueue();
        
       
    }

    @WebMethod
    @TransactionAttribute(REQUIRED)
    public void publishRequired(@WebParam(name = "id") Long id, 
                                @WebParam(name = "description") String description) {
      final String METHODNAME = "publishRequired";
      logger.info(METHODNAME + " ENTER [id=" + id + " description="+ description + "]");
      publish(id, description);
      logger.info(METHODNAME + " Exit [id=" + id + " description="+ description + "]");
    }

    @WebMethod
    @TransactionAttribute(SUPPORTS)
    public void publishSupports(@WebParam(name = "id") Long id, 
                                @WebParam(name = "description") String description) {
        final String METHODNAME = "publishSupports";
        logger.info(METHODNAME + "[id=" + id + " description="+ description + "]");
        publish(id, description);
    }

    
   @WebMethod 
   @TransactionAttribute(REQUIRED)
   public boolean verify(@WebParam(name="id") Long id, 
                         @WebParam(name="description") String description) {
        boolean result = false;
        
        try {
            result = verifyMessage(TIMEOUT_READING_MESSAGE, id, description);
        } catch (JMSException je) {
            je.printStackTrace();
        }
        return result;
    }
  
    // Implementation of functionality
    private void publish(Long id, String description) {
        Throwable rethrow = null;
        Session session = null;
        MessageProducer publisher = null;
        TextMessage message = null;
        String messageType = null;

        try {
            session = connection.createSession(false, 0);
            publisher = session.createProducer(queue);
            message = session.createTextMessage();
            message.setText("Item " + id + ": " + description);
            logger.info(
                        "PUBLISHER: Setting " + "message text to: "
                        + message.getText());
            publisher.send(message);
        } catch (Throwable t) {
            // JMSException could be thrown
            logger.severe(
                    "PublisherBean.publish: " + "Exception: "
                    + t.toString());
            rethrow = t;
        } finally {
            if (session != null) {
                try {
                    session.close();
                } catch (JMSException e) {
                }
            }
        }
    }
    
     private Message getMessage(int timeout) throws JMSException {
        Message result = null;
        Session session = null;
         try {
            session = connection.createSession(false, 0);
            MessageConsumer msgConsumer = session.createConsumer(queue);
            Message message = null;  
            connection.start();
            result = msgConsumer.receive(timeout);
        } finally {
            if (session != null) {
                try {
                    session.close();
                } catch (JMSException e) {
                }
            }
            return result;
        }
    }
     
    private boolean verifyMessage(int timeout, Long id, String description) throws JMSException {
       Message msg = getMessage(timeout);
       if (msg == null) {
           logger.warning("timed out reading message from jms/Queue");
        } else if (msg instanceof TextMessage) {
            TextMessage txtMsg = (TextMessage)msg;
            logger.info("read message from jms/Queue with text=|" + txtMsg.getText());
            final String expectedMsgText = "Item " + id + ": " + description;
            if (txtMsg.getText().equals(expectedMsgText)) {
                return true;
            } else {
                logger.info("verify failed. Expected=" + expectedMsgText + 
                                  " Received msg txt=" + txtMsg.getText());
            }
        } else {
            logger.warning("unhandled message type in verifyMessage");
        }
        return false;
    }
    
    /**
     * Creates the connection.
     */
    @PostConstruct
    public void makeConnection() {
     logger.info("acquiring JMS connection for instance " + this.toString());
     try {
            connection = connectionFactory.createConnection();
        } catch (Throwable t) {
            // JMSException could be thrown
            logger.severe(
                    "Simple.makeConnection:" + "Exception: "
                    + t.toString());
        }
    }
    
    /**
     * Closes the connection.
     */
    @PreDestroy
    public void endConnection() throws RuntimeException {
        logger.info("release JMS connection for instance " + toString());
        if (connection != null) {
            try {
                connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
     
     private void clearJMSQueue() {       
        // clear jms queue
         Session session = null;
         try {
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            MessageConsumer msgConsumer = session.createConsumer(queue);
            Message message = null;  
            connection.start();
            while (true) {
                Message result = msgConsumer.receive(1000);
                if (result == null) {
                    break;
                } else {
                    System.out.println("WARNING: clear unexpected unread message from queue:" +
                            ((TextMessage)result).getText());
                }
            }
        } catch (JMSException je) {
            je.printStackTrace();
        } finally {    
            if (session != null) {
                try {
                    session.close();
                } catch (JMSException e) {
                }
            }
        }
     }
}
