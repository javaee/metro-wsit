/*
 * ClientServlet.java
 *
 * Created on December 1, 2006, 12:51 AM
 */

package wstx.sample.client;

import com.sun.corba.se.impl.interceptors.PICurrent;
import java.io.*;
import java.net.*;
import javax.annotation.Resource;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;
import javax.xml.ws.WebServiceRef;
import wstx.sample.client.SimpleService;

/**
 * Transacted Client calling Simple Transacted Service implemented as a Servlet and as a
 * Container Managed Transaction (CMT) Enterprise Java Beans (EJB).
 *
 * @author jf39279
 * @version
 */
public class ClientServlet extends HttpServlet {
    
    @WebServiceRef(wsdlLocation = "http://localhost:8080/SimpleService/SimpleAsCMTEjb?WSDL")
    private wstx.sample.ejbclient.SimpleService serviceImplementedAsCMTEJB;
    
    @WebServiceRef(wsdlLocation = "http://localhost:8080/SampleService-war/SimpleService?wsdl")
    private SimpleService service;
    
    @Resource UserTransaction ut;
    
    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<title>WS-TX Simple Client</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>WS-TX Simple Client</h1>");
        out.flush();
        
        callSimpleServlet(out);
        out.println("</br></br>");
        out.flush();
        callSimpleCMTEJB(out);
        
        out.println("</body>");
        out.println("</html>");
        out.close();
    }
    
    private void callSimpleServlet(PrintWriter out) {
        out.println("<h2>Calling WS-TX Simple Web Service implemented as Servlet</h2>");
        out.flush();
        
        try {
            final long MAX_VALUE = 3;
            
            wstx.sample.client.Simple port = service.getSimpleServiceBinding();
            port.init();
            try {
                ut.begin();
                try {
                    for (long i = 0; i < MAX_VALUE; i++) {
                        port.publishRequired(i, "publishRequired" + i);
                    }
                } finally {
                    try {
                        ut.commit();
                    } catch (Exception e) { }
                }
                out.println("Finished publishedRequired. Sent " + MAX_VALUE + " message(s)</br>");
                
                boolean failed = false;
                for (long i = 0; i < MAX_VALUE; i++) {
                    boolean result = port.verify(i, "publishRequired" + i);
                    if (! result) {
                        failed = true;
                    }
                }
                if (! failed) {
                    out.println("verified " + MAX_VALUE + " message(s) sent.</br></br>");
                } else {
                    out.println("failed verified message(s) sent.</br></br>");
                }
                
            } catch (Exception e) {
                out.println("unexpected exception in publishRequired</br>");
                e.printStackTrace(out);
            }
            out.flush();
            
            try {
                ut.begin();
                try {
                    port.publishSupports(2L, "rollback2");
                    port.publishSupports(20L, "rollback20");
                } finally {
                    ut.rollback();
                }
                out.println("Finished publishSupports invocation</br>");        
                
                // Send a terminating message.
                port.publishRequired(12L, "Thats All Folks" + 12);
                
                // read terminating committed message. If rolled back messages sent,
                // this fails.
                if (port.verify(12L, "Thats All Folks" + 12)) {
                    out.println("Pass. verified rolled back messages not sent. </br></br>");
                } else {
                    out.println("Failed. verified rolled back messages sent despite rollback.</br></br>");
                }
            } catch (Exception e) {
                out.println("unexpected exception in rollback test</br>");
                e.printStackTrace(out);
                out.println("</br></br>");
            }
            out.flush();
        } catch (Exception ex) {
            ex.printStackTrace(out);
        }
    }
    
    private void callSimpleCMTEJB(PrintWriter out) {
        out.println("<h2>Calling WS-TX Simple Web Service implemented as CMT EJB</h2>");
        out.flush();
        
        wstx.sample.ejbclient.SimpleAsCMTEjb port = serviceImplementedAsCMTEJB.getSimpleServiceBinding();
        try {
            final long MAX_VALUE = 3;
            
            port.init();
            try {
                ut.begin();
                try {
                    for (long i = 0; i < MAX_VALUE; i++) {
                        port.publishRequired(i, "publishRequired" + i);
                    }
                } finally {
                    try {
                        ut.commit();
                    } catch (Exception e) { }
                }
                out.println("Finished publishedRequired. Sent " + MAX_VALUE + " message(s)</br>");
                  
                boolean failed = false;
                for (long i = 0; i < MAX_VALUE; i++) {
                    boolean result = port.verify(i, "publishRequired" + i);
                    if (! result) {
                        failed = true;
                    }
                }
                if (! failed) {
                    out.println("verified " + MAX_VALUE + " message(s) sent.</br></br>");
                } else {
                    out.println("failed verified message(s) sent.</br></br>");
                }
                
            } catch (Exception e) {
                out.println("unexpected exception in publishRequired</br>");
                e.printStackTrace(out);
            }
            out.flush();
            
            try {
                ut.begin();
                try {
                    port.publishSupports(2L, "rollback2");
                    port.publishSupports(20L, "rollback20");
                } finally {
                    ut.rollback();
                }
                out.println("Finished publishSupports invocation</br>");
                
                // Send a terminating message.
                port.publishRequired(12L, "Thats All Folks" + 12);
                   
                // read terminating committed message. If rolled back messages sent,
                // this fails.
                if (port.verify(12L, "Thats All Folks" + 12)) {
                    out.println("Pass. verified rolled back messages not sent. </br></br>");
                } else {
                    out.println("Failed. verified rolled back messages sent despite rollback.</br></br>");
                }
                
            } catch (Exception e) {
                out.println("unexpected exception in rollback test</br>");
                e.printStackTrace(out);
                out.println("</br></br>");
            }
            out.flush();
        } catch (Exception ex) {
            ex.printStackTrace(out);
        }
    }
    
// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
// </editor-fold>
}
